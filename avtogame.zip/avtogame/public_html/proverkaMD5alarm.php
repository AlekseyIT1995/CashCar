<?php
######################################
# Скрипт Fruit Farm
# Автор APTEMOH
# E-mail: anatolii.123456@yandex.ru
# Skype: ArtIncProject
# VK.com: https://vk.com/id381626457
######################################

//та же функция перебора всех файлов в подпапках
function GetListFiles($folder,&$all_files){
	if($folder=="./post-logs")
		return;
    $fp=opendir($folder);
    while($cv_file=readdir($fp)) {
        if(is_file($folder."/".$cv_file) && (substr($cv_file,-4)==".php" || $cv_file==".htaccess") ) {
        	$cv_file=str_replace(" ","_",$cv_file);
            $all_files[]=$folder."/".$cv_file;
        }elseif($cv_file!="." && $cv_file!=".." && is_dir($folder."/".$cv_file)){
            GetListFiles($folder."/".$cv_file,$all_files);
        }
    }
    closedir($fp);
}
//загружаем образцовые контрольные суммы
$file=file("md5.txt");
$orig=array();
foreach ($file as $val) {
	$tmp=explode(" ",$val);
	$orig[$tmp[0]]=trim($tmp[1]);
}
$all_files=array();
$alarm="";
GetListFiles(".",$all_files);
foreach ($all_files as $str) {
	//если такого файла нет среди исходных, то это подозрительно и стоить проверить не шелл ли это?
	if(!isset($orig[$str]))
		$alarm.="New file ".$str."\n";
	//если же не сходится md5 сумма, то это еще более подозрительно
	elseif($orig[$str]!=md5_file($str))
		$alarm.="MD5 sum for ".$str." changed! Orig ".$orig[$str].", new ".md5_file($str)."\n";
}
//если есть хоть одно срабатывание шлем себе письмо
if($alarm!="")
	mail("anatolii.123456@yandex.ru","Толясик баста телепузики!",$alarm);

?>