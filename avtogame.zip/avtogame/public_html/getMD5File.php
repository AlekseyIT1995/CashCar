<?php
######################################
# Скрипт Fruit Farm
# Автор APTEMOH
# E-mail: anatolii.123456@yandex.ru
# Skype: ArtIncProject
# VK.com: https://vk.com/id381626457
######################################

//рекурсивная функция для перебора всех файлов в папке и подпапках
function GetListFiles($folder,&$all_files){
        //исключаем папку с скомпилированными шаблонами smarty, они меняются постоянно
    if($folder=="./templates_c")
        return;
    $fp=opendir($folder);
    while($cv_file=readdir($fp)) {
        if(is_file($folder."/".$cv_file) && (substr($cv_file,-4)==".php" || $cv_file==".htaccess") ) {
            //если в имени файла есть пробелы заменяем их на подчеркивание
            $cv_file=str_replace(" ","_",$cv_file);
            $all_files[]=$folder."/".$cv_file;
        }elseif($cv_file!="." && $cv_file!=".." && is_dir($folder."/".$cv_file)){
            GetListFiles($folder."/".$cv_file,$all_files);
        }
    }
    closedir($fp);
}
$all_files=array();
GetListFiles(".",$all_files);
$str="";
//создаем строку разделенную пробелом, первая часть это путь к файлу, вторая это md5 сумма файлв 
foreach ($all_files as $val) {
    $str.=$val." ".md5_file($val)."\n";
}
//сохраняем данные
$fp=fopen("md5.txt","w");
fwrite($fp,$str);
fclose($fp);

?>