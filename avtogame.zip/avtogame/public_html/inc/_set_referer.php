<?php
# Тут вставляем в куки ID referera
if(isset($_GET["i"])){
    $_rid = (intval($_GET["i"]) > 0) ? (int)$_GET["i"] : 1; 
    $_rid = (int)$_rid;
    $_rid = filter_var($_rid, FILTER_SANITIZE_NUMBER_INT);
    setcookie("i",$_rid,time()+2592000);
    header("Location: /");
}
?>