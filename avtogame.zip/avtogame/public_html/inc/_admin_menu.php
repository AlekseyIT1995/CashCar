<?php
$adm = $config->AdminPage;
?>
<div class="col-xs-3">
	<div class="panel panel-primary ">
<style>
#sidebar-menu ul {
	background: #234;
}
#sidebar-menu ul li a{
	padding: 12px 20px;display: block;
}
#sidebar-menu ul li a:hover{
	
	background: #012;
}
</style>
        <div id="sidebar-menu" >
            <ul>
                <center style="background: #012;padding:5px;color: #89a;"><h3>АДМИНКА</h3></center>
                <li><a class="list-group-item" href="/?menu=<?=$adm?>&sel=stats">Статистика</a></li>
                <li><a class="list-group-item" href="/?menu=<?=$adm?>&sel=users">Пользователи</a></li>
                <li><a class="list-group-item" href="/?menu=<?=$adm?>&sel=quest">Квесты</a></li>
                <li><a class="list-group-item" href="/?menu=<?=$adm?>&sel=feedback">Отзывы</a></li>
                <li><a class="list-group-item" href="/?menu=<?=$adm?>&sel=compconfig">Конкурс рефералов</a></li>
                <li><a class="list-group-item" href="/?menu=<?=$adm?>&sel=invcompconfig">Конкурс инвесторов</a></li>
                <li><a class="list-group-item" href="/?menu=<?=$adm?>&sel=config">Настройки сайта</a></li>
                <li><a class="list-group-item" href="/?menu=<?=$adm?>&sel=story_swap">Реинвесты</a></li>
                <li><a class="list-group-item" href="/?menu=<?=$adm?>&sel=story_insert">Пополнения</a></li>
                <li><a class="list-group-item" href="/?menu=<?=$adm?>&sel=payments">Выплаты</a></li>
                <li><a class="list-group-item" href="/?menu=<?=$adm?>&sel=story_buy">Покупки</a></li>
                <li><a class="list-group-item" href="/?menu=<?=$adm?>&sel=story_sell">Продажи</a></li>
                <!-- <li><a class="list-group-item" href="/?menu=<?=$adm?>&sel=news">Новости</a></li> -->
                <li><hr></li>
                <li><a class="list-group-item" href="/?menu=<?=$adm?>&sel=output">Выход из профиля</a></li>
            </ul>
        </div>
	</div>
</div>