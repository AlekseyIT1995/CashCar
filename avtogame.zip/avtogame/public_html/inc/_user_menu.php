<!-- ========== Left Sidebar Start ========== -->
<?php 
$db->Query("SELECT COUNT(*) FROM db_serfing WHERE status = '2'");
$kolSerf = $db->FetchRow();
$user_id = (isset($_SESSION["user_id"])) ? $_SESSION["user_id"] : '';
?>
            <div class="left side-menu">
                <div class="sidebar-inner slimscrollleft">

                    <div class="user-details">
                        <div class="text-center">
                            <img src="/img/avatar/<?=(strlen($user_data['ava']) > 1) ? $user_data['ava'] : 'nouser.png'?>" class="img-circle">
                        </div>
                        <div class="user-info">
                            <div class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><?=(isset($_SESSION["user"])) ? $_SESSION["user"] : '';?></a>
                                <ul class="dropdown-menu">
                                    <li><a href="/user/"> Мой кабинет/настройки</a></li>
                                    <li><a href="/user/settings"> Настройки</a></li>
				                    <li><a href="/user/myreferrals">Рефералы </a></li>
                                    <li class="divider"></li>
                                    <li><a href="/user/output"> Выход</a></li>
                                </ul>
                            </div>

                            <p class="text-muted m-0"><i class="fa fa-dot-circle-o text-success"></i> Online</p>
                        </div>
						<br>
                        <button type="button" class="btn waves-effect btn-default btn-block" style="text-align: left;padding: 6px 10px;font-size: 13px;" data-toggle="tooltip" data-placement="top" data-original-title="Баланс на счету для покупок">
						    <i class="mdi mdi-arrow-left-bold-circle-outline"></i> На покупки: <div class="balancelist">{!BALANCE_B!} руб.</div>
						</button>
                        <button type="button" class="btn waves-effect btn-default btn-block" style="text-align: left;padding: 6px 10px;font-size: 13px;margin-top:5px;" data-toggle="tooltip" data-placement="top" data-original-title="Ваш баланс на счету для выплат">
						    <i class="mdi mdi-arrow-right-bold-circle-outline"></i> На вывод: <div class="balancelist">{!BALANCE_P!} руб.</div>
						</button>
                        <button type="button" class="btn waves-effect btn-default btn-block" style="text-align: left;padding: 6px 10px;font-size: 13px;margin-top:5px;" data-toggle="tooltip" data-placement="top" data-original-title="Ваш баланс на счету для рекламы">
						    <i class="mdi mdi-bullhorn"></i> На рекламу: <div class="balancelist">{!ADV!} руб.</div>
						</button>
                    </div>
                    <!--- Divider -->
                   <div id="sidebar-menu">
                        <ul>
                            <li><hr></li>
                            <li><a href="/user/" class="waves-effect"><i class="fa fa-user-circle"></i><span> Мой кабинет/настройки </span></a></li>
                            <li><a href="/user/carpark" class="waves-effect"><i class="fa fa-car"></i><span> Мой автопарк <span class="badge badge-default pull-right" data-toggle="tooltip" data-placement="left" data-original-title="Кол-во машин в вашем автопарке"><?=$func->allCars($user_id)?></span></span></a></li>
							<li><a href="/user/race_leaders" class="waves-effect"><i class="fa fa-car"></i><span> Гонки </span></a></li>
                            <li><a href="/user/daily" class="waves-effect"><i class="fa fa-gift"></i><span> Ежедневный бонус </span></a></li>							
							<li><a href="/user/lottery" class="waves-effect"><i class="fa fa-gift"></i><span> Лотерея  </span></a></li>
                            <li><hr></li>
                            <li><a href="/user/insert" class="waves-effect"><i class="fa fa-plus-square"></i><span> Пополнить баланс </span></a></li>
                            <li><a href="/user/outpay" class="waves-effect"><i class="fa fa-minus-square"></i><span> Заказать выплату </span></a></li>
                            <li><a href="/user/exchange" class="waves-effect"><i class="fa fa-refresh"></i><span> Обмен баланса </span></a></li>
                            <li><hr></li>
                            <li><a href="/user/serfing" class="waves-effect"><i class="fa fa-mouse-pointer"></i><span> Сёрфинг сайтов <span class="badge badge-default pull-right" data-toggle="tooltip" data-placement="left" data-original-title="Доступные ссылки для просмотра"><?=$kolSerf?></span></span></a></li>
                            <li><a href="/user/serfing/add" class="waves-effect"><i class="fa fa-forward"></i><span> Добавить сайт в серфинг </span></a></li>
                            <li><a href="/user/adv_balance" class="waves-effect"><i class="fa fa-bullhorn"></i><span> Рекламный баланс </span></a></li>
                            <li><hr></li>
                            <li><a href="/user/partnership" class="waves-effect"><i class="fa fa-handshake-o"></i><span> Партнерская программа </span></a></li>
                            <li><a href="/user/myreferrals" class="waves-effect"><i class="fa fa-users"></i><span> Список рефералов <span class="badge badge-default pull-right" data-toggle="tooltip" data-placement="left" data-original-title="Кол-во ваших рефералов"><?=$func->getAllRef($user_id)?></span></span></a></li>
							<li><a href="/user/buyref" class="waves-effect"><i class="fa fa-calculator"></i><span> Покупка рефералов </span></a></li>
                            <li><a href="/user/promo" class="waves-effect"><i class="fa fa-picture-o"></i><span> Рекламные материалы </span></a></li>
                            <li><hr></li>
						    <li><a href="/user/training" class="waves-effect"><i class="fa fa-info-circle"></i><span> Обучающий раздел </span></a></li>
                            <li><a target="_blank" href="/stat" class="waves-effect"><i class="fa fa-area-chart"></i><span> Статистика проекта </span></a></li>                            
                        </ul>
                    </div>
                    <div class="clearfix"></div>
                </div> <!-- end sidebarinner -->
            </div>
            <!-- Left Sidebar End -->
