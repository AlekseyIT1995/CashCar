<?php
######################################
# Модуль MegaKassa Скрипт Fruit Farm
# Автор APTEMOH
# E-mail: anatolii.123456@yandex.ru
# Skype: ArtIncProject
# VK.com: https://vk.com/id381626457
######################################

# Заголовки страницы с кодировкой :
header( 'Content-type: text/html; charset=utf-8' );

# Автоподгрузка классов
function __autoload($name){ include("classes/_class.".$name.".php");}

# Класс конфига
$config = new config;

# Функции
$func = new func;

# База данных
$db = new db($config->HostDB, $config->UserDB, $config->PassDB, $config->BaseDB);

	// проверка IP-адреса
	$ip_checked = false;
	
	foreach(array(
		'HTTP_X_CLUSTER_CLIENT_IP',
		'HTTP_X_FORWARDED_FOR',
		'HTTP_X_FORWARDED',
		'HTTP_FORWARDED_FOR',
		'HTTP_FORWARDED',
		'HTTP_CLIENT_IP',
		'REMOTE_ADDR'
	) as $param) {
		if(!empty($_SERVER[$param]) && $_SERVER[$param] === '5.196.121.217') {
			$ip_checked = true;
			break;
		}
	}
	if(!$ip_checked) {
		die('error1');
	}
	
	// проверка на наличие обязательных полей
	// поля $payment_time и $debug могут дать true для empty() поэтому их нет в проверке
	foreach(array(
		'uid',
		'amount',
		'amount_shop',
		'amount_client',
		'currency',
		'order_id',
		'payment_method_title',
		'creation_time',
		'client_email',
		'status',
		'signature'
	) as $field) {
		if(empty($_REQUEST[$field])) {
			die('error2');
		}
	}
	
	// ваш секретный ключ
	$secret_key	= $config->secret_key;
	
	// нормализация данных
	$uid					= (int)$_REQUEST["uid"];
	$amount					= (double)$_REQUEST["amount"];
	$amount_shop			= (double)$_REQUEST["amount_shop"];
	$amount_client			= (double)$_REQUEST["amount_client"];
	$currency				= $_REQUEST["currency"];
	$order_id				= $_REQUEST["order_id"];
	$payment_method_id		= (int)$_REQUEST["payment_method_id"];
	$payment_method_title	= $_REQUEST["payment_method_title"];
	$creation_time			= $_REQUEST["creation_time"];
	$payment_time			= $_REQUEST["payment_time"];
	$client_email			= $_REQUEST["client_email"];
	$status					= $_REQUEST["status"];
	$debug					= (!empty($_REQUEST["debug"])) ? '1' : '0';
	$signature				= $_REQUEST["signature"];
	
	// проверка валюты
	if(!in_array($currency, array('RUB', 'USD', 'EUR'), true)) {
		die('error3');
	}
	
	// проверка статуса платежа
	if(!in_array($status, array('success', 'fail'), true)) {
		die('error4');
	}
	
	// проверка формата сигнатуры
	if(!preg_match('/^[0-9a-f]{32}$/', $signature)) {
		die('error5');
	}
	
	// проверка значения сигнатуры
	$signature_calc = md5(join(':', array(
		$uid, $amount, $amount_shop, $amount_client, $currency, $order_id,
		$payment_method_id, $payment_method_title, $creation_time, $payment_time,
		$client_email, $status, $debug, $secret_key
	)));
	if($signature_calc !== $signature) {
		die('error6');
	}
	
	// далее ваши проверки:
	// - на наличие платежа в вашей БД по $order_id
	// - на соответствии суммы и валюты платежа в вашей БД
	// ...
	
	// обработка платежа
	switch($status) {
		case 'success':
		
			// время соверешния платежа в Unix timestamp (если нужно)
			$payment_time_ts = strtotime($payment_time);
		
			// ваш код при успешной оплате
			$db->Query("SELECT * FROM `db_payeer_insert` WHERE id = '".intval($_POST['order_id'])."'");
	        if($db->NumRows() == 0){ echo $_POST['order_id']."|error7"; exit;}

	        $payeer_row = $db->FetchArray();
	        if($payeer_row["status"] > 0){ echo $_POST['order_id']."|success"; exit;}

	        $db->Query("UPDATE `db_payeer_insert` SET status = '1' WHERE id = '".intval($_POST['order_id'])."'");

	        $ik_payment_amount = $amount;
	        $user_id = $payeer_row["user_id"];

	        # Настройки
	        $db->Query("SELECT * FROM db_config WHERE id = '1' LIMIT 1");
	        $sonfig_site = $db->FetchArray();

	        $db->Query("SELECT user, referer_id FROM db_users_a WHERE id = '{$user_id}' LIMIT 1");
	        $user_ardata = $db->FetchArray();
	        $user_name = $user_ardata["user"];
	        $refid = $user_ardata["referer_id"];

	        # Зачисляем баланс
	        $serebro = sprintf("%.4f", floatval($sonfig_site["ser_per_wmr"] * $ik_payment_amount) );

	        $db->Query("SELECT insert_sum FROM db_users_b WHERE id = '{$user_id}' LIMIT 1");
	        $ins_sum = $db->FetchRow();

	        $serebro = intval($ins_sum <= 0.01) ? ($serebro + ($serebro * 0.1) ) : $serebro;

	        #$add_tree = ( $ik_payment_amount >= 499.99) ? 2 : 0; e_t = e_t + '$add_tree',
	        $lsb = time();
	        
	        /* ====== Рефералка 3 уровня ====== */
		    $db->Query("SELECT user, referer_id, referer_id2, referer_id3 FROM db_users_a WHERE id = '{$user_id}' LIMIT 1");
		    $user_ardata = $db->FetchArray();
		    $user_name = $user_ardata["user"];
		    $refid = $user_ardata["referer_id"];
		    $ref2 = $user_ardata["referer_id2"];
		    $ref3 = $user_ardata["referer_id3"];

			$to_referer  = ($serebro * 0.04); // Первый уровень - 4 процента
			$to_referer2 = ($serebro * 0.03); // Второй уровень - 3 процента
			$to_referer3 = ($serebro * 0.01); // Третий уровень - 1 процент


		    $db->Query("UPDATE db_users_b SET money_b = money_b + $to_referer2 WHERE id = '$ref2'");
			$db->Query("UPDATE db_users_b SET money_b = money_b + $to_referer3 WHERE id = '$ref3'");

			$db->Query("UPDATE db_users_a SET doxod2 = doxod2 + $to_referer2 WHERE id = '$user_id'");
			$db->Query("UPDATE db_users_a SET doxod3 = doxod3 + $to_referer3 WHERE id = '$user_id'");

			/* ====== /Рефералка 3 уровня ====== */

	        # Зачисляем средства НАМ )
	        $db->Query("UPDATE db_users_b
	                    SET money_b = money_b + '$serebro',
	                        to_referer = to_referer + '$to_referer',
	                        insert_sum = insert_sum + '$ik_payment_amount'
	                    WHERE id = '{$user_id}'"); # last_sbor = '$lsb',

	        # Зачисляем средства рефереру и дерево
	        #$add_tree_referer = ($ins_sum <= 0.01) ? ", a_t = a_t + 1" : "";
	        $db->Query("UPDATE db_users_b
	                    SET money_b = money_b + $to_referer,
	                        from_referals = from_referals + '$to_referer'
	                    WHERE id = '$refid'");

	        # Статистика пополнений
	        $da = time();
	        $dd = $da + 60*60*24*15;
	        $db->Query("INSERT INTO db_insert_money (`user`, `user_id`, `money`, `serebro`, `date_add`, `date_del`) VALUES ('$user_name','$user_id','$ik_payment_amount','$serebro','$da','$dd')");

	        # Обновление статистики сайта
	        $db->Query("UPDATE db_stats SET all_insert = all_insert + '$ik_payment_amount' WHERE id = '1'");

	        # Конкурс
			$competition = new competition($db);
			$competition->UpdatePoints($user_id, $ik_payment_amount);
			#--------
			# Конкурс
			$invcompetition = new invcompetition($db);
			$invcompetition->UpdatePoints($user_id, $ik_payment_amount);
			#--------

			break;
		case 'fail':
			// ваш код при отмене или истечении платежа
			// ...
			break;
	}
	
	// успешный ответ для Мегакассы и завершение скрипта
	die('ok');
?>