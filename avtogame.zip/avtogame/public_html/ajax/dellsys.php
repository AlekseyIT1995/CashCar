<?php
session_start();
#####################################
# Автор APTEMOH
# E-mail: anatolii.123456@yandex.ru
# Skype: ArtIncProject
# VK.com: https://vk.com/id381626457
# Version: 1.1
#####################################

# Автоподгрузка классов
define('BASE_DIR', $_SERVER['DOCUMENT_ROOT']);
function __autoload($name){ include(BASE_DIR."/classes/_class.".$name.".php");}

# Класс конфига 
$config = new config;

# Функции
$func = new func;

# База данных
#$db = new db($config->HostDB, $config->UserDB, $config->PassDB, $config->BaseDB);
$db = new db(config::$HostDBstatic, config::$UserDBstatic, config::$PassDBstatic, config::$BaseDBstatic);

$usid = $_SESSION["user_id"];
$usname = $_SESSION["user"];

# Наш токен
$array = array('salt' => 'solsalt', 
               'key' => 'XrenVamVsemvStakanOtAPTEMOHa',
                );
$tokenMy = hash('sha256', implode(":", $array));

$userAgent = isset($_SERVER['HTTP_USER_AGENT'])
               ? strtolower($_SERVER['HTTP_USER_AGENT'])
               : '';

$tokenHash = md5($_SESSION['csrf_seed'].$userAgent.$_SERVER['REMOTE_ADDR'].$tokenMy);

if ($_GET['hex'] !== $tokenHash) {
    echo "badkey";
    exit();
}

$idPs = (int)$_POST['ps'];

$arrPaySysCode = array(1,2,3,4,5,6,7,8,9,10,11);

$arrPaySys = array(
                '1' => 'payeer',
                '2' => 'yandex',
                '3' => 'qiwi',
                '4' => 'advcash',
                '5' => 'okpay',
                '6' => 'beeline',
                '7' => 'tele2',
                '8' => 'mts',
                '9' => 'megafon',
                '10' => 'wm',
                '11' => 'visa',
        );

if (!in_array($idPs, $arrPaySysCode)) {
    exit('badkey');
}

$blockPaySys = $arrPaySys[$idPs];

# блокируем
$db->Query("UPDATE `db_users_b` SET {$blockPaySys} = '1' WHERE id = '$usid'");

echo "success";



?>