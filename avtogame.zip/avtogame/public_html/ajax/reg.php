<?php
session_start();
#####################################
# Автор APTEMOH
# E-mail: anatolii.123456@yandex.ru
# Skype: ArtIncProject
# VK.com: https://vk.com/id381626457
# Version: 1.1
#####################################

# Автоподгрузка классов
define('BASE_DIR', $_SERVER['DOCUMENT_ROOT']);
function __autoload($name){ include(BASE_DIR."/classes/_class.".$name.".php");}

# Класс конфига 
$config = new config;

# Функции
$func = new func;

# База данных
#$db = new db($config->HostDB, $config->UserDB, $config->PassDB, $config->BaseDB);
$db = new db(config::$HostDBstatic, config::$UserDBstatic, config::$PassDBstatic, config::$BaseDBstatic);

    # Регистрация
    if(isset($_POST["login"])){
    
        $login = $func->IsLogin($_POST["login"]);
        $pass = $func->IsPassword($_POST["pass"]);
        $rules = isset($_POST["rules"]) ? true : false;
        $time = time();
        $ip = $func->UserIP;
        $ipregs = $db->Query("SELECT * FROM `db_users_a` WHERE INET_NTOA(db_users_a.ip) = '$ip' ");
        $ipregs = $db->NumRows();
        $passmd = $func->md5Password($pass);
        $email = $func->IsMail($_POST["email"]);
        $referer_id = (isset($_COOKIE["i"]) AND intval($_COOKIE["i"]) > 0 AND intval($_COOKIE["i"]) < 1000000) ? intval($_COOKIE["i"]) : 1;
        $referer_name = "";
        
        if($referer_id != 1){
            $db->Query("SELECT user FROM db_users_a WHERE id = '$referer_id' LIMIT 1");
            if($db->NumRows() > 0){$referer_name = $db->FetchRow();}
                else{ $referer_id = 1; $referer_name = "Admin"; }
        }else{ $referer_id = 1; $referer_name = "Admin"; }
		
		$ip = $func->GetUserIp();
		$db->Query("SELECT COUNT(*) FROM db_users_a WHERE ip = INET_ATON('$ip')");
		if($db->FetchRow() == 0){
        
			$captcha = "";
			#$captcha = $_POST["g-recaptcha-response"];
			$captcha = $_POST["captcha"];

			$secret = "6LcVN1YUAAAAAJbua_CGl4ur5PsqoyVfHrB8c04h";

			$response = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=".$secret."&response=".$captcha."&remoteip=".$_SERVER['REMOTE_ADDR']);

			$response = json_decode($response, true);

			/*if($response["success"] === true) {  
				echo "Yes";
				var_dump($response);
			}else {
				#var_dump($_POST['g-recaptcha-response']);
				echo "ass";
				var_dump($response);
			}*/

			if ($response["success"] != false) {

				if($emailregs == 0) {

					#if($rules){

						if($email !== false){
				
							if($login !== false){
					
								if($pass !== false){
					
									#var_dump($pass);
									#echo "<br/>";
									#var_dump($_POST["repass"]);
									if($pass == $_POST["repass"]){
								
										$db->Query("SELECT COUNT(*) FROM db_users_a WHERE user = '$login'");
										if($db->FetchRow() == 0){
											/* ================== */
											# Регаем пользователя

											$db->Query("SELECT referer, referer_id FROM db_users_a WHERE id = '$referer_id' LIMIT 1");
											$stats_data = $db->FetchArray();
											$referer_name2=$stats_data["referer"];
											$referer_id2=$stats_data["referer_id"];

											$db->Query("SELECT referer, referer_id FROM db_users_a WHERE id = '$referer_id2' LIMIT 1");
											$stats_data3 = $db->FetchArray();
											$referer_name3=$stats_data3["referer"];
											$referer_id3=$stats_data3["referer_id"];

											# Регаем пользователя
											$db->Query("INSERT INTO db_users_a (user, email, pass, referer, referer_id, referer_id2, referer_id3, date_reg, ip) VALUES ('$login','{$email}','$passmd','$referer_name','$referer_id','$referer_id2','$referer_id3', '$time',INET_ATON('$ip'))");
											/* ================== */

											# Регаем пользователя
											$md5_pass = md5($pass);
											//$db->Query("INSERT INTO db_users_a (user, email, pass, referer, referer_id, date_reg, ip)
											//VALUES ('$login','{$email}','$md5_pass','$referer_name','$referer_id','$time',INET_ATON('$ip'))");
									
											$lid = $db->LastInsert();
									
											$db->Query("INSERT INTO db_users_b (id, user, a_t, last_sbor, money_b) VALUES ('$lid','$login','0', '".time()."',10)");
									
											# Вставляем статистику
											$db->Query("UPDATE db_stats SET all_users = all_users +1 WHERE id = '1'");
									
											$_SESSION["user_id"] = $lid;
											$_SESSION["user"] = $login;
											$_SESSION["referer_id"] = $referer_id;
											
											//exit(header("Location: /account/pole"));
							
											#echo "<div class='h-title2'><b><font color = '#fff'>Вы успешно зарегистрировались в проекте.<br /> Используйте форму для входа на главной странице</font></b><BR /></div>";
											//</div>
											//return;
											echo "success";
										
										}else echo "Указанный логин уже используется";
								
									}else echo "Пароль и повтор пароля не совпадают";
					
								}else echo "Пароль заполнен неверно";
					
							}else echo "Логин заполнен неверно";

						}else echo "E-mail имеет неверный формат";

					#}else echo "Вы не подтвердили правила";
			
				}else echo "Указанный E-mail уже есть в нашей базе!";
				
			}else echo "Капча не пройдёна!!!";
		
		}else echo "Регистрация с данного IP уже производилась!";
    
    }

?>