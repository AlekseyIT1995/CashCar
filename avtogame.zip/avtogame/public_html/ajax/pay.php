<?php
session_start();
#####################################
# Автор APTEMOH
# E-mail: anatolii.123456@yandex.ru
# Skype: ArtIncProject
# VK.com: https://vk.com/id381626457
# Version: 1.1
#####################################

# Автоподгрузка классов
define('BASE_DIR', $_SERVER['DOCUMENT_ROOT']);
function __autoload($name){ include(BASE_DIR."/classes/_class.".$name.".php");}

# Класс конфига 
$config = new config;

# Функции
$func = new func;

# База данных
#$db = new db($config->HostDB, $config->UserDB, $config->PassDB, $config->BaseDB);
$db = new db(config::$HostDBstatic, config::$UserDBstatic, config::$PassDBstatic, config::$BaseDBstatic);

$usid = $_SESSION["user_id"];
$usname = $_SESSION["user"];

$db->Query("SELECT `email_verify`,`plat_pass` FROM db_users_a WHERE id = '$usid' LIMIT 1");
$data = $db->FetchArray();

$db->Query("SELECT `money_p`,`paypass`,`payeer`,`yandex`,`qiwi`,`visa`,`beeline`,`tele2`,`mts`,`megafon`,`insert_sum` FROM db_users_b WHERE id = '$usid' LIMIT 1");
$datab = $db->FetchArray();

# Наш токен
$array = array('salt' => 'solsalt', 
               'key' => 'XrenVamVsemvStakanOtAPTEMOHa',
                );
$tokenMy = hash('sha256', implode(":", $array));

$userAgent = isset($_SERVER['HTTP_USER_AGENT'])
               ? strtolower($_SERVER['HTTP_USER_AGENT'])
               : '';

$tokenHash = md5($_SESSION['csrf_seed'].$userAgent.$_SERVER['REMOTE_ADDR'].$tokenMy);

if ($_GET['hex'] !== $tokenHash) {
    echo "badkey";
    exit();
}

if ($data['email_verify'] == 0) {
    echo "Подтвердите свой E-mail для активации выплат.";
    exit();
}

$idPs = (int)$_POST['ps'];
$psSys = array("payeer","yandex","qiwi","adv","pm","card","wm","okpay","beeline","tele2","mts","megafon","card");

$arrMinPay = array('1','11','11','11','1','100','11','1','11','11','11','11');

$arrPaySys = array(
		'payeer' => 'payeer',
		'yandex' => 'yandex',
		'qiwi' => 'qiwi',
		'adv' => 'adv',
		'pm' => 'pm',
		'card' => 'visa',
		'wm' => 'wm',
		'okpay' => 'okpay',
		'beeline' => 'beeline',
		'tele2' => 'tele2',
		'mts' => 'mts',
		'megafon' => 'megafon',
	);

$purse = $datab[$arrPaySys[$psSys[($idPs-1)]]];
if (strlen($purse) == 1) {
    echo "Укажите номер кошелька в настройках.";
    exit();
}

$sum = $func->myNum($_POST['sum']);

if (empty($sum)) {
    echo "Введите сумму выплаты.";
    exit();
}

if ($sum == false) {
    echo "badkey";
    exit();
}

# Заглушка
if($datab["insert_sum"] <= $config->minForPayment){
    echo "Для активации выплат необходимо пополнить баланс на -  1 руб., Пожалуйста пополните баланс!";
    exit();
}

if ($sum > $datab['money_p']) {
    echo "Недостаточно средств для вывода.";
    exit();
}

if (strlen($data['plat_pass']) == 1) {
    echo "Укажите платежный пароль в настройках.";
    exit();
}

$plat_passs = $_POST['paypass'];
$plat_pass = $func->md5Password($plat_passs);
if ($plat_pass !== $data['plat_pass']) {
    echo "Платежный пароль введен не верно!";
    exit();
}


$minPay = $arrMinPay[($idPs-1)];

if($sum >= $minPay){

    $val = 'RUB';

    $ps = array(
            'payeer'=>'1136053',
            'qiwi'=>'60792237',
            'yandex'=>'57378077',
            'beeline'=>'24898938',
            'megafon'=>'24899391',
            'mts'=>'24899291',
            'tele2'=>'95877310',
            'card' =>'117146509',
            'okpay' =>'57644634',
            'adv' =>'87893285',
        );

    $codePaySys = $ps[$psSys[($idPs-1)]];
    $purse = $datab[$arrPaySys[$psSys[($idPs-1)]]];

    # Проверяем на существующие заявки
    $db->Query("SELECT COUNT(*) FROM db_payment WHERE user_id = '$usid' AND (status = '0' OR status = '1')");
    if($db->FetchRow() == 0){

        # Делаем выплату
        $payeer = new rfs_payeer($config->AccountNumber, $config->apiId, $config->apiKey);
        if ($payeer->isAuth()){

            $arBalance = $payeer->getBalance();
            if($arBalance['auth_error'] == 0){

                $balance = $arBalance['balance']['RUB']['DOSTUPNO'];
                if($balance >= $sum_pay){

                    $array = array(
                        'action' => 'output',
                        'ps' => $codePaySys,
                        'curIn' => $val, // счет списания
                        'sumOut' => $sum, // сумма получения
                        'curOut' => $val, // валюта получения
                        'param_ACCOUNT_NUMBER' => $purse // получатель
                    );

                    if($psSys[($idPs-1)] == 'card'){
                        $array['param_CONTACT_PERSON'] = 'PETRO';
                    }

                    $initOutput = $payeer->initOutput($array);
                    if ($initOutput){

                        $historyId = $payeer->output();
                        if ($historyId > 0){
                            # Снимаем с пользователя
                            
                            $db->Query("UPDATE `db_users_b` SET money_p = money_p - '$sum', payment_sum = payment_sum + '$sum' WHERE id = '$usid'");

                            # Вставляем запись в выплаты
                            $da = time();
                            $dd = $da + 60*60*24*15;

                            $ppid = $historyId;
                            $pay_sys = $psSys[($idPs-1)];

                            $db->Query("INSERT INTO `db_payment` (user, user_id, purse, sum, valuta, serebro, pay_sys, pay_sys_id, payment_id, date_add, status) VALUES ('$usname','$usid','$purse','$sum','RUB', '$sum', '$pay_sys', '$codePaySys', '$ppid','".time()."', '3')");

                            $db->Query("UPDATE `db_stats` SET all_payments = all_payments + '$sum' WHERE id = '1'");

                            echo "success";
                        
                        }else{
                            echo 'Ошибка ['.print_r($payeer->getErrors(), true).'] - попробуйте через  20-30 секунд или сообщите о ней администратору!';
                        }

                    }else{
                        echo 'Ошибка ['.print_r($payeer->getErrors(), true).'] - попробуйте через 20-30 секунд или сообщите о ней администратору!';
                    }

                }else echo "Сервер перегружен - попробуйте через 10-30 секунд или сообщите о ней администратору";

            }else echo "Не удалось выплатить! Попробуйте позже.";

        }else echo "Не удалось выплатить! Попробуйте позже!";

    }else echo "У вас имеются необработанные заявки. Дождитесь их выполнения.";

}else echo 'Минимальная сумма для выплаты составляет '.$minPay.' руб.';

?>