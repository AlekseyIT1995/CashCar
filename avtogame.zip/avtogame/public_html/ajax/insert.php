<?php
session_start();
#####################################
# Автор APTEMOH
# E-mail: anatolii.123456@yandex.ru
# Skype: ArtIncProject
# VK.com: https://vk.com/id381626457
# Version: 1.1
#####################################

# Автоподгрузка классов
define('BASE_DIR', $_SERVER['DOCUMENT_ROOT']);
function __autoload($name){ include(BASE_DIR."/classes/_class.".$name.".php");}

# Класс конфига 
$config = new config;

# Функции
$func = new func;

# База данных
#$db = new db($config->HostDB, $config->UserDB, $config->PassDB, $config->BaseDB);
$db = new db(config::$HostDBstatic, config::$UserDBstatic, config::$PassDBstatic, config::$BaseDBstatic);

$usid = $_SESSION["user_id"];
$usname = $_SESSION["user"];

$type = (int)$_GET['type'];

if ($func->myNum($type) == false) {
    exit('Error!');
}

$arrPaySysCode = array(1,13,3,8,2,6,);

$arrPaySys = array(
            '1'     =>  'Payeer',
            '13'    =>  'YandexMoney',
            '3'     =>  'AdvancedCash',
            '8'     =>  'PerfectMoney',
            '2'     =>  'Free-Kassa',
            '6'     =>  'QiWi',
        );

if (!in_array($type, $arrPaySysCode)) {
    exit('Error.');
}

if ($func->myNum($_POST['sum']) == false) {
    exit('Error!!!');
}else $sum = $func->myNum($_POST['sum']);


if ($type == 1) {

    $time = time();
    $pay = $arrPaySys[$type];

    # Заносим в БД
    $db->Query("INSERT INTO db_payeer_insert (user_id, user, sum, date_add, pay_sys) VALUES ('$usid','$usname','$sum','$time','$pay')");

    $desc = base64_encode("Pay USER ".$usname);
    $m_shop = $config->shopID;
    $m_orderid = $db->LastInsert();
    $m_amount = number_format($sum, 2, ".", "");
    $m_curr = "RUB";
    $m_desc = $desc;
    $m_key = $config->secretW;
    $arHash = array(
        $m_shop,
        $m_orderid,
        $m_amount,
        $m_curr,
        $m_desc,
        $m_key
    );
    $sign = strtoupper(hash('sha256', implode(":", $arHash)));

    header('location: https://payeer.com/api/merchant/m.php?m_shop='.$m_shop.'&m_orderid='.$m_orderid.'&m_amount='.$m_amount.'&m_curr='.$m_curr.'&m_desc='.$m_desc.'&m_sign='.$sign);

}elseif ($type == 13) {
    $time = time();
    $pay = $arrPaySys[$type];

    # Заносим в БД
    $db->Query("INSERT INTO db_payeer_insert (user_id, user, sum, date_add, pay_sys) VALUES ('$usid','$usname','$sum','$time','$pay')");
    $orderId = $db->LastInsert();
    $desc = $usname;

    header('Location: https://money.yandex.ru/quickpay/confirm.xml?receiver='.$config->yandexMoney.'&quickpay-form=donate&paymentType=PC&formcomment='.$desc.'&short-dest='.$desc.'&targets=Помощь проекту!!!&successURL='.$_SERVER['SERVER_NAME'].'/success.html&label='.$orderId.'&sum='.$sum);

}elseif ($type == 3) {
    $time = time();
    $pay = $arrPaySys[$type];

    # Заносим в БД
    $db->Query("INSERT INTO db_payeer_insert (user_id, user, sum, date_add, pay_sys) VALUES ('$usid','$usname','$sum','$time','$pay')");
    $orderId = $db->LastInsert();
    $desc = $usname;

    $ac_account_email = $config->ac_account_email;
    $ac_sci_name = $config->ac_sci_name;
    $ac_amount = number_format($sum, 2, ".", "");
    $ac_currency = "RUB";
    $secret = $config->secret;
    $ac_order_id = $db->LastInsert();

    $ac_comments = $usid.'|'.$usname.'|'.$ac_order_id;

    $arHash = array(
        $ac_account_email,
        $ac_sci_name,
        $ac_amount,
        $ac_currency,
        $secret,
        $ac_order_id
    );

    $sign = hash('sha256', implode(":", $arHash));

    header('Location: https://wallet.advcash.com/sci/?ac_account_email='.$ac_account_email.'&ac_sci_name='.$ac_sci_name.'&ac_amount='.$ac_amount.'&ac_currency='.$ac_currency.'&ac_merchant_currency='.$ac_currency.'&ac_order_id='.$ac_order_id.'&ac_sign='.$sign);

}elseif ($type == 8) {
    $time = time();
    $pay = $arrPaySys[$type];

    # Заносим в БД
    $db->Query("INSERT INTO db_payeer_insert (user_id, user, sum, date_add, pay_sys) VALUES ('$usid','$usname','$sum','$time','$pay')");
    $orderId = $db->LastInsert();

    echo $orderId.";".$sum;
}elseif ($type == 2) {
    $time = time();
    $pay = $arrPaySys[$type];

    # Заносим в БД
    $db->Query("INSERT INTO db_payeer_insert (user_id, user, sum, date_add, pay_sys) VALUES ('$usid','$usname','$sum','$time','$pay')");
    $orderId = $db->LastInsert();

    $merchant_id = $config->fk_merchant_id;
    $out_amount = $sum;
    $secret_word = $config->fk_merchant_key;
    $descript = $func->make_signature($merchant_id, $out_amount, $secret_word, $order_id);
    #$m_amount = number_format($sum, 2, ".", "");

    header('Location: http://www.free-kassa.ru/merchant/cash.php?m='.$merchant_id.'&oa='.$sum.'&s='.$descript.'&o='.$orderId);

}elseif($type == 6){
    $time = time();
    $pay = $arrPaySys[$type];

    # Заносим в БД
    $db->Query("INSERT INTO db_payeer_insert (user_id, user, sum, date_add, pay_sys) VALUES ('$usid','$usname','$sum','$time','$pay')");
    $orderId = $db->LastInsert();

    #$db->Query("SELECT `email` FROM `db_users_a` WHERE id = '$usid' LIMIT 1");
    #$data = $db->FetchArray();

    $shop_id        = $config->shop_id;
    $amount         = number_format($sum, 2, '.', ''); // -> "100.50"
    $currency       = 'RUB'; // или "USD", "EUR"
    $description    = 'For user '.$usname;
    $order_id       = $orderId;
    $method_id      = ''; # QiWi = 22
    $client_email   = ''; #$data['email'];
    $client_phone   = '';
    $debug          = '1'; // или "1"
    $secret_key     = $config->secret_key; // из настроек сайта в личном кабинете
    $signature      = md5($secret_key.md5(join(':', array($shop_id, $amount, $currency, $description, $order_id, $method_id, $client_email, $debug, $secret_key))));
    $language       = 'ru'; // или 'en'

    /*<form method="post" action="https://megakassa.ru/merchant/" accept-charset="UTF-8">
        <input type="hidden" name="shop_id" value="<?=$shop_id;?>" />
        <input type="hidden" name="amount" value="<?=$amount;?>" />
        <input type="hidden" name="currency" value="<?=$currency;?>" />
        <input type="hidden" name="description" value="<?=htmlentities($description, ENT_QUOTES, 'UTF-8');?>" />
        <input type="hidden" name="order_id" value="<?=$order_id;?>" />
        <input type="hidden" name="method_id" value="<?=$method_id;?>" />
        <input type="hidden" name="client_email" value="<?=$client_email;?>" />
        <input type="hidden" name="debug" value="<?=$debug;?>" />
        <input type="hidden" name="signature" value="<?=$signature;?>" />
        <input type="hidden" name="language" value="<?=$language;?>" />
        <input type="submit" value="Купить" />
    </form>*/
    header('Location: https://megakassa.ru/merchant/?shop_id='.$shop_id.'&amount='.$amount.'&currency='.$currency.'&description='.$description.'&order_id='.$order_id.'&method_id='.$method_id.'&client_email='.$client_email.'&client_phone='.$client_phone.'&debug='.$debug.'&signature='.$signature.'&language='.$language);
}else{
    exit('Error');
}

?>