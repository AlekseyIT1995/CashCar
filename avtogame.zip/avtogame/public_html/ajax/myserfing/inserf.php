<?php 
session_start();
######################################
# Модуль Серфинг для Fruit Farm
# Автор APTEMOH
# E-mail: anatolii.123456@yandex.ru
# Skype: ArtIncProject
# VK.com: https://vk.com/id381626457
######################################
define('TIME', time());
define('BASE_DIR', $_SERVER['DOCUMENT_ROOT']);

header("Content-type: text/html; charset=utf-8");

if (!isset($_SESSION['user_id'])) { exit(); }

function __autoload($name){ include(BASE_DIR."/classes/_class.".$name.".php");}

$config = new config;

# База данных
$db = new db($config->HostDB, $config->UserDB, $config->PassDB, $config->BaseDB);

$db->Query("SET NAMES 'utf8'");
$db->Query("SET CHARACTER SET 'utf8'");
$db->Query("SET SESSION collation_connection = 'utf8_general_ci'");

$user_name = $_SESSION['user'];
$userId = $_SESSION['user_id'];

$db->Query("SELECT * FROM db_users_b WHERE id = '$userId'");
$users_info = $db->FetchArray();

$id = isset($_POST['id']) ? (int) $_POST['id'] : 0;
$db->query("SELECT * FROM db_serfing WHERE user_name = '$user_name' AND id = '$id'");

if (!$db->NumRows()) exit('fail');

$res = $db->FetchArray();

if($res['rating'] == 1){
    $nowcost = 20/1000;
}elseif($res['rating'] == 2){
    $nowcost = 40/1000;
}elseif($res['rating'] == 3){
    $nowcost = 60/1000;
}else{
    $nowcost = '0';
}

echo $res['id']."<br/>".$res['money']."<br/>".$nowcost;
?>