<?PHP
$_OPTIMIZATION["title"] = "Вход в аккаунт";
$_OPTIMIZATION["description"] = "Авторизация пользователя в системе";
$_OPTIMIZATION["keywords"] = "Авторизация пользователя в системе";

?>
<!doctype html>
<html lang="ru">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=no" />
    <title>AvtoGame - {!TITLE!}</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Arsenal:400,700|Ubuntu" />
    <link rel="stylesheet" href="/style/bootstrap.min.css" type="text/css" />
    <link rel="stylesheet" href="/style/pagestyle.css" type="text/css" />
    <link rel="stylesheet" href="/style/formstyle.css" type="text/css" /> 
    <link rel="icon" type="image/png" href="favicon.ico">
    <link href="/style/sweet-alert.css" rel="stylesheet" type="text/css">
		<script type="text/javascript" src="/js/functions.js"></script>
</head>

<body>
    <div class="container">
        <div class="content">

            <article class="col-md-12">
                <div class="row">
                    <div class="col-md-4 col-md-offset-4">
<form id="loginform" action="" method="post">

                            <div class="form-heading text-center">
					<a href="/"><img src="/img/logo-small.png" style="max-width: 100%;"></a>
					<div class="title">Вход в аккаунт</div>
                            </div>
<?php

	if(isset($_POST["log_email"])){
	
	   $lmail = $func->IsMail($_POST["log_email"]);
	
		if($lmail !== false){
		
			$db->Query("SELECT id, user, pass, referer_id, banned FROM db_users_a WHERE email = '$lmail'");
			if($db->NumRows() == 1){
			
                $log_data = $db->FetchArray();

                $post_pass = $func->md5Password($_POST["pass"]); // с формы авторизации в MD5
			
				#if(strtolower($log_data["pass"]) == strtolower($_POST["pass"])){
                if(strtolower($log_data["pass"]) == strtolower($post_pass)){
				
					if($log_data["banned"] == 0){
						
						# Считаем рефералов
						$db->Query("SELECT COUNT(*) FROM db_users_a WHERE referer_id = '".$log_data["id"]."'");
						$refs = $db->FetchRow();
						
						$db->Query("UPDATE db_users_a SET referals = '$refs', date_login = '".time()."', ip = INET_ATON('".$func->UserIP."') WHERE id = '".$log_data["id"]."'");
						
						$_SESSION["user_id"] = $log_data["id"];
						$_SESSION["user"] = $log_data["user"];
						$_SESSION["referer_id"] = $log_data["referer_id"];
						?>

                        <meta http-equiv="refresh" content="0;url=/user/" />

<?
						
					}else echo "<div class='alert alert-danger'> Аккаунт заблокирован ! У вас больше 1 аккаунта ! Напишите в тех поддержку  ! </div>";
				
				}else echo "<div class='alert alert-danger'>Неверные данные</div>";
			
			}else echo "<div class='alert alert-danger'>E-mail не зарегистрирован</div>";
			
		}else echo "<div class='alert alert-danger'>Недопустимый формат E-mail</div>";
	
	}

?>
                            <div class="row">
                                <div class="col-md-12">
		<input style="" name="log_email" placeholder="Введите e-mail" type="text" maxlength="35">
</div>
                                <div class="col-md-12">
		<input style="margin-top: 5px;" name="pass" placeholder="Введите пароль" type="password" maxlength="35">
</div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 text-center">
		<input type="submit" value="Войти в аккаунт" class="adam-button adam-red">
		<p class="title-description"><a href="/recovery">Напомнить пароль</a> | <a href="/reg">Создать аккаунт</a></p>
                               </div>
                            </div>
                        </form>
                    </div>
                </div>
            </article>

            <div class="clearfix"></div>
        </div>
    </div>
    <script src="js/jquery-3.1.1.min.js" type="text/javascript"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="/js/sweet-alert.min.js"></script>
	<!-- Yandex.Metrika counter --><!-- /Yandex.Metrika counter -->
</body>
</html>