<div class="page-header">
    <h1>Подтверждение отзывов</h1>
</div>
<br/>
<?php 
if (isset($_POST['go'])) {
    $id = (int)$_POST['id'];
    $user_id = (int)$_POST['user_id'];

    $db->Query("UPDATE db_feedback SET status = '1' WHERE id = '$id'");

    header( 'Refresh: 2; url=/?menu='.$adm.'&sel=feedback' );
    echo "<font style='font-size:20px; font-weight:bold;'>Выполнено! Подтверждено!</font><br/>";
}

if (isset($_POST['dell'])) {
    $id = (int)$_POST['id'];

    $db->Query("UPDATE db_feedback SET status = '2' WHERE id = '$id'");

    header( 'Refresh: 2; url=/?menu='.$adm.'&sel=feedback' );
    echo "Отклонено!";
}

$db->Query("SELECT * FROM `db_feedback` WHERE status = '0' ORDER BY `id` DESC");

if($db->NumRows() > 0){
?>
<table align="center" border="1" width="90%" cellpadding="10" cellspacing="10">
    <tr>
        <td>ID</td>
        <td>USER</td>
        <td>Дата</td>
        <td>Данные</td>
        <td>Статус</td>
        <td>Действие</td>
    </tr>
<?php 
    while($data = $db->FetchArray()){

        if ($data['status'] == 0) {
            $status = 'На проверке';
        }
?>
    <tr>
        <td><?=$data['id']?></td>
        <td><?=$data['user']?></td>
        <td><?=$data['data_time']?></td>
        <td><?=$data['text_fedd']?></td>
        <td><?=$status?></td>
        <td>
            <form method="POST" action="">
                <input type="hidden" name="id" value="<?=$data['id']?>">
                <input type="hidden" name="user_id" value="<?=$data['user_id']?>">
                <input type="submit" name="go" value="Подтвердить">
                <input type="submit" name="dell" value="Отклонить">
            </form>
        </td>
    </tr>
<?php
    }
    echo "</table>";
}else echo "<tr><td colspan='6'><br/>Нет отзывов требующих подтверждение!!!<br/></td></tr></table>";
?>
