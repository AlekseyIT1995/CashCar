<?PHP
$_OPTIMIZATION["title"] = "Партнерская программа";
$user_id = (int)$_SESSION["user_id"];
$uname = $_SESSION["user"];

$db->Query("SELECT COUNT(*) FROM db_users_a WHERE referer_id = '$user_id'");
$refs = $db->FetchRow();

if($user_id !== 1){
	#header( 'Refresh: 1; url=/user/buyref' );
	Header("Location: /user/buyref");
}
?>
<script type="text/javascript">
	function hideserfaddblock(bname) {
        if (document.getElementById(bname).style.display == 'none') {
            document.getElementById(bname).style.display = '';
        } else {
            document.getElementById(bname).style.display = 'none';
        }
        return false;
    }
</script>
<div class="page-content-wrapper ">

    <div class="container">
        <div class="row">
            <div class="col-lg-9 partner_cl">
                <div class="panel panel-primary">
                    <div class="panel-body">
						<ul>
							<li><span style="font-size: medium; color: #3366ff;"><strong>Приглашайте в игру своих друзей и знакомых, Вы будете получать: 10% от их продажи конфет !</strong></span><span style="color: green;"> <font color="green"> </span></li>
							<li><span style="font-size: medium; color: #3366ff;"><strong>Прибыль от рефералов поступает на счёт для вывода !</strong></span><span> <font color="blou"> </span></li>
							<li><span style="font-size: medium; color: #3366ff;"><strong>Вы можете продавать своих рефералов указав свою цену серебром, при продаже деньги поступят на счёт для вывода !</strong></span><span> <font color="blou"> </span></li>
							<li><span style="font-size: medium; color: #3366ff;"><strong>Так же вы можете приобрести себе свободного реферала, для этого посетите стр. Покупка рефералов !</strong></span><span> <font color="blou"> </span></li>
						</ul>
					 </div>
                </div>
            </div>
        </div>
        <!-- end row -->
    </div><!-- container -->
</div>


<?php

	if (isset($_POST['goback'])) {
		$ident = (int)$_POST['idref'];

		$user = $_POST["user"];
		$user = filter_var ( $user, FILTER_SANITIZE_STRING );

		$db->Query("DELETE FROM db_buyref WHERE id_user = '$ident' AND user = '$user'");

		header( 'Refresh: 1; url=/user/myref' );
	}

if (isset($_POST["submit"])) {
	$price = floatval($_POST['price']);

	# Получаем имя
	$ident = (int)$_POST['idref'];
	$ident = filter_var($ident, FILTER_SANITIZE_NUMBER_INT);

	$user = $_POST["user"];
	$user = filter_var ( $user, FILTER_SANITIZE_STRING );

	$time = date("Y-m-d H:i:s", time());

	$db->Query("SELECT `id` FROM db_users_a WHERE referer_id = '$ident'");
	$refRow = $db->FetchArray();
	if ($refRow !== $ident) {

		$db->Query("SELECT COUNT(*) FROM db_buyref WHERE id_user = '$ident' AND status = '1'");
		

			# Добавляем на продажу
			$db->Query("INSERT INTO db_buyref (`sum`, `id_user`, `user`, `status`, `id_buyer`, `date_add`) VALUES ('$price', '$ident', '$user', '1', '$user_id', '$time')");

			echo "<b>Ваш реферал выставлен на продажу за ".$price." серебра.!</b>";

			header( 'Refresh: 3; url=/user/myref' );

		
		

	} else echo "Hacking attempt! За вами уже выехали!";

	#header( 'Refresh: 3; url=/user/myref' );
}

?>

<br /><br />

<style type="text/css">
.refexchange {
    float: right;
    display: block;
    height: 116px;
    width: 16px;
    outline: none;
    border: none;
    margin: 0 1px;
    cursor: pointer;
}

.refexchange:hover {
    border: none;
}
.refexchange { background: url(/img/box.png) no-repeat left top; }

.refex-back { 
background: url(/img/box-back.png) no-repeat left top; 
} 

.refex-back { 
float: right; 
display: block; 
height: 16px; 
width: 16px; 
outline: none; 
border: none; 
margin: 0 2px; 
cursor: pointer; 
}

</style>

			<div class="col-lg-9 partner_cl">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title racetabletitle"><i class="fa fa-list-ul"></i> Количество ваших рефералов: <font color="#000;"><?=$refs; ?> чел.</font></h3>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="table-responsive">

    <table class="table">
	<thead>
		<tr height='25' valign=top align=center>
			<th class="text-center"> Логин </th>
			<th class="text-center"> Дата регистрации </th>
			<th class="text-center"> Заходил </th>
			<th class="text-center"> Смешариков</th>
			<th class="text-center"> Доход от партнера </th>
			<th class="text-center"> Продажа </th>
		</tr>
	</thead>
    <tbody>
<?php

$bd_host = $config->HostDB;
$bd_user = $config->UserDB;
$bd_password = $config->PassDB;
$bd_base = $config->BaseDB;


$con = mysql_connect($bd_host, $bd_user, $bd_password);
if (!$con) {
    die('Ошибка соединения: ' . mysql_error());
}
mysql_select_db($bd_base, $con); #$mysql_queries++;
#mysql_query("set names cp1251");


  $all_money = 0;
  $db->Query("SELECT db_users_a.id,
  					 db_users_a.user,
  					 db_users_a.date_reg,
  					 db_users_a.date_login,
  					 db_users_b.to_referer,
  					 db_users_b.a_t,
  					 db_users_b.b_t,
  					 db_users_b.c_t,
  					 db_users_b.d_t,
  					 db_users_b.e_t
  			    FROM db_users_a, db_users_b
  			    WHERE db_users_a.id = db_users_b.id
  			    AND db_users_a.referer_id = '$user_id'
  				ORDER BY to_referer DESC");

	if($db->NumRows() > 0){

  		while($ref = $db->FetchArray()){

            if ($ref["date_login"] == 0) {
                $date_login = $ref["date_reg"];
            }else{
                $date_login = $ref["date_login"];
            }

  			$all = $ref["a_t"] + $ref["b_t"] + $ref["c_t"] + $ref["d_t"] + $ref["e_t"];

		?>
		<tr class="text-center bonus_tr">
			<td align="center">
				<?=$ref["user"]; ?>
				<?php
				$refId = $ref["id"];
				$zz=mysql_query("SELECT sum FROM db_buyref WHERE id_user='$refId' AND status='1'");
				if(mysql_num_rows($zz)!=0) {
					$zzz=mysql_fetch_assoc($zz);
					echo "<BR/><span class='exchtext'><font color = 'green'>Продаётся за <b>".$zzz['sum']."</b> серебра.
					</span>";
				}
				?>
			</td>
			<td align="center"> <?=date("d.m.Y",$ref["date_reg"]); ?> </td>
			<td align="center"><?=date("d.m.Y",$date_login);?></td>
			<td align="center"><?=$all;?></td>
			<td align="center"> <?=sprintf("%.2f",$ref["to_referer"]); ?> </td>
			<td align="center">
				<?php
				if(mysql_num_rows($zz)!=0)
				{
				?>
				<a class='refex-back' onclick="javascript:hideserfaddblock('back<?=$ref['id'];?>');" title='Вернуть'></a>
				<?
				}else{
				?>
				<a class='refexchange' onclick="javascript:hideserfaddblock('exblock<?=$ref['id'];?>');" title='Продать '></a>
				<?php
				}
				?>
			</td>
		</tr>

		<tr id="back<?=$ref['id'];?>" style='display: none;'>
			<td class='ext' colspan='6' align='center'>
				<div class='goexchangeblock'>
					<form action='' method='post' autocomplete="off">
					<input type='hidden' name='idref' value="<?=$ref['id'];?>"/>
					<input type='hidden' name='user' value='<?=$ref["user"];?>'>
					<input type='submit' size='55' name='goback' value='Вернуть реферала <?=$ref["user"];?> с ярмарки'>
					</form>
				</div>
			</td>
		</tr>

		<tr id="exblock<?=$ref['id'];?>" style='display: none;'>
			<td class='ext' colspan='6' align='center'>
				<div class='goexchangeblock'>
					<form action='' method='post'>
						<input type='hidden' name='idref' value="<?=$ref['id'];?>">
						<input type="hidden" name="user" maxlength="30" value="<?=$ref["user"];?>">
						<input type='text' name='price' size='10' maxlength="5" placeholder="Ваша цена ?" value=''>
						<input type='submit' name="submit" value='Продать'>
					</form>
					<br/><br/><br/>
				</div>
			</td>
		</tr>

		<?PHP
		$all_money += $ref["to_referer"];
		}

	}else echo '<tr><td align="center" colspan="6">У вас нет рефералов</td></tr>'
  ?>

</tbody>
</table>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
</div>