<?php 
$_OPTIMIZATION["title"] = "Мой автопарк";
$usid = $_SESSION["user_id"];
$refid = $_SESSION["referer_id"];
$usname = $_SESSION["user"];

$db->Query("SELECT * FROM db_users_b WHERE id = '$usid' LIMIT 1");
$user_data = $db->FetchArray();

$db->Query("SELECT * FROM db_config WHERE id = '1' LIMIT 1");
$sonfig_site = $db->FetchArray();
?>

<div class="page-content-wrapper ">

<div>
        <table style="width:100%; text-align: left;">
        <tbody><tr>
            <td style="width: 50%; height:10px;">
                <div class="bn_head">
                    <div id="linkslot_223774"><script src="https://linkslot.ru/bancode.php?id=223774" async></script></div> 
                </div>
            </td>
            <td style="width: 50%; height:10px;">
            <div class="bn_head">
                <div id="linkslot_224396"><script src="https://linkslot.ru/bancode.php?id=224396" async></script></div>
            </div>
            </td>
			<td style="width: 50%; height:10px;">
            <div class="bn_head">
                <div id="linkslot_224413"><script src="https://linkslot.ru/bancode.php?id=224413" async></script></div>
            </div>
            </td>
        </tr>
        </tbody></table>
    </div>
    <BR></BR>
    <div class="container">

        <div class="row">
            <div class="col-md-12">

                <?php
$array_items = array(
                1 => "a_t",
                2 => "b_t",
                3 => "c_t",
                4 => "d_t",
                5 => "e_t",
                6 => "f_t",
                7 => "g_t",
                8 => "h_t",
                9 => "j_t",
);

$arr_items = array(
                1 => "a",
                2 => "b",
                3 => "c",
                4 => "d",
                5 => "e",
                6 => "f",
                7 => "g",
                8 => "h",
                9 => "j",
);

$array_name = array(
            1 => "Hyundai Solaris",
            2 => "Volkswagen Beetle",
            3 => "Toyota Camry",
            4 => "BMW 530i",
            5 => "Audi Q7",
            6 => "Mercedes-Benz SLS AMG",
            7 => "Porsche 991 Cabrio",
            8 => "Tesla Model S",
            9 => "Ferrari F12",
);

# Покупка новой машины
if(isset($_POST["item"])){


    $item = intval($_POST["item"]);
    $citem = $array_items[$item];

    if(strlen($citem) >= 3){

        # Проверяем средства пользователя
        $need_money = $sonfig_site["amount_".$citem];
        if($need_money <= $user_data["money_b"]){

            if($user_data["last_sbor"] == 0 OR $user_data["last_sbor"] > ( time() - 600) ){

                $to_referer = $need_money * 0.1;

                # Добавляем строения и списываем деньги
                $db->Query("UPDATE db_users_b SET money_b = money_b - $need_money, $citem = $citem + 1,  
                last_sbor = IF(last_sbor > 0, last_sbor, '".time()."') WHERE id = '$usid'");

                # Даем энергию пользователю 50% от стоимости
                $energy = $need_money * 0.005;
                $db->Query("UPDATE db_users_b SET pay_points = pay_points + '$energy' WHERE id = '$usid'");

                # Вносим запись о покупке
                $db->Query("INSERT INTO db_stats_btree (user_id, user, tree_name, amount, date_add, date_del) 
                VALUES ('$usid','$usname','".$array_name[$item]."','$need_money','".time()."','".(time()+60*60*24*15)."')");
                #

                #echo "<div class='alert alert-success'> <b>Вы успешно купили машину ".$array_name[$item].".</b></div>";
                echo $func->error("Вы успешно купили машину ".$array_name[$item], true);

                header( 'Refresh: 3; url=/user/carpark' );

                $db->Query("SELECT * FROM db_users_b WHERE id = '$usid' LIMIT 1");
                $user_data = $db->FetchArray();


            }else echo "<center><div class='alert error'>Перед тем как купить машинку, следует СНЯТЬ ДЕНЬГИ С КАССЫ  !!!</div></center><BR />";

        }else echo $func->error("Недостаточно денег на счёте для ПОКУПОК.");
    }

}

//$lvl1 = (($sonfig_site["a_in_h"] * 24) * 30)*10; // окупаемость
// $lvl1 = $sonfig_site["a_in_h"]/$sonfig_site["amount_a_t"]*24*30*100;
// $lvl2 = $sonfig_site["b_in_h"]/$sonfig_site["amount_b_t"]*24*30*100;
// $lvl3 = $sonfig_site["c_in_h"]/$sonfig_site["amount_c_t"]*24*30*100;
// $lvl4 = $sonfig_site["d_in_h"]/$sonfig_site["amount_d_t"]*24*30*100;
// $lvl5 = $sonfig_site["e_in_h"]/$sonfig_site["amount_e_t"]*24*30*100;
// $lvl6 = $sonfig_site["f_in_h"]/$sonfig_site["amount_f_t"]*24*30*100;


//$lvl6= ($sonfig_site["f_in_h"]*100)/$sonfig_site["amount_f_t"]/$sonfig_site["items_per_coin"]*24*30; // окупаемость

?>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12 col-lg-6">
                    <div class="row">
                        <div class="col-md-12">
                            <?php
                                include '_claim.php';
                            ?>
                        </div>

                        <div class="col-md-12">
                            <div class="panel text-center">
                                <div class="panel-heading">
                                    <h4 class="panel-title text-muted font-light profilemsz"> <i>Машины в Вашем автопарке</i>
                                    </h4>
                                </div>
                                <div class="panel-body p-t-10">
                                    <div class="row">
                                        <?php 

                                        for ($i=1; $i < 6; $i++) { 
                                            if ($user_data[$array_items[$i]] >= 1) {
                                                $all = $user_data[$array_items[$i]];
                                                for ($j = 0; $j < $all; $j++) {
                                                    echo '<div class="col-lg-2 col-sm-2 col-xs-2">
                                                        <img src="/img/cars/n'.$i.'.png" class="profilecarimg">
                                                    </div>';
                                                }
                                                
                                                
                                            };
                                        }
                                        
                                        ?>
                                        <!-- <table class="table table-bordered">
                                        <thead>
                                            <th>Название</th>
                                            <th>Осталось дней</th>
                                        </thead>
                                        <?php /*$life_time->GetTable($usid);*/ ?></table>
                                    -->
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="panel panel-color panel-warning">
                            <div class="panel-heading">
                                <h3 class="panel-title carsinfoblockh3">Описание игрового процесса</h3>
                            </div>
                            <div class="panel-body p-t-10">
                                <h4 class="carsinfoh4">Автопарк, машины и скорость заработка:</h4>
                                <p class="carsinfop">
                                    Чем больше машин в Вашем автопарке, тем больше доход он приносит. Основная единица измерения дохода в AvtoGame это "скорость заработка". У каждой из представленных машин своя скорость заработка, которая измеряется в количестве заработанных машиной рублей за час реального времени.!
                                </p>
                                <h4 class="carsinfoh4">Способы заработка на проекте AvtoGame:</h4>
                                <p class="carsinfop">
                                    Если вы не хотите покупать машины, то мы предлагаем Вам заработать следующими способами:
                                </p>
                                <p class="carsinfop" style="padding-left:20px;">
                                    <a href="/user/serfing">Сёрфинг сайтов</a>
                                    - смотрите сайты наших рекламодателей и получайте до 0,07 руб за один просмотр!
                                </p>
                                <!--<p class="carsinfop" style="padding-left:20px;">
                                <a href="">Линия удачи</a>
                                ,
                                <a href="">Одно из трех</a>
                                ,
                                <a href="">Великая битва</a>
                                - азартные игры с другими пользователями проекта.
                            </p>
                            -->
                            <p class="carsinfop" style="padding-left:20px;">
                                <a href="/user/partnership">Партнерская программа</a>
                                - реф.прогамма на сёрфинг и бонусы 100%.
                            </p>
                            <p class="carsinfop" style="padding-left:20px;">
                                <a href="/user/daily">Ежедневный бонус</a>
                                - получайте призы и бонусы за свою активность на проекте!
                            </p>						
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <div class="col-md-12 col-lg-6">
            <div class="row">
                <?php
                for ($i=1; $i < 10; $i++) {

                    echo'
                    <div class="col-sm-12 col-sm-6">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h3 class="panel-title text-center">'.$array_name[$i].'</h3>
                            </div>
                            <div class="panel-body">
                                <div class="carsbuydiv">
                                    <img src="/img/cars/n'.$i.'.png"></div>
                                <h5 class="profileinfoh5">
                                    Стоимость:
                                    <span>'.$sonfig_site["amount_".$array_items[$i]].' руб.</span>
                                </h5>
                                <h5 class="profileinfoh5">
                                    Доходность:
                                    <span>'.ceil($sonfig_site[$arr_items[$i]."_in_h"]/$sonfig_site["amount_".$array_items[$i]]*24*30*100).'% / мес.</span>
                                </h5>
                                <h5 class="profileinfoh5">
                                    Скорость:
                                    <span>'.$sonfig_site[$arr_items[$i]."_in_h"].' ₽ / час</span>
                                </h5>

                                <form action="/user/carpark?shop" method="post">
                                    <input type="hidden" name="item" value="'.$i.'">
                                    <button type="submit" class="btn waves-effect btn-default btn-block carsshopbtn">
                                    <i class="mdi mdi-cart"></i>
                                        Купить машину ('.$sonfig_site["amount_".$array_items[$i]].'р.)
                                    </button>
                                </form>

                            </div>
                        </div>
                    </div>';
                }
                ?>
            </div>
        </div>
    </div>
    <!-- end row -->

</div>
<!-- container -->

</div>
<!-- Page content Wrapper -->
<link href="/style/sweet-alert.css" rel="stylesheet" type="text/css">
<!-- <script src="/js/sweet-alert.min.js"></script> -->

</div>
<!-- content -->