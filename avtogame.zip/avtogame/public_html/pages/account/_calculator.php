<?php 
$_OPTIMIZATION["title"] = "Калькулятор дохода";
?>
<script>
var cars=[];
    cars[0]=0.0034;
    cars[1]=0.018;
    cars[2]=0.093;
    cars[3]=0.38;
    cars[4]=1.2;
    cars[5]=3.22;
    cars[6]=5.55;
    cars[7]=9.16;
    cars[8]=24.3;
    cars[9]=2.12;
    cars[10]=2.12;
  
function number_format( number, decimals, dec_point, thousands_sep ) {  // Format a number with grouped thousands
    //
    // +   original by: Jonas Raoni Soares Silva (http://www.jsfromhell.com)
    // +   improved by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
    // +     bugfix by: Michael White (http://crestidg.com)

    var i, j, kw, kd, km;

    // input sanitation & defaults
    if( isNaN(decimals = Math.abs(decimals)) ){
        decimals = 2;
    }
    if( dec_point == undefined ){
        dec_point = ",";
    }
    if( thousands_sep == undefined ){
        thousands_sep = ".";
    }

    i = parseInt(number = (+number || 0).toFixed(decimals)) + "";

    if( (j = i.length) > 3 ){
        j = j % 3;
    } else{
        j = 0;
    }

    km = (j ? i.substr(0, j) + thousands_sep : "");
    kw = i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + thousands_sep);
    //kd = (decimals ? dec_point + Math.abs(number - i).toFixed(decimals).slice(2) : "");
    kd = (decimals ? dec_point + Math.abs(number - i).toFixed(decimals).replace(/-/, 0).slice(2) : "");


    return km + kw + kd;
}


function calculate() {
  var h1=0;
  var h24=0;
  var d30=0;
  var d365=0;
  for(var i=0;i<9;i++) {
    h1+=cars[i]*parseInt($("#car"+i).val());
    h24+=cars[i]*parseInt($("#car"+i).val())*24;
    d30+=cars[i]*parseInt($("#car"+i).val())*24*30;
    d365+=cars[i]*parseInt($("#car"+i).val())*24*365;
  }
  $("#dhd1").html(number_format(h1, 4, '.', ' ')+"₽");
  $("#dhd2").html(number_format(h24, 3, '.', ' ')+"₽");
  $("#dhd3").html(number_format(d30, 2, '.', ' ')+"₽");
  $("#dhd4").html(number_format(d365, 0, '.', ' ')+"₽");
}
setTimeout(calculate, 500);
</script>

<div class="page-content-wrapper ">
    <div class="container">
        <div class="row">
            <div class="col-lg-9 partner_cl">
                <div class="panel panel-primary">
                    <div class="panel-body">
                        <p class="raceinfotext">
                            Калькулятор дохода служит для расчета Вашей прибыли от машин в автопарке. <b>Калькулятор не учитывает возможные бонусы, ускорения заработка от
                                <a>Гонки лидеров</a>
                                а так же реферальные вознаграждения.</b> 
                            Калькулятор считает только чистую прибыль за час, сутки, месяц и год согласно скорости заработка каждой из автомашин Вашего автопарка.
                        </p>
                        <hr>
                        <div class="ideas_coment text-center">Введите необходимое кол-во машин для расчета:</div>
                        <hr class="m-b-10">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label class="control-label">Машина 1 ур.</label>
                                    <input id="car0" class="vertical-spin form-control" type="text" value="1" name="vertical-spin">
                                </div>
                                <div class="form-group">
                                    <label class="control-label">Машина 2 ур.</label>
                                    <input id="car1" class="vertical-spin form-control" type="text" value="0" name="vertical-spin"></div>
                                <div class="form-group">
                                    <label class="control-label">Машина 3 ур.</label>
                                    <input id="car2" class="vertical-spin form-control" type="text" value="0" name="vertical-spin"></div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label class="control-label">Машина 4 ур.</label>
                                    <input id="car3" class="vertical-spin form-control" type="text" value="0" name="vertical-spin"></div>
                                <div class="form-group">
                                    <label class="control-label">Машина 5 ур.</label>
                                    <input id="car4" class="vertical-spin form-control" type="text" value="0" name="vertical-spin"></div>
                                <div class="form-group">
                                    <label class="control-label">Машина 6 ур.</label>
                                    <input id="car5" class="vertical-spin form-control" type="text" value="0" name="vertical-spin"></div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label class="control-label">Машина 7 ур.</label>
                                    <input id="car6" class="vertical-spin form-control" type="text" value="0" name="vertical-spin"></div>
                                <div class="form-group">
                                    <label class="control-label">Машина 8 ур.</label>
                                    <input id="car7" class="vertical-spin form-control" type="text" value="0" name="vertical-spin"></div>
                                <div class="form-group">
                                    <label class="control-label">Машина 9 ур.</label>
                                    <input id="car8" class="vertical-spin form-control" type="text" value="0" name="vertical-spin"></div>
                            </div>
                        </div>
                        <div class="text-center m-t-10">
                            <button type="button" class="btn waves-effect btn-primary btn-block calc_btn" style="width:300px;" onclick="calculate();"> <i class="fa fa-calculator"></i>
                                Рассчитать доход
                            </button>
                        </div>
                        <div class="row">
                            <div class="col-md-4 col-md-offset-4 p-t-10">
                                <div class="calc_resultline">
                                    Доход за 1 час:
                                    <div id="dhd1">0₽</div>
                                </div>
                                <div class="calc_resultline">
                                    Доход за 24 часа:
                                    <div id="dhd2">0₽</div>
                                </div>
                                <div class="calc_resultline">
                                    Доход за 30 дней:
                                    <div id="dhd3">0₽</div>
                                </div>
                                <div class="calc_resultline">
                                    Доход за 365 дней:
                                    <div id="dhd4">0₽</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>