<?php
$_OPTIMIZATION["title"] = "Пополнить баланс";
$usid = $_SESSION["user_id"];
$usname = $_SESSION["user"];

$db->Query("SELECT * FROM db_config WHERE id = '1' LIMIT 1");
$sonfig_site = $db->FetchArray();

?>
<script>
var astype=['',
    '1',
    '13',
    '3',
    '8',
    '-',
    '6',
    '14',
    '2',
    '2',
    '3',
    '3',
    '13',

    '15',
    '15',
    '15',
    '15',

    '13',
    '-',
    '14',
    '2',

    '13',
    '13',
    '14',
    '14',
    '13',

    '14',
    '14',
    '14',
    '14',

    '14',
    '14',
    '14',
    '14',
    '13'
];
function changePS(data) {
    var psid=$(data).find("img").attr('src');
    $("#mps").attr('src', psid);
    $("#mname").html($(data).find(".insert-two-ps-block-footer").html());
    psid=psid.replace("/img/ps2/", "");
    psid=psid.replace(".png", "");
    //alert(psid);
    $("#mform").attr('action', '/ajax/insert.php?type='+astype[psid]);
}

</script>

<article class="rs-content-wrapper">
    <div class="rs-content">
        <div class="rs-inner">

            <style>
            .insert-two-title{font-family: 'Montserrat', sans-serif;font-weight:300;margin-bottom:0;font-size:16px;letter-spacing:0.5px;text-transform:uppercase;margin-top:40px;}
            .insert-two-title:first-child{margin-top:0;}
            .insert-two-title-line{display:block;border-bottom:1px solid #f6f6f6;position:relative;width:100%;max-width:230px;margin-top:5px;}
            .insert-two-ps-block{width: 170px;height: auto;border-radius: 2px; margin-top: 15px;display: inline-block;margin-right: 16px;}
            .insert-two-ps-block:hover .insert-two-ps-block-img{box-shadow: 0 0 5px #ff8d0040;background:#fffdf8;}
            .insert-two-ps-block-img{padding: 10px;max-height: 65px;min-height: 58px;text-align: center;}
            .insert-two-ps-block-img img{max-width: 100%; max-height: 35px; -webkit-transition: 333ms ease-in-out; transition: 333ms ease-in-out; vertical-align: text-top;}
            .insert-two-ps-block-footer{padding:2px;text-align:center;color:#fff;font-family: 'Montserrat', sans-serif;font-weight:300;letter-spacing:1px;font-size:12px;}
            .insert-two-ps-block:hover .insert-two-ps-block-img img {-webkit-transform: scale(0.9);-ms-transform: scale(0.9);transform: scale(0.9);}
            .psactive .insert-two-ps-block-footer{background:#ff8c00;}
            .psdisactive .insert-two-ps-block-footer{background:#b7b7b7;}
            .btn-insertnew{font-family: 'Montserrat', sans-serif; text-transform: uppercase; font-size: 11px; letter-spacing: 1px; font-weight: 700;}
            </style>

            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-9 partner_cl">
                        <div class="row">
                            <?php 
                            if (strlen($config->TextInsert) >= 2) {
                            ?>
                            <div class="col-md-12">
                                <div class="panel garden_glpanel" style="margin-bottom:10px;">
                                    <div class="panel-body" style="padding: 10px;">
                                        <h4 style="color:#bf0202;font-family: 'Montserrat', sans-serif; letter-spacing:1px;text-align:center;">
                                            <?=$config->TextInsert?>
                                        </h4>
                                    </div>
                                </div>
                            </div>
                            <?php
                            }
                            ?>

                            <div class="col-md-12">
                                <div class="panel garden_glpanel">
                                    <div class="panel-body">
                                        <h3 class="insert-two-title">
                                            Платежные системы
                                            <div class="insert-two-title-line"></div>
                                        </h3>
                                        <a class="psactive" style="cursor:pointer;" data-toggle="modal" data-target=".psystem1">
                                            <div class="insert-two-ps-block">
                                                <div class="insert-two-ps-block-img">
                                                    <img src="/img/ps2/1.png"></div>
                                                <div class="insert-two-ps-block-footer">PAYEER</div>
                                            </div>
                                        </a>
                                        <!--<a class="psactive" style="cursor:pointer;" data-toggle="modal" data-target=".psystem1">
                                            <div class="insert-two-ps-block">
                                                <div class="insert-two-ps-block-img">
                                                    <img src="/img/ps2/2.png"></div>
                                                <div class="insert-two-ps-block-footer">Yandex.Money</div>
                                            </div>
                                        </a>-->
                                        <!--<a class="psactive" style="cursor:pointer;" data-toggle="modal" data-target=".psystem1">
                                            <div class="insert-two-ps-block">
                                                <div class="insert-two-ps-block-img">
                                                    <img src="/img/ps2/3.png"></div>
                                                <div class="insert-two-ps-block-footer">AdvancedCash</div>
                                            </div>
                                        </a>-->
                                        <!--<a class="psactive" style="cursor:pointer;" data-toggle="modal" data-target=".psystem2">
                                            <div class="insert-two-ps-block">
                                                <div class="insert-two-ps-block-img">
                                                    <img src="/img/ps2/4.png"></div>
                                                <div class="insert-two-ps-block-footer">PerfectMoney</div>
                                            </div>
                                        </a>-->

                                        <!--<a class="psactive" style="cursor:pointer;" data-toggle="modal" data-target=".psystem1">
                                            <div class="insert-two-ps-block">
                                                <div class="insert-two-ps-block-img">
                                                    <img src="/img/ps2/6.png"></div>
                                                <div class="insert-two-ps-block-footer">QIWI Кошелек</div>
                                            </div>
                                        </a>-->

                                        <!--<a class="psactive" style="cursor:pointer;" data-toggle="modal" data-target=".psystem1">
                                            <div class="insert-two-ps-block">
                                                <div class="insert-two-ps-block-img">
                                                    <img src="/img/ps2/20.png">
                                                </div>
                                                <div class="insert-two-ps-block-footer">Free-Kassa</div>
                                            </div>
                                        </a>-->

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</article>

<div class="modal fade psystem1" tabindex="-1" role="dialog" aria-labelledby="psystem1" aria-hidden="true">
    <div class="modal-dialog modal-sm" style="margin-top: 150px;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h4 class="modal-title" id="psystem1">
                    Пополнение баланса
                    <span id="iid"></span>
                </h4>
            </div>
            <div class="modal-body text-center">
                <img id="mps" src="/img/ps2/1.png">
                <form action="" id="mform" method="post" style="margin-top:10px;" autocomplete="off">
                    <div class="form-group">
                        <label style="letter-spacing: 0.5px; font-family: Montserrat; font-size: 11px; text-align: left; margin-bottom: 0px;">Введите сумму пополнения: (руб.)</label>
                        <div>
                            <input name="sum" type="text" minlength="1" maxlength="9" class="form-control" placeholder="" required>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary waves-effect waves-light btn-block btn-insertnew">Пополнить баланс</button>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="modal fade psystem2" tabindex="-1" role="dialog" aria-labelledby="psystem2" aria-hidden="true">
    <div class="modal-dialog modal-sm" style="margin-top: 150px;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h4 class="modal-title" id="psystem2">
                    Пополнение баланса
                    <span id="iid"></span>
                </h4>
            </div>
            <div class="modal-body text-center">
                <img id="mps" src="/img/ps2/4.png">
                <form method="post" action="https://perfectmoney.is/api/step1.asp" id="perfect" method="post" style="margin-top:10px;">
                    <input type="hidden" name="PAYEE_ACCOUNT" value="<?=$config->AccountNumberPM?>">
                    <input type="hidden" name="PAYEE_NAME" value="<?=$config->StoreName?>">
                    <input type="hidden" name="PAYMENT_ID" id="PAYMENT_ID">
                    <input type="hidden" name="PAYMENT_AMOUNT" id="PAYMENT_AMOUNT">
                    <input type="hidden" name="PAYMENT_UNITS" value="USD">
                    <input type="hidden" name="STATUS_URL" value="<?=$config->SaitUrlStatus?>/perfectmoney">
                    <input type="hidden" name="PAYMENT_URL" value="<?=$config->SaitUrlStatus?>/success.php">
                    <input type="hidden" name="PAYMENT_URL_METHOD" value="POST">
                    <input type="hidden" name="NOPAYMENT_URL" value="<?=$config->SaitUrlStatus?>/fail.php">
                    <input type="hidden" name="NOPAYMENT_URL_METHOD" value="POST">
                    <div class="form-group">
                        <label style="letter-spacing: 0.5px; font-family: Montserrat; font-size: 11px; text-align: left; margin-bottom: 0px;">Введите сумму пополнения: (руб.)</label>
                        <div>
                            <input name="sum" id="sum" type="text" minlength="1" maxlength="9" class="form-control" placeholder="" required></div>
                    </div>
                    <button type="button" class="btn btn-primary waves-effect waves-light btn-block" id="subm">Пополнить баланс</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    $("a.psactive").click(function(){changePS(this);});
</script>

<script>
$("#subm").click(function() {
    var sum=$("#sum").val();
    if(isNaN(sum)) {
        swal({
            type: "warning",
            title: "Ошибка!",
            text: "Сумма должна быть числом",
            timer: 5000,
            showConfirmButton: true
        });
    }
    else
    {
        if(sum<1) {
            swal({
                type: "warning",
                title: "Ошибка!",
                text: "Сумма должна быть больше 1 руб.",
                timer: 5000,
                showConfirmButton: true
            });
        }
        else
        {
            $.post("/ajax/insert.php?type=8", {sum: $("#sum").val()}).
            done(function(data) {
                var split=data.split(";");
                //console.log(split);
                $("#PAYMENT_ID").val(split[0]);
                $("#PAYMENT_AMOUNT").val(split[1]);
                $("#perfect").submit();
            });
        }
    }
});
</script>