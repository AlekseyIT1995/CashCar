<?php
$_OPTIMIZATION["title"] = "Обмен валюты на рекламный баланс";
$usid = $_SESSION["user_id"];
$usname = $_SESSION["user"];

$db->Query("SELECT * FROM db_users_b WHERE id = '$usid' LIMIT 1");
$user_data = $db->FetchArray();

$db->Query("SELECT * FROM db_config WHERE id = '1' LIMIT 1");
$sonfig_site = $db->FetchArray();
?>  
<div class="page-content-wrapper ">

    <div class="container">
<?php

if(isset($_POST["swap"])){

    $sum = intval($_POST["sum"]);
    $sum = (int)$_POST["sum"];

    if($sum >= $config->minSumSwap){
		
		$ps = (int)$_POST["ps"];
		if ($ps == 1) {
			$money = 'money_p';
		}elseif ($ps == 2) {
			$money = 'money_b';
		}else{
			$money = false;
		}
    
        if($user_data[$money] >= $sum AND $sum >= $config->minSumSwap){
        
            $add_sum = ($sonfig_site["percent_swap"] > 0) ? ( ($sonfig_site["percent_swap"] / 100) * $sum) + $sum : $sum;
            
            $ta = time();
            $td = $ta + 60*60*24*15;

            if ($ps != false AND is_numeric($ps)) {

                $db->Query("UPDATE db_users_b SET serf = serf + $add_sum, {$money} = {$money} - $sum WHERE id = '$usid'");
                $db->Query("INSERT INTO db_swap_ser (user_id, user, amount_b, amount_p, date_add, date_del) VALUES ('$usid','$usname','$add_sum','$sum','$ta','$td')");
                
                echo $func->error("Обмен произведен!", true);

            }
        
        }else echo $func->error("Недостаточно руб. для обмена");
    
    }else echo $func->error("Минимальная сумма для обмена ".$config->minSumSwap." руб.");

}

?>
    <div class="row">
        <div class="col-lg-9 partner_cl">
            <div class="row">
                <div class="col-sm-6 col-lg-6">
                    <div class="panel panel-warning">
                        <div class="panel-heading">
                            <h3 class="panel-title racetabletitle" style="color: #fff7ea;text-shadow: 1px 1px 3px #6b470b;"><i class="fa fa-refresh"></i> Обмен с баланса ВЫВОДА/ПОКУПКИ на РЕКЛАМНЫЙ БАЛАНС</h3>
                        </div>
                        <div class="panel-body">
                            <center><img class="exchange_img" src="/img/exchange2.png"></center>
                            <blockquote class="m-t-15"><p class="exchange_desctext">Выберите счёт с которого будет пополнен РЕКЛАМНЫЙ БАЛАНС , укжите сумму и нажмите пополнить. Мин. сумма: 20 руб.</p> <footer>Описание направления обмена.</footer></blockquote>
                            <form action="/user/adv_balance?ok" method="post">
                                <div class="form-group exchange_formelem">
                                    <select name="ps" class="form-control">
                                        <option value="1" selected="select">С вывода</option>
                                        <option value="2">С покупок</option>
                                    </select>
                                    <input name="sum" id="sum" onkeyup="GetSumPer();" maxlength="7" class="form-control" placeholder="Введите сумму обмена... (руб.)" required="" type="text">
                                    <button type="submit" name="swap" class="btn waves-effect btn-default btn-block m-t-10"> <i class="mdi mdi-call-split"></i> Пополнить рекламный баланс</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div><!-- end row -->
        </div>
    </div>

    </div><!-- container -->

</div>
<script language="javascript">GetSumPer();</script>