<?php
$_OPTIMIZATION["title"] = "Заказ выплаты";
$user_id = $_SESSION["user_id"];
$usname = $_SESSION["user"];

$db->Query("SELECT * FROM db_users_b WHERE id = '$user_id' LIMIT 1");
$user_data = $db->FetchArray();

$db->Query("SELECT * FROM db_config WHERE id = '1' LIMIT 1");
$config_site = $db->FetchArray();

$status_array = array( 0 => "Проверяется", 1 => "Выплачивается", 2 => "Отменена", 3 => "Выплачено");

$array = array('salt' => 'solsalt', 
               'key' => 'XrenVamVsemvStakanOtAPTEMOHa',
                );
$tokenMy = hash('sha256', implode(":", $array));

$userAgent = isset($_SERVER['HTTP_USER_AGENT'])
               ? strtolower($_SERVER['HTTP_USER_AGENT'])
               : '';

$seed = $_SESSION['csrf_seed'] = mt_rand(0, PHP_INT_MAX);
$token = md5($seed.$userAgent.$_SERVER['REMOTE_ADDR'].$tokenMy);

# Минималка РУБ!
$minPay = 1;

?>
<style>
body{background:#f3f2f0 !important;}
.insert_box{padding: 10px;border-radius: 10px;-moz-box-shadow: 0 1px 2px 0 rgba(0,0,0,.14);-webkit-box-shadow: 0 1px 2px 0 rgba(0,0,0,.14);box-shadow: 0 1px 2px 0 rgba(0,0,0,.14);}
.insert_new_btn {
    color: #fff;
    font-weight: 700;
    border: none;
    border-top-right-radius: 50px;
    border-bottom-right-radius: 50px;
    border-bottom-left-radius: 50px;
    border-top-left-radius: 50px;
    outline: none;
    -webkit-transition: 333ms ease-in-out;
    transition: 333ms ease-in-out;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    padding: 10px 38px 10px;
    margin-top:10px;
    font-size: 15px;
    letter-spacing:1px;
    background-color: #ff8c00;
    -webkit-box-shadow: 0 10px 15px 0 rgba(255,140,0,.2);
    box-shadow: 0 7px 15px 0 rgba(255,140,0,.2);
    text-shadow: 1px 1px #de7a00;
}
.insert_new_input{border-radius: 50px;letter-spacing: 1px;text-align: center;background-color: #fdfdfd;height: 41px;font-size: 13px;}
.insert_new_input:focus::-webkit-input-placeholder {color: transparent}
.insert_new_input:focus::-moz-placeholder          {color: transparent}
.insert_new_input:focus:-moz-placeholder           {color: transparent}
.insert_new_input:focus:-ms-input-placeholder      {color: transparent}
.insert_new_btn:hover{color:#fff !important;-webkit-transition:133ms ease-in-out;transition:133ms ease-in-out-webkit-box-shadow:0 7px 30px 0 rgba(255,140,0,.4));box-shadow:0 7px 30px 0 rgba(255,140,0,.4);}
.insert_new_btn:active{color:#fff !important;}
.insert_new_btn:focus{color:#fff !important;}
@media (min-width: 1200px) and (max-width: 1470px) {.insert_new_btn{font-size: 13px;padding: 10px 0px 10px;}}
.balancei_form {
    margin-top: 20px;
}
</style>
<div class="page-content-wrapper ">

    <div class="container">

        <div class="row">

            <div class="col-sm-12 col-lg-12">
                <div class="panel text-center exchange_panel">
                    <div class="panel-body">
                    <h3 style="text-align:center;font-family: Montserrat;font-weight:500;">Ещё нет кошелька ? Регистрация - <a href="https://payeer.com/0393115" target="_blank" >PAYEER </a> </h3>
                    </div>
                </div>
            </div>
            <?php
            #$arrImgPay = array("pb_logo","ym_logo","qiwi_logo","adv_logo","pm_logo","card_logo","wm_logo","okpay_logo","bl_logo","t2_logo","mts_logo","mg_logo","card_logo");
            $arrImgPay = array("pb_logo");

            #for ($i=1; $i < 13; $i++) { 
            for ($i=1; $i < 2; $i++) { 
                //echo $i;
            ?>
            <div class="col-sm-6 col-lg-3">
                <div class="panel text-center insert_box">
                    <div class="panel-body p-t-20">
                        <img class="balancei_psimg m-b-5" src="/img/ps/<?=$arrImgPay[($i-1)]?>.png">
                        <form class="balancei_form">
                            <div class="form-group m-b-0">
                                <?php
                                if ($arrImgPay[($i-1)] == 'pm_logo' OR $arrImgPay[($i-1)] == 'okpay_logo') {
                                    echo '<button type="button" disabled="" class="btn waves-light btn-block balancei_btngo insert_new_btn"><i class="fa fa-credit-card"></i> Временно недоступно </button>';
                                }else{ 
                                ?>
                                <button onclick="changePS(<?=$i?>);" type="button" class="btn waves-light btn-block balancei_btngo insert_new_btn" data-toggle="modal" data-target="#paymodal_1">
                                    <i class="fa fa-credit-card"></i> Заказать выплату
                                </button>
                                <?php } ?>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php
            } 
            ?>
            <!-- <div class="col-sm-6 col-lg-3">
                <div class="panel text-center insert_box">
                    <div class="panel-body p-t-20">
                        <img class="balancei_psimg m-b-5" src="assets/ps/ym_logo.png">
                        <form class="balancei_form">
                            <div class="form-group m-b-0">
                                <button onclick="changePS(2);" type="button" class="btn waves-light btn-block balancei_btngo insert_new_btn" data-toggle="modal" data-target="#paymodal_1"> <i class="fa fa-credit-card"></i>
                                    Заказать выплату
                                </button>

                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-lg-3">
                <div class="panel text-center insert_box">
                    <div class="panel-body p-t-20">
                        <img class="balancei_psimg m-b-5" src="assets/ps/qiwi_logo.png">
                        <form class="balancei_form">
                            <div class="form-group m-b-0">

                                <button onclick="changePS(3);" type="button" class="btn waves-light btn-block balancei_btngo insert_new_btn" data-toggle="modal" data-target="#paymodal_1">
                                    <i class="fa fa-credit-card"></i>
                                    Заказать выплату
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-lg-3">
                <div class="panel text-center insert_box">
                    <div class="panel-body p-t-20">
                        <img class="balancei_psimg m-b-5" src="assets/ps/adv_logo.png">
                        <form class="balancei_form">
                            <div class="form-group m-b-0">
                                <button onclick="changePS(4);" type="button" class="btn waves-light btn-block balancei_btngo insert_new_btn" data-toggle="modal" data-target="#paymodal_1">
                                    <i class="fa fa-credit-card"></i>
                                    Заказать выплату
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-lg-3">
                <div class="panel text-center insert_box">
                    <div class="panel-body p-t-20">
                        <img class="balancei_psimg m-b-5" src="assets/ps/pm_logo.png">
                        <form class="balancei_form">
                            <div class="form-group m-b-0">
                                <button type="button" disabled class="btn waves-light btn-block balancei_btngo insert_new_btn">
                                    <i class="fa fa-credit-card"></i>
                                    Временно недоступно
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-lg-3">
                <div class="panel text-center insert_box">
                    <div class="panel-body p-t-20">
                        <img class="balancei_psimg m-b-5" src="assets/ps/card_logo.png">
                        <form class="balancei_form">
                            <div class="form-group m-b-0">
                                <button onclick="changePS(13);" type="button" class="btn waves-light btn-block balancei_btngo insert_new_btn" data-toggle="modal" data-target="#paymodal_1">
                                    <i class="fa fa-credit-card"></i>
                                    Заказать выплату
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-lg-3">
                <div class="panel text-center insert_box">
                    <div class="panel-body p-t-20">
                        <img class="balancei_psimg m-b-5" src="assets/ps/wm_logo.png">
                        <form class="balancei_form">
                            <div class="form-group m-b-0">
                                <button onclick="changePS(7);" type="button" class="btn waves-light btn-block balancei_btngo insert_new_btn" data-toggle="modal" data-target="#paymodal_1">
                                    <i class="fa fa-credit-card"></i>
                                    Заказать выплату
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-lg-3">
                <div class="panel text-center insert_box">
                    <div class="panel-body p-t-20">
                        <img class="balancei_psimg m-b-5" src="assets/ps/okpay_logo.png">
                        <form class="balancei_form">
                            <div class="form-group m-b-0">

                                <button type="button" disabled class="btn waves-light btn-block balancei_btngo insert_new_btn">
                                    <i class="fa fa-credit-card"></i>
                                    Временно недоступно
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-lg-3">
                <div class="panel text-center insert_box">
                    <div class="panel-body p-t-20">
                        <img class="balancei_psimg m-b-5" src="assets/ps/bl_logo.png">
                        <form class="balancei_form">
                            <div class="form-group m-b-0">
                                <button onclick="changePS(9);" type="button" class="btn waves-light btn-block balancei_btngo insert_new_btn" data-toggle="modal" data-target="#paymodal_1">
                                    <i class="fa fa-credit-card"></i>
                                    Заказать выплату
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-lg-3">
                <div class="panel text-center insert_box">
                    <div class="panel-body p-t-20">
                        <img class="balancei_psimg m-b-5" src="assets/ps/t2_logo.png">
                        <form class="balancei_form">
                            <div class="form-group m-b-0">
                                <button onclick="changePS(10);" type="button" class="btn waves-light btn-block balancei_btngo insert_new_btn" data-toggle="modal" data-target="#paymodal_1">
                                    <i class="fa fa-credit-card"></i>
                                    Заказать выплату
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-lg-3">
                <div class="panel text-center insert_box">
                    <div class="panel-body p-t-20">
                        <img class="balancei_psimg m-b-5" src="assets/ps/mts_logo.png">
                        <form class="balancei_form">
                            <div class="form-group m-b-0">
                                <button onclick="changePS(11);" type="button" class="btn waves-light btn-block balancei_btngo insert_new_btn" data-toggle="modal" data-target="#paymodal_1">
                                    <i class="fa fa-credit-card"></i>
                                    Заказать выплату
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-lg-3">
                <div class="panel text-center insert_box">
                    <div class="panel-body p-t-20">
                        <img class="balancei_psimg m-b-5" src="assets/ps/mg_logo.png">
                        <form class="balancei_form">
                            <div class="form-group m-b-0">
                                <button onclick="changePS(12);" type="button" class="btn waves-light btn-block balancei_btngo insert_new_btn" data-toggle="modal" data-target="#paymodal_1">
                                    <i class="fa fa-credit-card"></i>
                                    Заказать выплату
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div> -->
        </div>

        <div class="row">
            <div class="col-lg-6 col-lg-offset-3 balancep_offset balancep_panel">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title racetabletitle">
                            <i class="fa fa-list-ul"></i>
                            Ваши последние выплаты
                        </h3>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="table-responsive">

                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th class="text-center">Дата выплаты</th>
                                                <th class="text-center">Сумма выплаты</th>
                                                <th class="text-center">Платежная система</th>
                                                <th class="text-center">Реквизиты</th>
                                                <th class="text-center">Статус</th>
                                            </tr>
                                        </thead>
                                        <tbody>
<?php
  
$db->Query("SELECT * FROM db_payment WHERE user_id = '$user_id' ORDER BY id DESC LIMIT 10");
  
    if($db->NumRows() > 0){
    
        $psSys = array("payeer","yandex","qiwi","adv","pm","card","wm","okpay","beeline","tele2","mts","megafon","card");

        while($ref = $db->FetchArray()){
        
?>
            <tr class="htt">
                <td align="center"><?=date("d.m.Y в H:i",$ref["date_add"]); ?></td>
                <td align="center"><?=sprintf("%.2f",$ref["sum"] - $ref["comission"]); ?> <?=$ref["valuta"]; ?></td>
                <td align="center"><img src="/img/ps/<?=$ref["pay_sys"]?>.png" width="25px"></td>
                <td align="center"><?=$ref["purse"]; ?></td>
                <td align="center"><?=$status_array[$ref["status"]]; ?></td>
            </tr>
<?php
        
        }
  
    }else echo '<tr class="text-center"><td align="center" colspan="5">Пока-что вы не заказали ни одной выплаты :(</td></tr>'
  
  ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div id="paymodal_1" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog balancep_modalwidth">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                        <h4 class="modal-title" id="myModalLabel">Форма заказа выплаты</h4>
                    </div>
                    <form class="balancei_form">
                        <div class="modal-body">
                            <div class="balancep_modaling">
                                <img id="imgid" src=""></div>
                            <hr class="balancep_hr">        
                            <h5 class="balancep_h5">
                                Мин. сумма:
                                <span id="minsum">15 руб.</span>
                            </h5>
                            <h5 class="balancep_h5">
                                Макс. сумма:
                                <span id="maxsum">15000 руб.</span>
                            </h5>
                            <h5 class="balancep_h5">
                                Комиссия:
                                <span id="coms">3.5%</span>
                            </h5>
                            <h5 class="balancep_h5">
                                Формат кошелька:
                                <span id="format">+7953155XXXX</span>
                            </h5>
                            <hr class="balancep_hr">        
                            <div class="form-group">
                                <input id="getsum" type="text" class="form-control balancei_input insert_new_input" onkeyup="upSum()" maxlength="5" placeholder="Введите сумму выплаты... (руб.)" required>
                            </div>
                            <div class="form-group">
                                <input id="nprs" type="text" class="form-control balancei_input insert_new_input" disabled>
                            </div>
                            <div class="form-group">
                                <input id="paypass" type="password" value="" autocomplete="new-password" name="paypass" class="form-control balancei_input insert_new_input" placeholder="Введите свой платежный пароль" required>
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control balancei_input insert_new_input" style="background-color: #fff8be;color: rgb(170, 117, 13);border: none;box-shadow: inset 0 0 4px #e0d158;text-shadow: 1px 1px 0 #fffce4;" id="scms" value="Вы получайте с учетом комиссии: 0.00" disabled>
                            </div>
                            <center id="alertc" style="display:none;">
                                <h4 style="color:#d22;font-family: Rubik;font-weight: 700;font-size: 17px;line-height: 2.0;letter-spacing: 1px;margin: 15px 0 0 0;">
                                    В данный момент выплаты доступны только РФ карты VISA и MasterCard!
                                </h4>
                            </center>
                            <center id="alertb" style="display:none;">
                                <h4 style="color:#d22;font-family: Rubik;font-weight: 700;font-size: 17px;line-height: 2.0;letter-spacing: 1px;margin: 15px 0 0 0;">
                                    Выплаты производятся через платежный шлюз в сроки от 5 минут до 3х рабочих дней
                                </h4>
                            </center>
                        </div>
                        <div class="modal-footer" style="border-top: 1px solid #f8f8f8;">
                            <button type="button" onclick="sendMoney()" class="btn waves-light btn-block balancei_btngo insert_new_btn" style="margin-top: 0;margin-bottom: 15px;">Заказать выплату</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

    </div>
</div>

<script>
var nowid=0;
var imgs = ["pb_logo","ym_logo","qiwi_logo","adv_logo","pm_logo","card_logo","wm_logo","okpay_logo","bl_logo","t2_logo","mts_logo","mg_logo","card_logo"];
var coms = [0.95, 2.9, 2.9, 2.9, 0, 0, 4.5, 4.1, 2, 2, 2, 2, "2.5% + 45 руб."];
var exmpl = ["P1000000","410011499718000","+7953155XXXX","help@AvtoGame.org","","412107XXXX785577","R123456789XXX","OK123456789","+7953155XXXX","+7953155XXXX","+7953155XXXX","+7953155XXXX","2911432072895794"];

function changePS(id) {
    nowid=id;
    $("#imgid").attr("src","/img/ps/"+imgs[(id-1)]+".png");
    $("#alertc").css("display","none");
    $("#alertb").css("display","none");

    if(id==1) {
        $("#minsum").html("1 руб.");
    }
    else if(id==2 || id==3) {
        $("#minsum").html("10 руб.");
    }
    else if(id==13 || id==6) {
        $("#minsum").html("500 руб.");
    }
    else
    {
        $("#minsum").html("15 руб.");
    }

    $("#maxsum").html("15000 руб.");

    if(id==13 || id==6) {
        $("#coms").html(coms[12]);
        $("#alertc").css("display","block");
    }
    else
    {
        $("#coms").html(coms[(id-1)]+"%");
    }

    if(id==2 || id==3) {
        $("#alertb").css("display","block");
    }

    $("#format").html(exmpl[(id-1)]);

    if(id==1) {
        $("#nprs").val("<?=(strlen($user_data['payeer']) > 2) ? $user_data['payeer'] : 'Введите свой кошелёк в настройках!'?>");
    }
    else if(id==2) {
        $("#nprs").val("<?=(strlen($user_data['yandex']) > 2) ? $user_data['yandex'] : 'Введите свой кошелёк в настройках!'?>");
    }
    else if(id==6) {
        $("#nprs").val("<?=(strlen($user_data['qiwi']) > 2) ? $user_data['qiwi'] : 'Введите свой кошелёк в настройках!'?>");
    }
    else if(id==3) {
        $("#nprs").val("<?=(strlen($user_data['advcash']) > 2) ? $user_data['advcash'] : 'Введите свой кошелёк в настройках!'?>");
    }
    else if(id==4) {
        $("#nprs").val("<?=(strlen($user_data['pm']) > 2) ? $user_data['pm'] : 'Введите свой кошелёк в настройках!'?>");
    }
    else if(id==8) {
        $("#nprs").val("<?=(strlen($user_data['visa']) > 2) ? $user_data['visa'] : 'Введите свой кошелёк в настройках!'?>");
    }
    else if(id==9) {
        $("#nprs").val("<?=(strlen($user_data['wm']) > 2) ? $user_data['wm'] : 'Введите свой кошелёк в настройках!'?>");
    }
    else if(id==7) {
        $("#nprs").val("<?=(strlen($user_data['okpay']) > 2) ? $user_data['okpay'] : 'Введите свой кошелёк в настройках!'?>");
    }
    else if(id==10) {
        $("#nprs").val("<?=(strlen($user_data['beeline']) > 2) ? $user_data['beeline'] : 'Введите свой кошелёк в настройках!'?>");
    }
    else if(id==11) {
        $("#nprs").val("<?=(strlen($user_data['tele2']) > 2) ? $user_data['tele2'] : 'Введите свой кошелёк в настройках!'?>");
    }
    else if(id==12) {
        $("#nprs").val("<?=(strlen($user_data['mts']) > 2) ? $user_data['mts'] : 'Введите свой кошелёк в настройках!'?>");
    }
    else if(id==13) {
        $("#nprs").val("<?=(strlen($user_data['megafon']) > 2) ? $user_data['megafon'] : 'Введите свой кошелёк в настройках!'?>");
    }
}

    function upSum() {
        if(nowid==13 || nowid==6) {
            scmss=number_format($("#getsum").val()*0.975-45, 2);
            if(scmss<0) {
                scmss=0.00;
            }
        }
        else
        {
            var prc=(100-coms[(nowid-1)])/100;
            scmss=number_format($("#getsum").val()*prc, 2);
        }

        $("#scms").val("Вы получайте с учетом комиссии: "+scmss);
    }

function sendMoney() {
    $.post("/ajax/pay.php?hex=<?=$token?>", {ps: nowid, sum: $("#getsum").val(), purse: $("#purse").val(), paypass: $("#paypass").val()}).
    done(function(data) {
        if(data=="success") {
            swal({
                type: "success",
                title: "Отлично!",
                text: "Выплата успешно произведена",
                timer: 5000
            });
            setTimeout(function() {
                document.location.reload(true);
            }, 3000);
        }
        else if(data=="badkey") {
            document.location.reload(true);
        }
        else
        {
          swal({
              type: "warning",
              title: "Ошибка!",
              text: data,
              timer: 5000,
              showConfirmButton: true
          });
        }
    });
}

function number_format( number, decimals, dec_point, thousands_sep ) {

    var i, j, kw, kd, km;

    // input sanitation & defaults
    if( isNaN(decimals = Math.abs(decimals)) ){
        decimals = 2;
    }
    if( dec_point == undefined ){
        dec_point = ".";
    }
    if( thousands_sep == undefined ){
        thousands_sep = " ";
    }

    i = parseInt(number = (+number || 0).toFixed(decimals)) + "";

    if( (j = i.length) > 3 ){
        j = j % 3;
    } else{
        j = 0;
    }

    km = (j ? i.substr(0, j) + thousands_sep : "");
    kw = i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + thousands_sep);
    //kd = (decimals ? dec_point + Math.abs(number - i).toFixed(decimals).slice(2) : "");
    kd = (decimals ? dec_point + Math.abs(number - i).toFixed(decimals).replace(/-/, 0).slice(2) : "");


    return km + kw + kd;
}

</script>