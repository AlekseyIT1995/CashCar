<?php
#################################################
# Модуль Биржа рефералов Новая Скрипт Fruit Farm
# Автор APTEMOH
# E-mail: anatolii.123456@yandex.ru
# Skype: ArtIncProject
# VK.com: https://vk.com/id381626457
#################################################
$_OPTIMIZATION["title"] = "Покупка свободных рефералов";
$usid = $_SESSION["user_id"];
$uname = $_SESSION["user"];

$db->Query("SELECT * FROM db_users_b WHERE id = '$usid' LIMIT 1");
$user_datab = $db->FetchArray();
?>
<style>
.buybuy{
	text-decoration:none;
	text-align:center;
	padding:0px 6px;
	border:solid 0px #fcfdfe;
	font:9px arial;
	font-weight:bold;
	color:#434f4f;
</style>
<div class="page-content-wrapper ">

    <div class="container">
        <div class="row">
            <div class="col-lg-9 partner_cl">
                <div class="panel panel-primary">
                    <div class="panel-body">
						<p class="raceinfotext">
							<ul>
							<li><span style="font-size: medium; color: #000000;"><strong>Покупая рефералов вы будете получать от них следующие ВОЗНАГРАЖДЕНИЯ:</strong></span><span> <font color="black"> </span></li>
							<li><span style="font-size: medium; color: #000000;"><strong> - 100% за каждый просмотр рекламы в "Cёрфинге сайтов" ! </strong></span><span> <font color="black"> </span></li>
							<li><span style="font-size: medium; color: #000000;"><strong> - до 0.10 руб от получения ежедневного бонуса Вашими рефералами,с каждого !</strong></span><span> <font color="black"> </span></li>
							<li><span style="font-size: medium; color: #000000;"><strong> - 5% от суммы пополнения рекламного баланса ! </strong></span><span> <font color="black"> </span></li>
							<li><span style="font-size: medium; color: #000000;"><strong> - Кнопки DESC и ASC помогут выбрать лудшего реферала ! </strong></span><span> <font color="black"> </span></li>
							<li><span style="font-size: medium; color: #ff2b2b;"><strong>Вознаграждения выплачиваются на ваш баланс для ВЫВОДА ! </strong></span><span> <font color="black"> </span></li>
							</ul>
						</p>
					</div>

                </div>
            </div>
        </div>
        <!-- end row -->
    </div><!-- container -->
</div>

            <div class="col-lg-9 partner_cl">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title racetabletitle"><i class="fa fa-list-ul"></i> Покупка свободных рефералов</h3>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="table-responsive">
								
								<table class="table">
								<thead>
								<tr>
									<th class="text-center">
										Пользователь
										<BR/>
										<a href="/user/buyref/1" class="stn-sort" <?=(isset($_GET["sort"]) AND strtolower($_GET["sort"]) == "1") ? 'style="color:red;"' : False; ?>>DESC</a> |
										<a href="/user/buyref/11" class="stn-sort" <?=(isset($_GET["sort"]) AND strtolower($_GET["sort"]) == "11") ? 'style="color:red;"' : False; ?>>ASC</a>
									</th>
									<th class="text-center">
										Заходил
										<BR/>
										<a href="/user/buyref/2" class="stn-sort" <?=(isset($_GET["sort"]) AND strtolower($_GET["sort"]) == "2") ? 'style="color:red;"' : False; ?>>DESC</a> |
										<a href="/user/buyref/22" class="stn-sort" <?=(isset($_GET["sort"]) AND strtolower($_GET["sort"]) == "22") ? 'style="color:red;"' : False; ?>>ASC</a>
									</th>
									<th class="text-center">
										Регистрация
										<BR/>
										<a href="/user/buyref/5" class="stn-sort" <?=(isset($_GET["sort"]) AND strtolower($_GET["sort"]) == "5") ? 'style="color:red;"' : False; ?>>DESC</a> |
										<a href="/user/buyref/55" class="stn-sort" <?=(isset($_GET["sort"]) AND strtolower($_GET["sort"]) == "55") ? 'style="color:red;"' : False; ?>>ASC</a>
									</th>
									<th class="text-center">
										Машинок
										<BR/>
										<a href="/user/buyref/3" class="stn-sort" <?=(isset($_GET["sort"]) AND strtolower($_GET["sort"]) == "3") ? 'style="color:red;"' : False; ?>>DESC</a> |
										<a href="/user/buyref/33" class="stn-sort" <?=(isset($_GET["sort"]) AND strtolower($_GET["sort"]) == "33") ? 'style="color:red;"' : False; ?>>ASC</a>
									</th>
									<th class="text-center">
										Цена/руб.
										<BR/>
										<a href="/user/buyref/4" class="stn-sort" <?=(isset($_GET["sort"]) AND strtolower($_GET["sort"]) == "4") ? 'style="color:red;"' : False; ?>>DESC</a> |
										<a href="/user/buyref/44" class="stn-sort" <?=(isset($_GET["sort"]) AND strtolower($_GET["sort"]) == "44") ? 'style="color:red;"' : False; ?>>ASC</a>
									</th>
									<th class="text-center">Выбор счёта</th>
									<th class="text-center">Покупка</th>
								</tr>
								</thead>


							<?php

								function sort_b($int_s){

									$int_s = intval($int_s);

									switch($int_s){

										case 1: return "db_users_a.user";
										case 2: return "date_login";
										case 3: return "all_trees";
										case 4: return "db_buyref.sum";
										case 5: return "db_users_a.date_reg";

										default: return "db_buyref.id";
									}

								}

								$sort_b = (isset($_GET["sort"])) ? intval($_GET["sort"]) : 0;
								$str_sort = sort_b($sort_b);

								function sortASC($int_s){

									$int_s = intval($int_s);

									switch($int_s){

										case 11: return "ASC";
										case 22: return "ASC";
										case 33: return "ASC";
										case 44: return "ASC";
										case 55: return "ASC";

										default: return "DESC";
									}

								}

								$sortASC = (isset($_GET["sort"])) ? intval($_GET["sort"]) : 0;
								$sortASC = sortASC($sortASC);

							$db->Query("SELECT *,(db_users_b.a_t + db_users_b.b_t + db_users_b.c_t + db_users_b.d_t + db_users_b.e_t) all_trees FROM db_users_a LEFT JOIN db_users_b ON db_users_a.id=db_users_b.id LEFT JOIN db_buyref ON db_users_b.id=db_buyref.id_user WHERE db_buyref.status = '1' ORDER BY $str_sort $sortASC");


							if($db->NumRows() > 0){

								while($user_data = $db->FetchArray()){

									$all = $user_data["a_t"] + $user_data["b_t"] + $user_data["c_t"] + $user_data["d_t"] + $user_data["e_t"];

									# Расчитываем сумму
									$sum = $user_data["sum"];
									$price = $sum ;

									$buyed_user = $user_data["id_user"];
									$id_buyer = $user_data["id_buyer"];

									if ($user_data["date_login"] == 0) {
										$date_login = $user_data["date_reg"];
									}else{
										$date_login = $user_data["date_login"];
									}

							?>

									<tr class="text-center bonus_tr">
										<form action="" method="POST">
										<input type="hidden" name="ref_id" maxlength="3" value="<?=$buyed_user;?>">
										<input type="hidden" name="ref_name" maxlength="30" value="<?=$user_data["user"];?>">
										<input type="hidden" name="buyreferal" maxlength="4" value="<?=$sum;?>">
										<input type="hidden" name="id_buyer" maxlength="30" value="<?=$id_buyer;?>">
										<td align="center"><?=$user_data["user"];?></td>
										<td align="center"><?=date("d.m.Y",$date_login);?></td>
										<td align="center"><?=date("d.m.Y",$user_data["date_reg"]);?></td>
										<td align="center"><?=$all;?></td>
										<td align="center"> <?=$price;?> </td>
										<td align="center">
											<select name="methodPay[]">
												<option value="money_b">Покупки</option>
												<option value="money_p">Вывод</option>
											</select>
										</td>
										<td align="center">
											<input type="submit" class="buybuy" name="buy" value="Приобрести" style="height: 27px; margin-top:6px;"/>
										</td>
										</form>
									</tr>


								<?php

								} # END WHILE

								echo "</table>";

							}else{
								echo '<tr><td align="center" colspan="6">Нет к продаже!</td></tr></table>';
							}
							?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
</div>

<?php
	if(isset($_POST["buy"])){

		# Расчитываем сумму
		$sum = (int)$_POST["buyreferal"];
		$price = $sum ;

		$ref_id = (int)$_POST["ref_id"];
		$ref_name = $_POST["ref_name"];
		$ref_name = filter_var ( $ref_name, FILTER_SANITIZE_STRING );

		$methodPay = $_POST["methodPay"][0];
		$methodPay = filter_var ( $methodPay, FILTER_SANITIZE_STRING );

		$id_buyer = (int)$_POST["id_buyer"];

		if ($methodPay == "money_p") {
			$userPay = $user_datab["money_p"];
			$pay = "money_p";
		}elseif ($methodPay == "money_b") {
			$userPay = $user_datab["money_b"];
			$pay = "money_b";
		}else{
			$userPay = "";
		}

		# Проверим стоимость реферала
		$db->Query("SELECT COUNT(*) FROM db_buyref WHERE sum = '$sum'");
		if($db->FetchRow() == 0){
			# Нет такой стоимости
			echo "Hacking attempt! За вами уже выехали!";
		}else{
			#echo "Покупаем!";
			if($price <= $userPay){

				# Снимаем у меня деньги
				$db->Query("UPDATE db_users_b SET $pay = $pay - '$price' WHERE id = '$usid'");

				# Плюсуем мне реферала
				$db->Query("UPDATE db_users_a SET referals = referals + 1 WHERE id = '$usid'");

				# Прописуем рефералу мои данные
				$db->Query("UPDATE db_users_a SET referer = '$uname', referer_id = '$usid' WHERE id = '$ref_id'");

				# Ставим статус продано
				$db->Query("UPDATE db_buyref SET status = 0 WHERE id_user = '$ref_id'");
                $price = $sum - ($sum * 0.1);
				# Добавляем деньги продавану
				$db->Query("UPDATE db_users_b SET money_p = money_p + '$price' WHERE id = '$id_buyer'"); 
                # Обнуляем доход от реферала  
                $db->Query("UPDATE db_users_b SET to_referer = 0 WHERE id = '$ref_id'");
				
				echo '<center><font color = "8C0508"><b>Вы успешно купили реферала.!</b></font></center><BR />';

				header( 'Refresh: 3; url=/user/buyref' );

			}else echo "<center><font color = '8C0508'><b>Недостаточно денег для покупки реферала</b></font></center><BR />";

		}
	}
?>