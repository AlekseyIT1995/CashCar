<?php 
/**
 * приз + 10 % от ставки проигравший теряет всю ставку
 
если гонка за 1 руб то выйгрыш 1 руб 10 коп


админу что?

 
1 руб делим на 9 победителей это 90 коп 10 коп админу
 
если гонка за 2 руб то на 9 победителей 1руб 80 и 20 админу итд
 */
$_OPTIMIZATION["title"] = "Гонки с ВЫВОДА на ВЫВОД!";
$usid = (int)$_SESSION["user_id"];
$usname = $_SESSION["user"];

$db->Query("SELECT * FROM `db_users_b` WHERE `id` = '$usid' LIMIT 1");
$user_data = $db->FetchArray();

$time = time();

/**
 * Получить стоимость игры
 * @return [type] [description]
 */
function getPriceGame($id){
    GLOBAL $db;
    $db->Query("SELECT `price` FROM `db_race_leaders` WHERE `status` = '0' AND id = '$id'");
    $row = $db->FetchArray();
    return $row['price'];
}

/**
 * Генерирует новые игры
 * @return [type] [description]
 */
function getNewGame(){
    GLOBAL $db;
    $time = time();

    $db->Query("SELECT * FROM `db_race_leaders` WHERE `status` = '0'");
    $res = $db->NumRows();

    if($res >= 10){
        # Есть столы
    }else{
        # Нет столов
        # Добавляем стол
        
        $ass = array();
        while($row = $db->FetchArray()){
            $ass[$row["id"]] = $row["price"];
        }
        /*echo "<pre>";
        var_dump($ass);
        echo "</pre>";*/

        $array2 = array("1", "2", "3", "4", "5", "6", "7", "8", "9", "10");
        #$result = array_intersect($ass, $array2);
        $result = array_diff($array2, $ass);
        $arr= array_values($result);

        /*echo "<pre>";
        print_r($arr);
        echo "</pre>";*/

        $time = time();
        for ($i=0; $i < count($arr); $i++) { 
            $db->Query("INSERT INTO `db_race_leaders` (`price`, `date_add`) VALUES ('$arr[$i]', '$time')");
        }
    }

    #return $res;
}

# Добавим новую игру, если нужно
getNewGame();
?>

<div class="page-content-wrapper ">

    <div class="container">
        <div class="row">
            <div class="col-lg-9 partner_cl">
                <div class="panel panel-primary">
                    <div class="panel-body">
					
					<p class="raceinfotext"> <li><span style="font-size: medium; color: #000000;"><strong> Гонки - это отличный шанс увеличить ваш баланс для ВЫВОДА ! </strong></span><span> <font color="black"> </span></li>  </p>
					<li><span style="font-size: medium; color: #000000;"><strong> На выбор представлены (10 Гонок ) - за 1 руб. за 2руб. за 3 руб за 4 руб. за 5 руб. за 6 руб. за 7 руб. за 8 руб. за 9 руб. и за 10руб.! </strong></span><span> <font color="black"> </span></li>
					<li><span style="font-size: medium; color: #000000;"><strong> В каждой Гонке 9 ПОБЕДИТЕЛЕЙ и 1 ПРОИГРАВШИЙ который разделит свой пройгрыш на победителей поровну ! </strong></span><span> <font color="black"> </span></li>
					<li><span style="font-size: medium; color: #000000;"><strong> Когда в Гонке будут заняты все 10 мест Гонка завершится и начнётя занаво ! </strong></span><span> <font color="black"> </span></li>
					<li><span style="font-size: medium; color: #000000;"><strong> Выйгрыш зачисляется автоматический на ВЫВОД по завершению гонки ! </strong></span><span> <font color="black"> </span></li>
					<li><span style="font-size: medium; color: #000000;"><strong> Выйгрыш = ваша ставка + 10 % Например: Если начать Гонку за 10 руб. то Выйгрыш составит 11 руб. Если за 9 руб. то 9.90  и.т.д. ! </strong></span><span> <font color="black"> </span></li>

<style type="text/css">
.MyTable td{
    text-align: center;
}
</style>

<?php
#$db->Query("DELETE FROM `db_race_leaders` WHERE `8m` = 'TestPoslM'");

if (isset($_POST['go'])) {
	
	$game_id = (int)$_POST['game_id'];
	$db->Query("SELECT 1m,2m,3m,4m,5m,6m,7m,8m,9m,10m FROM db_race_leaders WHERE id = '$game_id' AND status = '0'");
	$arr1 = array();

	while($row = $db->FetchArray()){
		$arr1[] = $row;
	}

    if (in_array($usname, $arr1[0])) {
        echo $func->error("ВЫ уже в ГОНКЕ дождитесь завершения!");
        header( 'Refresh: 2; url=/user/race_leaders' );
    }else{

        $game_id = (int)$_POST['game_id'];
        $sum = getPriceGame($game_id);

        if($sum <= $user_data["money_p"]){

            # Снимаем с пользователя
            $db->Query("UPDATE db_users_b SET money_p = money_p - '$sum' WHERE id = '$usid'");

            $time = time();
            $id = (int)$_POST['id'];
            $db->Query("UPDATE db_race_leaders SET {$id}m = '$usname', bank = bank + '$sum' WHERE id = '$game_id'");

            #echo "<div align='center' style='color: green; font-size: 25px;font-weight: bold;'>Вы выбрали игру №".$game_id." место №".$id."</div>";

            /* ======== */
			$db->Query("SELECT 1m,2m,3m,4m,5m,6m,7m,8m,9m,10m FROM db_race_leaders WHERE id = '$game_id' AND status = '0'");
			$arr = array();

			while($row = $db->FetchArray()){
				$arr[] = $row;
			}
	
            $resArr = array_unique($arr[0]);
            /*echo "<pre>";
            var_dump($resArr);
            echo "</pre>";*/

            $rand = rand(0,9);
            unset($resArr[$rand]);
            $array = array_values($resArr);

            /*
			var_dump($arr[0]);*/

            for ($i=1; $i < 11; $i++) {
                if ($arr[0][$i.'m'] == '0') {
                    $last[$i] = '0';
                }
            }

            /* ----------- */
            $priz = $sum / 10;
            $prizAll = $priz + $sum;
            /* ----------- */


            #if (empty($last)) {
            if ($last == NULL) {
                #$rand_keys = array_rand($arr[0], 2);
                #$winner = $arr[0][$rand_keys[0]]; # исключить проигравшего

                $db->Query("UPDATE db_race_leaders SET status = '1' WHERE id = '$game_id'");

                $sql = array();
                for ($i=0; $i < 9; $i++) { 
                    # Добавим в таблицу выигрышей
                    $sql[] = "'{$array[$i]}'";
                    # Начислим приз
                    $db->Query("UPDATE db_users_b SET money_p = money_p + '$prizAll' WHERE user = '$array[$i]'");
                }

                if(count($sql) > 0) {
                    $db->Query("INSERT INTO `db_race_leaders_win` (`1m`,`2m`,`3m`,`4m`,`5m`,`6m`,`7m`,`8m`,`9m`, `date_add`, `game_id`, `sum`) VALUES (".implode(",", $sql).", '$time', '$game_id', '$prizAll') ");
                }

                #echo "<br/><br/><div align='center' style='color: green; font-size: 25px;font-weight: bold;'>Делаем розыгрышь игры №".$game_id."... Итак... Победители записаны, проиграл: ".$winner."</div>";
				#echo $func->error("Делаем розыгрышь игры №".$game_id."... Итак... Победители записаны, проиграл: ".$winner, true);
				echo $func->error("Делаем розыгрышь игры №".$game_id."... Итак... Победители записаны.", true);
            }else{
                #echo "<div align='center' style='color: green; font-size: 25px;font-weight: bold;'>Вы выбрали игру №".$game_id." место №".$id."</div>";
				echo $func->error("Вы выбрали игру №".$game_id." место №".$id, true);
            }
            /* ======== */

            header( 'Refresh: 3; url=/user/race_leaders' );

        }else echo $func->error("На счёте для ВЫВОДА недостаточно средств!");

    }
}
?>

  </div>

                </div>
            </div>
        </div>
        <!-- end row -->
    </div><!-- container -->
</div>

<style>
/*input[type="submit"] {*/
.submitn1,.submitn2,.submitn3,.submitn4,.submitn5,.submitn6,.submitn7,.submitn8,.submitn9,.submitn10 {
	color: #0def0aad;
    font-size: 25px;
    font-weight: bold;
	/*padding-top: 85px;*/
}
.submitn1{
    width: 195px;
    height: 120px;
    border: none;
    background: url(/img/cars/n1.png) no-repeat 80% 8%;
}
.submitn2{
    width: 195px;
    height: 120px;
    border: none;
    background: url(/img/cars/n2.png) no-repeat 80% 8%;
}
.submitn3{
    width: 195px;
    height: 120px;
    border: none;
    background: url(/img/cars/n3.png) no-repeat 80% 8%;
}
.submitn4{
    width: 195px;
    height: 120px;
    border: none;
    background: url(/img/cars/n4.png) no-repeat 80% 8%;
}
.submitn5{
    width: 195px;
    height: 120px;
    border: none;
    background: url(/img/cars/n5.png) no-repeat 80% 8%;
}
.submitn6{
    width: 195px;
    height: 120px;
    border: none;
    background: url(/img/cars/n6.png) no-repeat 80% 8%;
}
.submitn7{
    width: 195px;
    height: 120px;
    border: none;
    background: url(/img/cars/n7.png) no-repeat 80% 8%;
}
.submitn8{
    width: 195px;
    height: 120px;
    border: none;
    background: url(/img/cars/n8.png) no-repeat 80% 8%;
}
.submitn9{
    width: 195px;
    height: 120px;
    border: none;
    background: url(/img/cars/n9.png) no-repeat 80% 8%;
}
.submitn10{
    width: 195px;
    height: 120px;
    border: none;
    background: url(/img/cars/n10.png) no-repeat 80% 8%;
}

.myopacity1, .myopacity2, .myopacity3, .myopacity4, .myopacity5, .myopacity6, .myopacity7, .myopacity8, .myopacity9, .myopacity10 {
	opacity: 0.5;
}
.myopacity1{
	width: 195px;
    height: 120px;
    border: none;
    background: url(/img/cars/n1.png) no-repeat 80% 8%;
	padding-top: 30px;
    color: white;
    font-weight: bold;
    font-size: 25px;
	-webkit-text-fill-color: white;
	-webkit-text-stroke: 1px #00000052;
	text-shadow:
			-1px -1px 0 #0000006b,
			1px -1px 0 #0000006b,
			-1px 1px 0 #0000006b,
			1px 1px 0 #0000006b;
}
.myopacity2{
	width: 195px;
    height: 120px;
    border: none;
    background: url(/img/cars/n2.png) no-repeat 80% 8%;
	padding-top: 30px;
    color: white;
    font-weight: bold;
    font-size: 25px;
	-webkit-text-fill-color: white;
	-webkit-text-stroke: 1px #00000052;
	text-shadow:
			-1px -1px 0 #0000006b,
			1px -1px 0 #0000006b,
			-1px 1px 0 #0000006b,
			1px 1px 0 #0000006b;
}
.myopacity3{
	width: 195px;
    height: 120px;
    border: none;
    background: url(/img/cars/n3.png) no-repeat 80% 8%;
	padding-top: 30px;
    color: white;
    font-weight: bold;
    font-size: 25px;
	-webkit-text-fill-color: white;
	-webkit-text-stroke: 1px #00000052;
	text-shadow:
			-1px -1px 0 #0000006b,
			1px -1px 0 #0000006b,
			-1px 1px 0 #0000006b,
			1px 1px 0 #0000006b;
}
.myopacity4{
	width: 195px;
    height: 120px;
    border: none;
    background: url(/img/cars/n4.png) no-repeat 80% 8%;
	padding-top: 30px;
    color: white;
    font-weight: bold;
    font-size: 25px;
	-webkit-text-fill-color: white;
	-webkit-text-stroke: 1px #00000052;
	text-shadow:
			-1px -1px 0 #0000006b,
			1px -1px 0 #0000006b,
			-1px 1px 0 #0000006b,
			1px 1px 0 #0000006b;
}
.myopacity5{
	width: 195px;
    height: 120px;
    border: none;
    background: url(/img/cars/n5.png) no-repeat 80% 8%;
	padding-top: 30px;
    color: white;
    font-weight: bold;
    font-size: 25px;
	-webkit-text-fill-color: white;
	-webkit-text-stroke: 1px #00000052;
	text-shadow:
			-1px -1px 0 #0000006b,
			1px -1px 0 #0000006b,
			-1px 1px 0 #0000006b,
			1px 1px 0 #0000006b;
}
.myopacity6{
	width: 195px;
    height: 120px;
    border: none;
    background: url(/img/cars/n6.png) no-repeat 80% 8%;
	padding-top: 30px;
    color: white;
    font-weight: bold;
    font-size: 25px;
	-webkit-text-fill-color: white;
	-webkit-text-stroke: 1px #00000052;
	text-shadow:
			-1px -1px 0 #0000006b,
			1px -1px 0 #0000006b,
			-1px 1px 0 #0000006b,
			1px 1px 0 #0000006b;
}
.myopacity7{
	width: 195px;
    height: 120px;
    border: none;
    background: url(/img/cars/n7.png) no-repeat 80% 8%;
	padding-top: 30px;
    color: white;
    font-weight: bold;
    font-size: 25px;
	-webkit-text-fill-color: white;
	-webkit-text-stroke: 1px #00000052;
	text-shadow:
			-1px -1px 0 #0000006b,
			1px -1px 0 #0000006b,
			-1px 1px 0 #0000006b,
			1px 1px 0 #0000006b;
}
.myopacity8{
	width: 195px;
    height: 120px;
    border: none;
    background: url(/img/cars/n8.png) no-repeat 80% 8%;
	padding-top: 30px;
    color: white;
    font-weight: bold;
    font-size: 25px;
	-webkit-text-fill-color: white;
	-webkit-text-stroke: 1px #00000052;
	text-shadow:
			-1px -1px 0 #0000006b,
			1px -1px 0 #0000006b,
			-1px 1px 0 #0000006b,
			1px 1px 0 #0000006b;
}
.myopacity9{
	width: 195px;
    height: 120px;
    border: none;
    background: url(/img/cars/n9.png) no-repeat 80% 8%;
	padding-top: 30px;
    color: white;
    font-weight: bold;
    font-size: 25px;
	-webkit-text-fill-color: white;
	-webkit-text-stroke: 1px #00000052;
	text-shadow:
			-1px -1px 0 #0000006b,
			1px -1px 0 #0000006b,
			-1px 1px 0 #0000006b,
			1px 1px 0 #0000006b;
}
.myopacity10{
	width: 195px;
    height: 120px;
    border: none;
    background: url(/img/cars/n10.png) no-repeat 80% 8%;
	padding-top: 30px;
    color: white;
    font-weight: bold;
    font-size: 25px;
	-webkit-text-fill-color: white;
	-webkit-text-stroke: 1px #00000052;
	text-shadow:
			-1px -1px 0 #0000006b,
			1px -1px 0 #0000006b,
			-1px 1px 0 #0000006b,
			1px 1px 0 #0000006b;
}
</style>

<table align="center" class="MyTable" border="0" width="95%" cellpadding="10" cellspacing="10">
    <?php
    $db->Query("SELECT * FROM db_race_leaders WHERE status = '0' ORDER BY `price` DESC");

    if($db->NumRows() > 0){
        #$row = $db->FetchArray();

        while($row = $db->FetchArray()){

            echo '<tr>
                <td colspan="5" align="center"><h1> -------------- Гонка №'.$row['id'].' за '.$row['price'].' руб., Банк: '.$row['bank'].' руб. -------------- </h1></td>
            </tr>';
            
            echo '<tr>';
            for ($i=1; $i < 11; $i++) {
                if ($row[$i.'m'] == '0') {
                    $res = '<form method="POST" action=""><input type="hidden" name="id" value="'.$i.'"><input type="hidden" name="game_id" value="'.$row['id'].'"><input type="submit" class="submitn'.$row['price'].'" name="go" value="Занять №'.$i.'"></form>';
                }else{
                    $res = "<div class='myopacity".$row['price']."'>
						<span class='myposition'>Занято ".$row[$i.'m']."</span>
					</div>";
                }

                if ($i == '6') {
                    echo "</tr><tr>";
                }
                echo "<td>".$res."</td>";
            }
            echo '</tr>';

        }

    }else echo '<tr><td colspan="5" align="center">Нет участников</td></tr>';
    ?>
</table>

<div class="col-lg-9 partner_cl">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title racetabletitle"><i class="fa fa-list-ul"></i> Победители</h3>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="table-responsive">

	<table class="table">
	<thead>
<?php

  $db->Query("SELECT * FROM `db_race_leaders_win` ORDER BY `id` DESC LIMIT 20");

    if($db->NumRows() > 0){

        while($ref = $db->FetchArray()){
?>
        <tr class="htt">
            <td align="center"><?=$ref["1m"];?></td>
            <td align="center"><?=$ref["2m"];?></td>
            <td align="center"><?=$ref["3m"];?></td>
            <td align="center"><?=$ref["4m"];?></td>
            <td align="center"><?=$ref["5m"];?></td>
            <td align="center"><?=$ref["6m"];?></td>
            <td align="center"><?=$ref["7m"];?></td>
            <td align="center"><?=$ref["8m"];?></td>
            <td align="center"><?=$ref["9m"];?></td>
        </tr>
        <tr class="htt">
            <th class="text-center" colspan="2" align="center" class="m-tb">ID <?=$ref["id"];?></td>
            <th class="text-center" colspan="2" align="center" class="m-tb">Гонка № <?=$ref["game_id"]; ?></td>
            <th class="text-center" colspan="2" align="center" class="m-tb">Приз по <?=$ref["sum"]; ?> руб.</td>
            <th class="text-center" colspan="3" align="center" class="m-tb"><?=date("d.m.Y в H:i",$ref["date_add"]);?></td>
        </tr>
        <tr>
            <td colspan="9" align="center">-=-</td>
        </tr>
<?php
        }

    }else echo '<tr><td align="center" colspan="5">Нет победителей! :(</td></tr>';

?>
</thead>
</table>
<br/><br/><br/>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
</div>