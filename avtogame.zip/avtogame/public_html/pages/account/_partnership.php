<?php
$_OPTIMIZATION["title"] = "Партнерская программа";

$user_id = $_SESSION["user_id"];
$uname = $_SESSION["user"];

$db->Query("SELECT `from_referals` FROM db_users_a, db_users_b WHERE db_users_a.id = db_users_b.id AND db_users_a.id = '$user_id'");
$prof_data = $db->FetchArray();

$db->Query("SELECT COUNT(*) FROM db_users_a WHERE referer_id = '$user_id'");
$refs = $db->FetchRow(); // Считаем рефералов 1 уровня
$db->Query("SELECT COUNT(*) FROM db_users_a WHERE referer_id2 = '$user_id'");
$refs2 = $db->FetchRow(); // Считаем рефералов 2 уровня
$db->Query("SELECT COUNT(*) FROM db_users_a WHERE referer_id3 = '$user_id'");
$refs3 = $db->FetchRow(); // Считаем рефералов 3 уровня
$all = $refs + $refs2 + $refs3;

    # ========= вывод всего заработано на рефералах ========= #
    $db->Query("SELECT doxod2 FROM db_users_a WHERE referer_id2 = '$user_id'");
    $doxod_refs2 = $db->FetchArray();
    $doxod_refs2['doxod2'];

    $db->Query("SELECT doxod3 FROM db_users_a WHERE referer_id3 = '$user_id'");
    $doxod_refs3 = $db->FetchArray();
    $doxod_refs3['doxod3'];

    $zarab_na_refax = $prof_data["from_referals"] + $doxod_refs2['doxod2'] + $doxod_refs3['doxod3'];
    # ======================= #
	
	# Кликов в сёрфинге
    $db->Query("SELECT COUNT(*) FROM db_serfing_view WHERE user_id = '$user_id'");
    $clicks = $db->FetchRow();
?>




<div class="page-content-wrapper ">

    <div class="container">

        <div class="row">
            <div class="col-sm-6 col-lg-3 partner_cl_top">
                <div class="panel text-center">
                    <div class="panel-heading">
                        <h4 class="panel-title text-muted font-light profilemsz">Количество рефералов</h4>
                    </div>
                    <div class="panel-body p-t-0">
                        <h2 class="m-t-0 m-b-5 profilemst"><i class="mdi mdi-account-network text-danger m-r-10"></i><b><?=$refs?> чел.</b></h2>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-lg-3 partner_cl_top">
                <div class="panel text-center">
                    <div class="panel-heading">
                        <h4 class="panel-title text-muted font-light profilemsz">Доход с рефералов</h4>
                    </div>
                    <div class="panel-body p-t-0">
                        <h2 class="m-t-0 m-b-5 profilemst"><i class="mdi mdi-cash-multiple text-primary m-r-10"></i><b><?=sprintf("%.2f",$zarab_na_refax); ?>₽</b></h2>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-lg-3 partner_cl_top">
                <div class="panel text-center">
                    <div class="panel-heading">
                        <h4 class="panel-title text-muted font-light profilemsz">Кликов в сёрфинге</h4>
                    </div>
                    <div class="panel-body p-t-0">
                        <h2 class="m-t-0 m-b-5 profilemst"><i class="mdi mdi-mouse text-danger m-r-10"></i><b><?=($clicks == 0) ? 'нет' : $clicks?></b></h2>
                    </div>
                </div>
            </div>
        </div><!-- end row -->

        <div class="row">
            <div class="col-lg-9 partner_cl">
                <div class="panel panel-primary">
                    <div class="panel-body">
  <div class="row">
  <div class="col-md-6">
                          <h4 class="m-b-10 m-t-0" style="color:#d20909;">Реферальная ссылка :</h4>
    <h5 class="profileinfoh5"><b class="partner_stath5">Реф. ссылка:</b> <span style="float:none;margin-left: 15px;"> https://<?=$_SERVER['HTTP_HOST']; ?>/?i=<?=$_SESSION["user_id"]; ?></span></h5>
                        </div>
  <div class="col-md-6">
  <h4 class="m-b-10 m-t-0" style="color:#d20909;">Баннеры:</h4>
                          <h5 class="profileinfoh5"><b class="partner_stath5"><a href="https://avtogame.ru/user/promo" target="_blank" >Перейти к БАННЕРАМ >>>   </a></b> <span></span></h5>

  </div>
  </div>
</div>
                </div>
            </div>
            <div class="col-lg-9 partner_cl">
                <div class="panel panel-primary">
                    <div class="panel-body">
                        <h4 class="m-b-10 m-t-0">Наша партнерская программа 100%:</h4>
  <p>В партнерской программе может участвовать любой пользователь проекта. Программа предусматривает ряд вознаграждений за определенные действия Ваших рефералов. Рефералы - пользователи, которые зарегистрировались на проекте после перехода по Вашей реферальной ссылке или баннеру. Так же вы можете купить свободных рефералов <a href="https://avtogame.ru/user/buyref" target="_blank" > Здесь>>>   </a>    </p>
                        <h4 class="m-b-10 m-t-0">Вознаграждения:</h4>
  <p class="partner_payp"> - 100% с каждого просмотра в "Сёрфинге сайтов"</p>					
  <p class="partner_payp"> - 100% от получения ежедневного бонуса вашими рефералами, с каждого ! </p>						
  <p class="partner_payp"> - 5% от суммы пополнения рекламного баланса</p>
  <h5 class="m-b-0 m-t-0" style="color:#b10909;letter-spacing:1px;">Вознаграждения выплачиваются на ваш баланс для вывода!</h5>
</div>
                </div>
            </div>
        </div> <!-- End Row -->

    </div><!-- container -->


</div>