<?php
$_OPTIMIZATION["title"] = "Ежедневный бонус";
$usid = $_SESSION["user_id"];
$uname = $_SESSION["user"];

# Реф начисление
$db->Query("SELECT user, referer_id FROM db_users_a WHERE id = '{$usid}' LIMIT 1");
$user_refdata = $db->FetchArray();
$refid = $user_refdata["referer_id"];

# Настройки бонусов
$bonus_min = 5;
$bonus_max = 5;

?>

<div class="page-content-wrapper ">

    <div class="container">
        <div class="row">
            <div class="col-lg-9 partner_cl">
                <div class="panel panel-primary">
                    <div class="panel-body">
  <p class="raceinfotext"><li><span style="font-size: medium; color: #000000;"><strong>Для получения бонуса нажмите на баннер ! Если нет баннера отключите блокировщик рекламмы ! </strong></span><span> <font color="blou"> </span></li> </p>
  <p class="raceinfotext">Каждый участник проекта, раз в сутки получает ежедневный бонус, сумма бонуса от 0,01 коп. до 1 рубля. Благодаря ежедневному бонусу, <a href="/user/surfing">сёрфингу сайтов</a> и/или <a href="/user/partnership">партнерской программе</a> пользователи проекта, которые решили участвовать в проекте без вложений могут накопить на машины начальных уровней, тем самым заработать реальные деньги без инвестиций.</p>
  <p class="raceinfotext">Так же Вы будете получать ежедневно до 0.10 руб на ВЫВОД от получения бонуса Вашими рефералами,с каждого ! </p>
  <p class="raceinfotext">Хотите получать прибыль с бонусов от рефералов ? Тогда вы можете купить их <a href="/user/buyref" >Здесь </a> или пригласить по реф. ссылке  ! </p>
	
<?php
$ddel = time() + 60*60*12;
$dadd = time();
$db->Query("SELECT COUNT(*) FROM db_bonus WHERE user_id = '$usid' AND date_del > '$dadd'");

$hide_form = false;

	if($db->FetchRow() == 0){
	
		# Выдача бонуса
		if(isset($_POST["bonus"])){
		
			$sumrad = rand($bonus_min, rand($bonus_min, $bonus_max) );
			$sum=$sumrad/100;
			$sumref = $sum * 0.05; // Реф начисление 5%
			$energy = $sum * 0.01; // Даем 10% энергии от бонуса
			
			# Зачилсяем юзверю
			$db->Query("UPDATE db_users_b SET money_p = money_p + '$sum', to_referer = to_referer + '$sum' WHERE id = '$usid'"); 
			
			#сюда надо прописать бонус реферу
			$db->Query("UPDATE db_users_b SET money_p = money_p + '$sum' WHERE id = '$refid'");
			
			#Пропишем доход с рефералов ! реферу
			$db->Query("UPDATE db_users_b SET from_referals = from_referals + '$sum' WHERE id = '$refid'");			
			
			# Вносим запись в список бонусов
			$db->Query("INSERT INTO db_bonus (user, user_id, sum, date_add, date_del) VALUES ('$uname','$usid','$sum','$dadd','$ddel')");
			
			# Случайная очистка устаревших записей
			#$db->Query("DELETE FROM db_bonus WHERE date_del < '$dadd'");
			
			echo $func->error("На Ваш счет для вывода и вашему реферу зачислен бонус в размере {$sum} руб.", true);
			
			$hide_form = true;

            header( 'Refresh: 5; url=/user/daily' );
			
		}
			
			# Показывать или нет форму
			if(!$hide_form){
?>

<center><br/>

<div class="column_3" id="hidden_link" onclick="document.all.hidden_link1.style.display='block';" style="width: 468px;display:yes">
    <!-- <div id="linkslot_111"><script src="https://linkslot.ru/bancode.php?id=111" async></script></div> -->
    <div><a href="https://profit-boom.pro/?i=4408" target="_blank"><img src="http://avtogame.ru/img/468.gif" /></a></div>       
<?php
//include "_bonlink.php";
?>
</div>
<div class="column_3" id="hidden_link1" onclick="document.all.hidden_link2.style.display='block';" style="display:none"><br/>
<form action="" method="post">
    <!-- <input type="submit" name="bonus" value="Получить бонус" class="btn btn-success"> -->
    <button type="submit" name="bonus" class="btn btn-primary btn-block waves-effect ideas_btn" style="width:300px;"><i class="fa fa-gift"></i> Получить бонус</button>
</form>
</div>
</center>


<?PHP 

			}

	}else {
    	$db->Query("SELECT * FROM db_bonus WHERE user_id = '$usid' AND date_del > '$dadd'");
        $u_data = $db->FetchArray();
        $time = $u_data['date_del'] - $dadd;
        $hours = floor($time/3600);
        floor($minutes =($time/3600 - $hours)*60);
        $seconds = ceil(($minutes - floor($minutes))*60);
        $min=ceil($minutes)-1;
?>
    <div class="text-center">
        <h3 class="ideas_goto">
            <a><i class="fa fa-clock-o"></i>
            <b id="bonus">Следующий бонус будет доступен через: 
                <?=json_encode($hours);echo ' ч.  ';echo json_encode($min);echo ' мин.  '; echo json_encode($seconds);echo ' сек.  ';?>
            </b>
            <script>setInterval(function(){
                $("#bonus").load("# #bonus"); }, 1000);
            </script>
            </a>
        </h3>
    </div>
<?php
	}
?>

  </div>

                </div>
            </div>
        </div>
        <!-- end row -->
    </div><!-- container -->
</div>

            <div class="col-lg-9 partner_cl">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title racetabletitle"><i class="fa fa-list-ul"></i> Последние 15 полученных бонусов</h3>
						<h3 class="panel-title racetabletitle"><i class="fa fa-list-ul"></i> Партнёрская программа на бонусы 100 %</h3>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="table-responsive">

    <table class="table">
    <thead>
    <tr>
    <th class="text-center">Логин пользователя</th>
    <th class="text-center">Дата получения</th>
    <th class="text-center">Сумма бонуса</th>
	<th class="text-center">Реферу</th>
    </tr>
    </thead>
    <tbody>

<?php
  
  $db->Query("SELECT * FROM db_bonus ORDER BY id DESC LIMIT 15");
  
	if($db->NumRows() > 0){
  
  		while($bon = $db->FetchArray()){
		
		?>

        <tr class="text-center bonus_tr">
        <td><a href="/user/wall/<?=$bon["user_id"]; ?>"><?=$bon["user"]; ?></a></td>
        <td><?=date("d.m.Y в H:i:s",$bon["date_add"]); ?></td>
        <td><?=$bon["sum"]; ?> руб.</td>
		<td><?=$bon["sum"]; ?> руб.</td>
        </tr>
		
<?php
		
		}
  
	}else echo '<tr><td align="center" colspan="5">Нет записей</td></tr>'
  ?>    
  
</tbody>
</table>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
</div>
