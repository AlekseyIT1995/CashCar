<?php
$_OPTIMIZATION["title"] = "Оплачиваемые квесты";
$user_id = $_SESSION["user_id"];
$usname = $_SESSION["user"];

if (isset($_POST['report'])) {
    $report = $_POST['report'];
    $id = (int)$_POST['id'];

    $db->Query("INSERT INTO `db_quest` (user_id, date_add, quest, report, status) VALUES ('$user_id','".time()."','$id','$report','0')");

}
?>
<script>
    function changeModal(id) {
        var abouts = ["","Ссылку на ваш профиль во ВКонтакте","Ссылку на видеообзор.","Ссылку на ваш видео-обзор проекта"];
        $(".quests_modalinfo").html(abouts[id]);
        if(id<3) {
            $("#getID").val(id);
        }
        else if(id==3) {
            $("#getID").val(5);
        }
    }
</script>
<div class="page-content-wrapper ">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <p class="raceinfotext m-b-0">
                            Выполняйте простые задания от администрации и получайте приятные бонусы! Ниже представлен ряд квестов, за выполнение которых администрация выплачивает поощрительные бонусы. Внимательно ознакомьтесь с описанием квеста, условиями для его выполнения, и подайте отчет после осуществления требуемых от Вас действий. Некоторые квесты имеют срок действия, по истечению которого квест удаляется из системы. <b>Отчеты проверяются вручную администрацией проекта в течении 24 часа.</b> 
                        </p>
                    </div>
                </div>
            </div>

        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="panel">
                    <div class="panel-heading quests_gradient01">
                        <h3 class="panel-title quests_zag">
                            <div> <i class="fa fa-vk"></i>
                                Подписаться на сообщество проекта во ВКонтакте
                            </div>
                            <span class="quests_sum">Вознаграждение: 1 ₽</span>
                        </h3>
                    </div>
                    <div class="panel-body quests_gradient02">
                        <h4 class="quests_h4">Описание квеста:</h4>
                        <p class="quests_info">
                            Самый простой квест. Перейдите на
                            <a target="_blank" href="https://vk.com/club74735637">
                                официальную страницу проекта <sup><i class="fa fa-external-link"></i></sup> 
                            </a>
                            AvtoGame.ru во ВКонтакте и подпишитесь на новости со своей страницы.
                        </p>
                    </div>
                    <div class="quests_panel-footer panel-body quests_gradient02">
                        <h4 class="quests_h4_prem">
<?php 
                $db->Query("SELECT * FROM `db_quest` WHERE `quest` = 1 AND user_id = '$user_id'");
                $data = $db->FetchArray();
                if ($data['status'] == 1) {
                    echo '<button type="button" class="btn btn-dark waves-effect quests_btn disabled"> <i class="fa fa-check"></i> Выполнено!</button>';
                }elseif($data['status'] == 0){
                    echo '<button type="button" class="btn btn-dark waves-effect quests_btn disabled"> <i class="fa fa-refresh"></i> На модерации!</button>';
                }elseif($data['status'] == 2){
                    echo '<button type="button" class="btn btn-dark waves-effect quests_btn disabled"> <i class="fa fa-close"></i> Отчет отклонен!</button>';
                }else{
?>
                            <button type="button" class="btn btn-dark waves-effect quests_btn" data-toggle="modal" data-target="#myModal" onclick="changeModal(1)">
                                <i class="fa fa-pencil-square-o"></i>
                                Подать отчет
                            </button>
<?php 
                }
?>
                            <span class="quests_prem">Срок действия: неограничен</span>
                            <span class="quests_prem m-r-10">Тип задания: одноразовое</span>
                        </h4>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="panel">
                    <div class="panel-heading quests_gradient01">
                        <h3 class="panel-title quests_zag">
                            <i class="fa fa-commenting"></i>
                            Сделать видеообзор игры
                            <span class="quests_sum">Вознаграждение: 200 ₽</span>
                        </h3>
                    </div>
                    <div class="panel-body quests_gradient02">
                        <h4 class="quests_h4">Описание квеста:</h4>
                        <p class="quests_info">
                            <b>Сделайте видеообзор нашей игры не менее 5 минут и разместите видео на YouTube   </b>
                        </p>

                    </div>
                    <div class="quests_panel-footer panel-body quests_gradient02">
                        <h4 class="quests_h4_prem">
                            <button type="button" class="btn btn-dark waves-effect quests_btn" data-toggle="modal" data-target="#myModal" onclick="changeModal(2)">
                                <i class="fa fa-pencil-square-o"></i>
                                Подать отчет
                            </button>
                            <!--  -->
                            <!--  -->
                            <span class="quests_prem">Срок действия: НЕОГРАНИЧЕН</span>
                            <span class="quests_prem m-r-10">Тип задания: раз в 7 дней</span>
                        </h4>
                    </div>
                </div>
            </div>

        </div>
        <style>
        .quests_zag{color: #fff;text-shadow:1px 1px 0px #41a2ad;text-transform:uppercase;letter-spacing:1px;}
        .quests_zag div{display:inline;}
        .quests_sum{float:right;letter-spacing: 1px;background: rgba(0, 0, 0, 0.47);color: #ffe79d;text-shadow: 1px 1px 0 #000;padding: 0px 10px;border-radius:5px;}
        .quests_h4{font-size:15px;color: rgba(255,255,255,0.5) !important;text-transform:uppercase;letter-spacing:1px;}
        .quests_info{color:#fff;letter-spacing:1px;background: rgba(255,255,255,0.2);padding: 5px 15px;border-radius:4px;font-size:15px;}
        .quests_info a{color:#fff;font-weight:700;}
        .quests_info a:hover{color: rgba(255,255,255,0.8);}
        .quests_btn{text-transform:uppercase;letter-spacing:1px;color:#fff;font-weight:bold;border:0;padding: 4px 30px;font-size: 16px;box-shadow: inset 0 0 6px rgba(255, 255, 255, 0.43);}
        .quests_btn:hover{opacity:0.9;box-shadow: inset 0 0 8px rgba(255, 255, 255, 0.7)}
        .quests_panel-footer{border: none !important;padding: 5px 10px;border-radius: 0 0 3px 3px;}
        .quests_h4_prem{font-size:14px;text-transform:uppercase;letter-spacing:1px;margin:0;}
        .quests_prem{float:right;letter-spacing: 1px;background: rgba(255, 255, 255, 0.16);font-weight:100;padding: 4px 10px;border-radius:5px;color: #fff;}
        .quests_modalzag{text-transform: uppercase;letter-spacing: 1px;}
        .quests_modalback{background:#fafafa;padding:15px;padding: 1px 15px;}
        .quests_modalinfo{color:#9c2320;font-size: 13px;line-height: 1.6;letter-spacing: 1px;text-shadow: 1px 1px #fff;}
        .quests_gradient01{background: #c2e59c !important;background: -moz-linear-gradient(45deg, #c2e59c 0%, #64b3f4 100%) !important;background: -webkit-linear-gradient(45deg, #c2e59c 0%,#64b3f4 100%) !important;background: linear-gradient(45deg, #c2e59c 0%,#64b3f4 100%) !important;filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#c2e59c', endColorstr='#64b3f4',GradientType=1 ) !important;}
        .quests_gradient02{box-shadow: inset 0 0 5px rgba(0,0,0,0.2);background: #67b26f !important;background: -moz-linear-gradient(45deg, #67b26f 0%, #4ca2cd 100%) !important;background: -webkit-linear-gradient(45deg, #67b26f 0%,#4ca2cd 100%) !important;background: linear-gradient(45deg, #67b26f 0%,#4ca2cd 100%) !important;filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#67b26f', endColorstr='#4ca2cd',GradientType=1 ) !important;}
        @media (max-width: 1000px) {
          .quests_prem{display:block;text-align: center;float:none;margin-top:5px;}
          .quests_h4_prem .m-r-10{margin-right:0;}
          .quests_btn{width:100%;text-align:center;}
        }
        @media (max-width: 390px) {
          .quests_btn{font-size:13px;}
        }
        @media (max-width: 768px) {
          .quests_zag{text-align:center;font-size:15px;padding-bottom: 40px;}
          .quests_zag span{width:100%;text-align:center;}
        }
        @media (min-width: 768px) and (max-width: 1000px) {
           .quests_zag{font-size:13px;}
        }
        </style>

        <div id="myModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                        <h4 class="modal-title" id="myModalLabel">Отчет о выполнении квеста</h4>
                    </div>
                    <div class="modal-body">
                        <h5 class="quests_modalzag">Что необходимо написать в отчете:</h5>
                        <div class="quests_modalback">
                            <h6 class="quests_modalinfo">Ссылку на ваш профиль во ВКонтакте</h6>
                        </div>
                        <hr class="m-b-5">
                        <form action="" method="post">
                            <input type="hidden" name="id" id="getID" />
                            <div class="form-group">
                                <label class="ideas_label">Форма подачи отчета:</label>
                                <textarea name="report" class="form-control" maxlength="1000" placeholder="Введите информацию которую необходимо подать для отчета...." rows="3" required></textarea>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary waves-effect waves-light">Отправить отчет</button>
                            <button type="button" class="btn btn-default waves-effect" data-dismiss="modal">Закрыть</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>