<?PHP
$_OPTIMIZATION["title"] = "Настройки аккаунта";

$usid = $_SESSION["user_id"];
$uname = $_SESSION["user"];

$db->Query("SELECT * FROM db_users_a WHERE id = '$usid'");
$user_data = $db->FetchArray();

$db->Query("SELECT `payeer`,`yandex`,`qiwi`,`advcash`,`okpay`,`beeline`,`tele2`,`mts`,`megafon`,`wm`,`visa` FROM db_users_b WHERE id = '$usid'");
$data = $db->FetchArray();

# ==========
$array = array('salt' => 'solsalt', 
               'key' => 'XrenVamVsemvStakanOtAPTEMOHa',
                );
$tokenMy = hash('sha256', implode(":", $array));

$userAgent = isset($_SERVER['HTTP_USER_AGENT'])
               ? strtolower($_SERVER['HTTP_USER_AGENT'])
               : '';

$seed = $_SESSION['csrf_seed'] = mt_rand(0, PHP_INT_MAX);
$token = md5($seed.$userAgent.$_SERVER['REMOTE_ADDR'].$tokenMy);
# ==========

if (isset($_GET['key'])) {

    if($user_data["email_verify"] == 0){

        $email = $user_data['email'];
        $options = array(
                'options' => array(
                        'regexp' => '/^[-a-zA-Z0-9]{30,40}+$/'
                        )  
                );
        $strKey = $_GET["key"];
        $key = filter_var($strKey, FILTER_VALIDATE_REGEXP, $options);

        function clear($data,$type='str')
        {
            $data = trim($data);
            #$data = mysql_escape_string($data);
            $data = strip_tags($data);
            $data = htmlspecialchars($data);
            $data = ($type == 'str')?strval($data):intval($data);
            return $data;
        }
        $key = clear($key);

        $token_data = explode('-', $key);

        $token_id = (string)$token_data[0];
        $token_hash = (string)$token_data[1];

        if(strlen($token_hash) != 32){ 
            echo $func->error("Ссылка для подтверждения не действительна :("); 
            
            echo '<div class="clr"></div></div>';
            return; 
        }

        $tkey = md5($email."_rfs_".$email);
        if($token_hash != $tkey){ 
            echo $func->error("Ссылка для подтверждения не действительна :(");

            echo '<div class="clr"></div></div>';
            return; 
        }

        $db->Query("UPDATE db_users_a SET email_verify = '1' WHERE `user` = '$uname'");

        header( 'Refresh: 0; url=/user/settings' );

    }else{
        echo $func->error("E-mail уже подтвержден!");
        header( 'Refresh: 3; url=/user/settings' );
    } 

}

if (isset($_POST['go'])) {
    $email = $user_data['email'];

    $verif_key = "verify-".md5($email."_rfs_".$email);

    # Отправляем на почту
    $sender = new isender;
    $sender -> SendVerifKey($email, $verif_key);

    echo $func->error("Сылка выслана на Ваш E-mail", true);

    header( 'Refresh: 3; url=/user/settings' );
}

if (isset($_POST['nname'])) {

    if(preg_match("/^[0-9a-zA-Z]{3,12}$/i", $_POST['nname'])){

        $name = $func->clear($_POST['nname']);

        $db->Query("UPDATE db_users_a SET uname = '$name' WHERE `user` = '$uname'");

        echo $func->error("Имя успешно установлено!", true);
        header( 'Refresh: 3; url=/user/settings' );

    }else echo $func->error("Введите корректное имя.");

    
}

    if(isset($_POST["pass1"])){

        $old_pass = $func->IsPassword($_POST["pass1"]);
        $new_pass = $func->IsPassword($_POST["pass2"]);

        $old = $func->md5Password($old_pass);
        $new = $func->md5Password($new_pass);

        if($old !== false AND strtolower($old) == strtolower($user_data["pass"])){

            if($new !== false){

                if( strtolower($new_pass) == strtolower($_POST["pass3"])){

                    $db->Query("UPDATE db_users_a SET pass = '$new' WHERE id = '$usid'");

                    echo $func->error("Новый пароль успешно установлен!", true);
                    header( 'Refresh: 3; url=/user/settings' );

                }else echo $func->error("Пароль и повтор пароля не совпадают.");

            }else echo $func->error("Новый пароль имеет неверный формат.");

        }else echo $func->error("Старый паполь заполнен неверно.");

    }

    if(isset($_POST["paypass"])){

        $plat_passs = $func->plat_passs($_POST["paypass"]);
        $plat_pass = $func->md5Password($plat_passs);


        if($plat_passs !== false){

            $db->Query("UPDATE db_users_a SET plat_pass = '$plat_pass' WHERE id = '$usid'");

            echo $func->error("Платежный пароль успешно установлен!", true);
            header( 'Refresh: 2; url=/user/settings' );

        }else echo $func->error("Платежный пароль имеет неверный формат!");

    }

    
    if(isset($_POST['ava'])){

        if ($_FILES['avatar']['size'] > 0) {

            # === Грузим баннер на сервер === #
            $filename=$_FILES['avatar']['name'];
            $filetype=$_FILES['avatar']['type'];
            $filesize=$_FILES["avatar"]["size"];
            $filename = strtolower($filename);
            $filetype = strtolower($filetype);

            # Проверяем есть ли файлы с расширением *.PHP
            $pos = strpos($filename,'php');
            if(!($pos === false)) {
                echo $func->error("Ошибка! За тобой уже выехали!");
                #die('error1');
                header( 'Refresh: 0; url=/user/settings' );
            }

            if($filesize > 1024*2*1024){
                echo $func->error("Ошибка! Размер файла превышает два мегабайта!");
                #die('error2');
                header( 'Refresh: 0; url=/user/settings' );
            }

            #get the file ext
            $file_ext = strrchr($filename, '.');

            #проверяем расширание файла
            $whitelist = array(".jpg",".jpeg",".gif",".png");
            if (!(in_array($file_ext, $whitelist))) {
                echo $func->error("Ошибка! Загрузать можно только изображения с расширениями: .jpg,.jpeg,.gif,.png!");
                #die('error3');
                header( 'Refresh: 0; url=/user/settings' );
            }

            #check upload type
            $pos = strpos($filetype,'image');
            if($pos === false) {
                #die('error4');
                header( 'Refresh: 0; url=/user/settings' );
            }

            $imageinfo = getimagesize($_FILES['avatar']['tmp_name']);
            if($imageinfo['mime'] != 'image/gif' && $imageinfo['mime'] != 'image/jpeg'&& $imageinfo['mime'] != 'image/jpg'&& $imageinfo['mime'] != 'image/png') {
                #die('error5');
                header( 'Refresh: 0; url=/user/settings' );
            }

            #проверяем двойной тип файла (изображение с комментариями)
            if(substr_count($filetype, '/')>1){
                #die('error6');
                header( 'Refresh: 0; url=/user/settings' );
            }

            #загружаем в каталог
            #$uploaddir = 'uploads/banner/'.date("Y-m-d").'/' ;
            $uploaddir = 'img/avatar/';

            if (file_exists($uploaddir)) {

            }
            else
            {
                mkdir( $uploaddir, 0777);
            }

            #имя файла
            $namefile = md5(basename($_FILES['avatar']['name'])).$file_ext;
            $uploadfile = $uploaddir.$namefile;

            #Проверяем загружен ли файл
            if(is_uploaded_file($_FILES["avatar"]["tmp_name"])){
                #Если файл загружен успешно, перемещаем его из временной директории в конечную
                if (move_uploaded_file($_FILES['avatar']['tmp_name'], $uploadfile)) {
                    //echo "<img id=\"upload_id\" src=\"".$uploadfile."\"><br />";

                    $db->Query("UPDATE db_users_a SET ava = '$namefile' WHERE id = '$usid'");

                    echo $func->error("Аватр успешно загружен.", true);
                    header( 'Refresh: 3; url=/user/settings' );
                }
                else
                {
                    echo $func->error("Ошибка! Не удалось загрузить файл на сервер!");
                }

            }
            else
            {
                echo $func->error("Ошибка загрузки файла");
                echo $_FILES['avatar']['error'];
                /*
                Начиная с PHP 4.2.0, PHP возвращает код ошибки наряду с другими атрибутами принятого файла. Он расположен в массиве, создаваемом PHP при загрузке файла, и может быть получен при обращении по ключу ['error']. Говоря другими словами, код ошибки можно найти в переменной $_FILES['userfile']['error'].
                UPLOAD_ERR_OK

                Значение: 0; Ошибок не возникало, файл был успешно загружен на сервер.
                UPLOAD_ERR_INI_SIZE

                Значение: 1; Размер принятого файла превысил максимально допустимый размер, который задан директивой upload_max_filesize конфигурационного файла php.ini.
                UPLOAD_ERR_FORM_SIZE

                Значение: 2; Размер загружаемого файла превысил значение MAX_FILE_SIZE, указанное в HTML-форме.
                UPLOAD_ERR_PARTIAL

                Значение: 3; Загружаемый файл был получен только частично.
                UPLOAD_ERR_NO_FILE

                Значение: 4; Файл не был загружен.

                echo $_FILES['avatar']['error'];
                */

            }
            # === Грузим баннер на сервер === #

        }else echo $func->error("Ошибка! Выберите файл.");

    }

    if (isset($_POST['purse'])) {
        $purse1 = filter_input(INPUT_POST, 'purse1', FILTER_SANITIZE_STRING);
        $purse2 = filter_input(INPUT_POST, 'purse2', FILTER_SANITIZE_STRING);
        $purse3 = filter_input(INPUT_POST, 'purse3', FILTER_SANITIZE_STRING);
        $purse4 = filter_input(INPUT_POST, 'purse4', FILTER_SANITIZE_STRING);
        $purse5 = filter_input(INPUT_POST, 'purse5', FILTER_SANITIZE_STRING);
        $purse6 = filter_input(INPUT_POST, 'purse6', FILTER_SANITIZE_STRING);
        $purse7 = filter_input(INPUT_POST, 'purse7', FILTER_SANITIZE_STRING);
        $purse8 = filter_input(INPUT_POST, 'purse8', FILTER_SANITIZE_STRING);
        $purse9 = filter_input(INPUT_POST, 'purse9', FILTER_SANITIZE_STRING);
        $purse10 = filter_input(INPUT_POST, 'purse10', FILTER_SANITIZE_STRING);
        $purse11 = filter_input(INPUT_POST, 'purse11', FILTER_SANITIZE_STRING);

        if(strlen($purse1) == 0 AND strlen($purse2) == 0 AND strlen($purse3) == 0 AND strlen($purse4) == 0 AND strlen($purse5) == 0 AND strlen($purse6) == 0 AND strlen($purse7) == 0 AND strlen($purse8) == 0 AND strlen($purse9) == 0 AND strlen($purse10) == 0 AND strlen($purse11) == 0)
        {
            echo $func->error("Заполните одно любое поле.");
            #header( 'Refresh: 3; url='.$_SERVER['HTTP_REFERER'] );
        }
        else
        {
            # Payeer
            /*if(strlen($purse1) !== 0 AND $purse1 !== false){

                $purse1 = $func->ViewPursePayeer($_POST["purse1"]);

                if($purse1 !== false){
                    $db->Query("UPDATE `db_users_b` SET `payeer` = '$purse1' WHERE id = '$usid'");
                    echo $func->error("Кошелек успешно установлен.", true);
                }else{
                    echo $func->error("Кошелек Payeer указан неверно! Смотрите образец!");
                }
            }*/

            function setPurse($usid){
                GLOBAL $db;
                GLOBAL $func;

                $arrPaySys = array(
                        '1' => 'payeer',
                        '2' => 'yandex',
                        '3' => 'qiwi',
                        '4' => 'advcash',
                        '5' => 'okpay',
                        '6' => 'beeline',
                        '7' => 'tele2',
                        '8' => 'mts',
                        '9' => 'megafon',
                        '10' => 'wm',
                        '11' => 'visa',
                );

                for ($i=1; $i < 12; $i++) { 

                    $name = 'purse'.$i;
                    $$name=$i;
                
                    $name = filter_input(INPUT_POST, $name, FILTER_SANITIZE_STRING);

                    if(strlen($name) !== 0 AND $name !== false){

                        if ($i == 1) {
                            $purse = $func->ViewPursePayeer($name);
                        }elseif ($i == 2) {
                            $purse = $func->ViewPurseYandex($name);
                        }elseif ($i == 3) {
                            $purse = $func->ViewPurseQiwi($name);
                        }elseif ($i == 4) {
                            $purse = $func->ViewPurseAdvcash($name);
                        }elseif ($i == 5) {
                            $purse = $func->ViewPurseOkPay($name);
                        }elseif ($i == 6) {
                            $purse = $func->ViewPurseBeeline($name);
                        }elseif ($i == 7) {
                            $purse = $func->ViewPurseTele($name);
                        }elseif ($i == 8) {
                            $purse = $func->ViewPurseMts($name);
                        }elseif ($i == 9) {
                            $purse = $func->ViewPurseMegafon($name);
                        }elseif ($i == 10) {
                            $purse = $func->ViewPurseWebMoney($name);
                        }elseif ($i == 11) {
                            $purse = $func->ViewPurseCardVisa($name);
                        }else{
                            $purse = false;
                        }
                        
                        if($purse !== false){
                            $db->MultiQuery("UPDATE `db_users_b` SET `{$arrPaySys[$i]}` = '$purse' WHERE id = '$usid'");
                            echo $func->error("Кошелек успешно установлен.", true);
                        }else{
                            echo $func->error("Кошелек указан неверно! Смотрите образец!");
                        }

                    }

                }
            }

            echo setPurse($usid);

            header( 'Refresh: 3; url='.$_SERVER['HTTP_REFERER'] );

        }
    }
?>
<!-- <div class="content-page">

    <div class="content"> -->
        <!-- <div class="">
            <div class="page-header-title">
                <h4 class="page-title">Настройки аккаунта</h4>
            </div>
        </div> -->
        <div class="page-content-wrapper ">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="row">

                <?php 
                        if($user_data["email_verify"] == 0){
                ?>
                            <form method="POST" action="">
                                <!-- <input type="submit" name="go" value="Подтвердить"> -->
                            </form>
                            <div class="col-lg-12">
                                <div class="panel panel-gradient bg-grad bg-grad-15 panel-block-color panel-rounded">
                                    <div class="panel-heading">
                                        <h3 class="panel-title">Подтверждение E-mail</h3>
                                    </div>
                                    <div class="panel-body">
                                        <p class="settings_email">
                                            Пожалуйста подтвердите свой E-mail адрес, подтверждение необходимо для улучшения безопасности Вашего аккаунта, препятствует действиям мошенников и позволяет восстановить утерянный пароль. Так же не подтвердив свой E-mail Вы не сможете заказывать выплаты заработанных средств из проекта.
                                        </p>
                                        <form class="settings_formbox" action="" method="post">
                                            <div class="form-group">
                                                <input class="form-control index_rdl" type="email" required="" value="<?=$user_data["email"]?>" readonly></div>
                                            <button type="submit" name="go" class="btn waves-effect btn-darken btn-primary btn-block calc_btn"> <i class="fa fa-envelope"></i>
                                                Отправить сообщение
                                            </button>
                                        </form>
                                        <p class="settings_email m-t-10 m-b-0">
                                            Укажите свой E-mail адресс, и затем нажмите кнопку «Отправить сообщение», после чего зайдите на свой почтовый ящик и перейдите по ссылке из полученного письма. Проверяйте папку СПАМ, если письма нету.
                                        </p>
                                    </div>
                                    <div class="panel-footer settings_efooter">
                                        Мы не производим каких-либо рассылок на E-mail адреса участников проекта, а так же не передаем Ваши данные третьим лицам.
                                    </div>
                                </div>
                            </div>
                <?php
                        }else{
                ?>
                            <div class="col-lg-12">
                                <div class="panel panel-gradient bg-grad bg-grad-15 panel-block-color panel-rounded">
                                    <div class="panel-heading">
                                        <h3 class="panel-title">Подтверждение E-mail</h3>
                                        <div class="panel-toolbar v-centered">
                                            <ul class="list-inline m-a-0">
                                                <li class="settings_esuccess"><i class="fa fa-check"></i> Ваш E-mail успешно подтвержден!</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>

                <?php 
                        }
                ?>

                            <style>
							.panel-toolbar {
							position: absolute;
							right: 20px;
							top: 15px;
							}
							.bg-grad-15 {
							background: #4776e6 !important;
							background: -moz-linear-gradient(45deg, #4776e6 0%, #8e54e9 100%) !important;
							background: -webkit-linear-gradient(45deg, #4776e6 0%,#8e54e9 100%) !important;
							background: linear-gradient(45deg, #4776e6 0%,#8e54e9 100%) !important;
							filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#4776e6', endColorstr='#8e54e9',GradientType=1 ) !important;
							}
							.bg-grad {
							color: #fff !important;
							}
							style.css:2034
							.panel-block-color {
							border-width: 0;
							color: #fff;
							}
							.panel-block-color > .panel-heading {
							background-color: rgba(255,255,255,0.08);
							color: #fff;
							border-width: 0;
							}
							.panel-block-color > .panel-footer {
							border-color: rgba(255,255,255,0.1);
							background-color: transparent;
							color: #fff;
							border-top: 1px solid #7876ea;
							padding: 20px 20px;
							}
							.btn-darken {
							color: #fff;
							background-color: rgba(0,0,0,0.10) !important;
							border-color: rgba(0,0,0,0) !important;
							}
							.btn-darken:focus,
							.btn-darken.focus,
							.btn-darken:hover {
							color: #fff;
							background-color: rgba(1,1,1,0.18) !important;
							border-color: rgba(0,0,0,0.1) !important;
							}
							.settings_email{letter-spacing: 1px;font-size:110%;text-align:center;font-family: 'PT Sans Caption', sans-serif;}
							.settings_efooter{font-family: 'Philosopher', sans-serif;text-align:center;letter-spacing:1px;}
							.settings_esuccess{font-weight:bold;font-family: 'PT Sans Caption', sans-serif;letter-spacing:1px;}
							.index_rdl{background-color: rgba(245, 245, 245, 0.17) !important;border-color: rgba(255, 255, 255, 0.17);color: rgba(255, 255, 255, 0.88);font-family: 'PT Sans Caption', sans-serif;}
							</style>
                            <div class="col-lg-12">
                                <div class="panel panel-primary">
                                    <div class="panel-body">
                                        <hr>
                                        <div class="ideas_coment text-center">Изменение пароля:</div>
                                        <hr class="m-b-10">
                                        <div class="text-center m-t-10">
                                            <form action="" method="post" class="settings_formbox">
                                                <div class="form-group">
                                                    <input name="pass1" class="form-control" maxlength="20" minlength="6" type="password" required="" placeholder="Введите актуальный пароль"></div>
                                                <div class="form-group">
                                                    <input name="pass2" class="form-control" maxlength="20" minlength="6" type="password" required="" placeholder="Введите новый пароль"></div>
                                                <div class="form-group">
                                                    <input name="pass3" class="form-control" maxlength="20" minlength="6" type="password" required="" placeholder="Повторите новый пароль"></div>
                                                <button type="submit" class="btn waves-effect btn-primary btn-block calc_btn">
                                                    <i class="fa fa-cog"></i>
                                                    Изменить пароль
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="panel panel-primary">
                                    <div class="panel-body">
                                        <hr>
                                        <div class="ideas_coment text-center">Платежный пароль:</div>
                                        <hr class="m-b-10">
                                        <?php
                                        if(strlen($user_data['plat_pass']) == 1) {
                                        ?>
                                        <p class="settings_text"> <b>Обязательно устанавливайте платежный пароль!</b>
                                            Платежный пароль служит для защиты Ваших средств от мошенников, которые в результате различных махинаций могут завладеть Вашим аккаунтом.
                                        </p>
                                        <p class="settings_text">
                                            Установите платежный пароль, введя <b>любую комбинацию из 3-10 цифр</b>
                                            , которую Вы не сможете забыть, после чего при каждой попытке вывода средств из проекта система будет запрашивать платежный пароль для осуществления выплаты.
                                        </p>
                                        <div class="text-center m-t-10">
                                            <form action="" method="post" class="settings_formbox">
                                                <div class="form-group">
                                                    <input name="paypass" class="form-control" maxlength="10" minlength="3" type="password" required="" placeholder="Введите платежный пароль"></div>
                                                <button type="submit" class="btn waves-effect btn-primary btn-block calc_btn" style="width:400px;">
                                                    <i class="fa fa-cog"></i>
                                                    Установить платежный пароль
                                                </button>
                                            </form>
                                        </div>
                                        <?php
                                        } else {
                                        ?>

                                        <p class="settings_text"><b>Платежный пароль уже установлен!</b> Если вы забыли платёжный пароль - обратитесь в тех. поддержку.</p>
                                        <div class="text-center m-t-10">
                                            <!-- <form action="" method="post" class="settings_formbox"> -->
                                                <button type="submit" class="btn waves-effect btn-primary btn-block calc_btn"><i class="fa fa-envelope-o"></i> Платежный пароль установлен!</button>
                                            <!-- </form> -->
                                        </div>
                                        <?php 
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="panel panel-primary">
                                    <div class="panel-body text-center">
                                        <hr>
                                        <div class="ideas_coment text-center">Изменение аватарки:</div>
                                        <hr class="m-b-10">
                                        <img src="/img/avatar/<?=(strlen($user_data['ava']) > 1) ? $user_data['ava'] : 'nouser.png'?>" class="img-circle wall_ava m-b-15">
	                                    <form action="" enctype="multipart/form-data" method="post">
											<input name="avatar" type="file" class="filestyle" data-size="sm" required="" id="filestyle-0" tabindex="-1" style="position: absolute; clip: rect(0px, 0px, 0px, 0px);">
                                            <div class="bootstrap-filestyle input-group"><input type="text" class="form-control input-sm" placeholder="" disabled="">
                                                <span class="group-span-filestyle input-group-btn" tabindex="0">
                                                    <label for="filestyle-0" class="btn btn-default btn-sm">
                                                        <span class="icon-span-filestyle glyphicon glyphicon-folder-open"></span>
                                                        <span class="buttonText"> Выбрать файл</span>
                                                    </label>
                                                </span>
                                            </div>
											<button type="submit" name="ava" class="btn btn-dark waves-effect waves-light btn-block m-t-5" style="letter-spacing:1px;"><i class="fa fa-picture-o"></i> Обновить аватарку</button>
										</form>
                                        <!-- <form action="./settings?hex=eca11b38027adce9d4b9a31d87a46af8&avatar" enctype="multipart/form-data" method="post">
                                            <input name="avatar" type="file" class="filestyle" data-size="sm" required>
                                            <button type="submit" class="btn btn-dark waves-effect waves-light btn-block m-t-5" style="letter-spacing:1px;">
                                                <i class="fa fa-picture-o"></i>
                                                Обновить аватарку
                                            </button>
                                        </form> -->
                                    </div>
                                </div>
                            </div>
                            <style>
							.insert_new_btn {
							color: #fff;
							font-weight: 700;
							border: none;
							border-top-right-radius: 50px;
							border-bottom-right-radius: 50px;
							border-bottom-left-radius: 50px;
							border-top-left-radius: 50px;
							outline: none;
							-webkit-transition: 333ms ease-in-out;
							transition: 333ms ease-in-out;
							white-space: nowrap;
							overflow: hidden;
							text-overflow: ellipsis;
							padding: 10px 38px 10px;
							margin-top:10px;
							font-size: 15px;
							letter-spacing:1px;
							background-color: #ff8c00;
							-webkit-box-shadow: 0 10px 15px 0 rgba(255,140,0,.2);
							box-shadow: 0 7px 15px 0 rgba(255,140,0,.2);
							}
							.insert_new_btn:hover{color:#fff;-webkit-transition:133ms ease-in-out;transition:133ms ease-in-out-webkit-box-shadow:0 7px 30px 0 rgba(255,140,0,.4));box-shadow:0 7px 30px 0 rgba(255,140,0,.4);}
							.insert_new_input{border-radius: 50px;margin-bottom:15px;letter-spacing: 1px;text-align: center;background-color: #fdfdfd;height: 41px;font-size: 12px;}
							.insert_new_input:focus::-webkit-input-placeholder {color: transparent}
							.insert_new_input:focus::-moz-placeholder          {color: transparent}
							.insert_new_input:focus:-moz-placeholder           {color: transparent}
							.insert_new_input:focus:-ms-input-placeholder      {color: transparent}
							.settings_new_label{padding:0 15px;font-weight:300;letter-spacing:1px;font-size: 11px;color: #484848;width:100%;}
							.settings_new_label a{text-align:right;float: right;color: #9c2e0b;cursor: help;}
							.settings_new_label a:hover{color:#d22;}
							.insert_new_btn:active{color:#fff !important;}
							.insert_new_btn:focus{color:#fff !important;}
							.settings_pmodal{font-size: 13px;letter-spacing: 1px;text-align:justify;}
							.settings_modal_btn{letter-spacing: 1px;font-size: 13px;}
							</style>

							<script>

                                function delSys(activeS) {
                                    $.post("/ajax/dellsys.php?hex=<?=$token?>", {ps: activeS}).
                                    done(function(data) {
                                        if(data=="success") {
                                            swal({
                                                type: "success",
                                                title: "Отлично!",
                                                text: "Вы успешно заблокировали платежную систему.",
                                                timer: 5000
                                            });

                                            setTimeout(
                                                function() {
                                                    location.reload();
                                                }, 3000
                                            );
                                        }
                                        else if(data=="badkey") {
                                            document.location.reload(true);
                                        }
                                        else
                                        {
                                          swal({
                                              type: "warning",
                                              title: "Ошибка!",
                                              text: data,
                                              timer: 5000,
                                              showConfirmButton: true
                                          });
                                        }
                                    });
                                }

                            var activeS;
							function blockPurse() {
                                //location.href='./settings?hex=eca11b38027adce9d4b9a31d87a46af8&delsys='+activeS;
                                delSys(activeS);
                                //location.href='/user/settings';
							}

							function changeS(id) {
                                activeS=id;
                                if(id==1) {
                                    $("#nowpurse").html("PAYEER");
                                }
                                else if(id==2) {
                                    $("#nowpurse").html("Яндекс.Деньги");
                                }
                                else if(id==3) {
                                    $("#nowpurse").html("QIWI Wallet");
                                }
                                else if(id==4) {
                                    $("#nowpurse").html("ADV Cash");
                                }
                                else if(id==5) {
                                    $("#nowpurse").html("OKPAY");
                                }
                                else if(id==6) {
                                    $("#nowpurse").html("Билайн");
                                }
                                else if(id==7) {
                                    $("#nowpurse").html("TELE 2");
                                }
                                else if(id==8) {
                                    $("#nowpurse").html("МТС");
                                }
                                else if(id==9) {
                                    $("#nowpurse").html("Мегафон");
                                }
                                else if(id==10) {
                                    $("#nowpurse").html("WebMoney");
                                }
                                else if(id==11) {
                                    $("#nowpurse").html("Банковская карта");
                                }
							}
							</script>
                            <div class="col-lg-12">
                                <div class="panel panel-primary">
                                    <div class="panel-body">
                                        <hr>
                                        <div class="ideas_coment text-center">Кошельки для выплат:</div>
                                        <hr class="m-b-10">
                                        <form action="" method="post">
                                            <div class="form-group">
                                                <label class="settings_new_label">
                                                    PAYEER
                                                    <?=($data['payeer'] == 1) ? '' : '<a href="" onclick="changeS(1);" data-toggle="modal" data-target="#myModal">Заблокировать</a>'?>
                                                </label>
                                                <?php
                                                if ($data['payeer'] == 1) {
                                                    echo '<input name="purse1" type="text" class="form-control balancei_input insert_new_input" value="Кошелёк заблокирован" disabled="">';
                                                }elseif(strlen($data['payeer']) > 2){
                                                    echo '<input name="purse1" type="text" class="form-control balancei_input insert_new_input" value="'.$data['payeer'].'" disabled="disabled">';
                                                }else echo '<input name="purse1" type="text" class="form-control balancei_input insert_new_input" placeholder="Формат кошелька: P1000000">';
                                                ?>
                                            </div>
                                            <div class="form-group">
                                                <label class="settings_new_label">
                                                    Яндекс.Деньги
                                                    <?=($data['yandex'] == 1) ? '' : '<a href="" onclick="changeS(2);" data-toggle="modal" data-target="#myModal">Заблокировать</a>'?>
                                                </label>
                                                <?php
                                                if ($data['yandex'] == 1) {
                                                    echo '<input name="purse2" type="text" class="form-control balancei_input insert_new_input" value="Кошелёк заблокирован" disabled="">';
                                                }elseif(strlen($data['yandex']) > 2){
                                                    echo '<input name="purse2" type="text" class="form-control balancei_input insert_new_input" value="'.$data['yandex'].'" disabled="disabled">';
                                                }else echo '<input name="purse2" type="text" class="form-control balancei_input insert_new_input" placeholder="Формат кошелька: 410011499718000">';
                                                ?>
                                            </div>
                                            <div class="form-group">
                                                <label class="settings_new_label">
                                                    QIWI Wallet
                                                    <?=($data['qiwi'] == 1) ? '' : '<a href="" onclick="changeS(3);" data-toggle="modal" data-target="#myModal">Заблокировать</a>'?>
                                                </label>
                                                <?php
                                                if ($data['qiwi'] == 1) {
                                                    echo '<input name="purse3" type="text" class="form-control balancei_input insert_new_input" value="Кошелёк заблокирован" disabled="">';
                                                }elseif(strlen($data['qiwi']) > 2){
                                                    echo '<input name="purse3" type="text" class="form-control balancei_input insert_new_input" value="'.$data['qiwi'].'" disabled="disabled">';
                                                }else echo '<input name="purse3" type="text" class="form-control balancei_input insert_new_input" placeholder="Формат кошелька: +7953155XXXX">';
                                                ?>
                                            </div>
                                            <div class="form-group">
                                                <label class="settings_new_label">
                                                    ADV Cash
                                                    <?=($data['advcash'] == 1) ? '' : '<a href="" onclick="changeS(4);" data-toggle="modal" data-target="#myModal">Заблокировать</a>'?>
                                                </label>
                                                <?php
                                                if ($data['advcash'] == 1) {
                                                    echo '<input name="purse4" type="text" class="form-control balancei_input insert_new_input" value="Кошелёк заблокирован" disabled="">';
                                                }elseif(strlen($data['advcash']) > 2){
                                                    echo '<input name="purse4" type="text" class="form-control balancei_input insert_new_input" value="'.$data['advcash'].'" disabled="disabled">';
                                                }else echo '<input name="purse4" type="text" class="form-control balancei_input insert_new_input" placeholder="Формат кошелька: mail@example.com">';
                                                ?>
                                            </div>
                                            <div class="form-group">
                                                <label class="settings_new_label">
                                                    OKPAY
                                                    <?=($data['okpay'] == 1) ? '' : '<a href="" onclick="changeS(5);" data-toggle="modal" data-target="#myModal">Заблокировать</a>'?>
                                                </label>
                                                <?php
                                                if ($data['okpay'] == 1) {
                                                    echo '<input name="purse5" type="text" class="form-control balancei_input insert_new_input" value="Кошелёк заблокирован" disabled="">';
                                                }elseif(strlen($data['okpay']) > 2){
                                                    echo '<input name="purse5" type="text" class="form-control balancei_input insert_new_input" value="'.$data['okpay'].'" disabled="disabled">';
                                                }else echo '<input name="purse5" type="text" class="form-control balancei_input insert_new_input" placeholder="Формат кошелька: OK123456789">';
                                                ?>
                                            </div>
                                            <div class="form-group">
                                                <label class="settings_new_label">
                                                    Билайн
                                                    <?=($data['beeline'] == 1) ? '' : '<a href="" onclick="changeS(6);" data-toggle="modal" data-target="#myModal">Заблокировать</a>'?>
                                                </label>
                                                <?php
                                                if ($data['beeline'] == 1) {
                                                    echo '<input name="purse6" type="text" class="form-control balancei_input insert_new_input" value="Кошелёк заблокирован" disabled="">';
                                                }elseif(strlen($data['beeline']) > 2){
                                                    echo '<input name="purse6" type="text" class="form-control balancei_input insert_new_input" value="'.$data['beeline'].'" disabled="disabled">';
                                                }else echo '<input name="purse6" type="text" class="form-control balancei_input insert_new_input" placeholder="Формат кошелька: +7953155XXXX">';
                                                ?>
                                            </div>
                                            <div class="form-group">
                                                <label class="settings_new_label">
                                                    TELE 2
                                                    <?=($data['tele2'] == 1) ? '' : '<a href="" onclick="changeS(7);" data-toggle="modal" data-target="#myModal">Заблокировать</a>'?>
                                                </label>
                                                <?php
                                                if ($data['tele2'] == 1) {
                                                    echo '<input name="purse7" type="text" class="form-control balancei_input insert_new_input" value="Кошелёк заблокирован" disabled="">';
                                                }elseif(strlen($data['tele2']) > 2){
                                                    echo '<input name="purse7" type="text" class="form-control balancei_input insert_new_input" value="'.$data['tele2'].'" disabled="disabled">';
                                                }else echo '<input name="purse7" type="text" class="form-control balancei_input insert_new_input" placeholder="Формат кошелька: +7953155XXXX">';
                                                ?>
                                            </div>
                                            <div class="form-group">
                                                <label class="settings_new_label">
                                                    МТС
                                                    <?=($data['mts'] == 1) ? '' : '<a href="" onclick="changeS(8);" data-toggle="modal" data-target="#myModal">Заблокировать</a>'?>
                                                </label>
                                                <?php
                                                if ($data['mts'] == 1) {
                                                    echo '<input name="purse8" type="text" class="form-control balancei_input insert_new_input" value="Кошелёк заблокирован" disabled="">';
                                                }elseif(strlen($data['mts']) > 2){
                                                    echo '<input name="purse8" type="text" class="form-control balancei_input insert_new_input" value="'.$data['mts'].'" disabled="disabled">';
                                                }else echo '<input name="purse8" type="text" class="form-control balancei_input insert_new_input" placeholder="Формат кошелька: +7953155XXXX">';
                                                ?>
                                            </div>
                                            <div class="form-group">
                                                <label class="settings_new_label">
                                                    Мегафон
                                                    <?=($data['megafon'] == 1) ? '' : '<a href="" onclick="changeS(9);" data-toggle="modal" data-target="#myModal">Заблокировать</a>'?>
                                                </label>
                                                <?php
                                                if ($data['megafon'] == 1) {
                                                    echo '<input name="purse9" type="text" class="form-control balancei_input insert_new_input" value="Кошелёк заблокирован" disabled="">';
                                                }elseif(strlen($data['megafon']) > 2){
                                                    echo '<input name="purse9" type="text" class="form-control balancei_input insert_new_input" value="'.$data['megafon'].'" disabled="disabled">';
                                                }else echo '<input name="purse9" type="text" class="form-control balancei_input insert_new_input" placeholder="Формат кошелька: +7953155XXXX">';
                                                ?>
                                            </div>
                                            <div class="form-group">
                                                <label class="settings_new_label">
                                                    WebMoney
                                                    <?=($data['wm'] == 1) ? '' : '<a href="" onclick="changeS(10);" data-toggle="modal" data-target="#myModal">Заблокировать</a>'?>
                                                </label>
                                                <?php
                                                if ($data['wm'] == 1) {
                                                    echo '<input name="purse10" type="text" class="form-control balancei_input insert_new_input" value="Кошелёк заблокирован" disabled="">';
                                                }elseif(strlen($data['wm']) > 2){
                                                    echo '<input name="purse10" type="text" class="form-control balancei_input insert_new_input" value="'.$data['wm'].'" disabled="disabled">';
                                                }else echo '<input name="purse10" type="text" class="form-control balancei_input insert_new_input" placeholder="Формат кошелька: R291143207289">';
                                                ?>
                                            </div>
                                            <div class="form-group">
                                                <label class="settings_new_label">
                                                    Банковская карта
                                                    <?=($data['visa'] == 1) ? '' : '<a href="" onclick="changeS(11);" data-toggle="modal" data-target="#myModal">Заблокировать</a>'?>
                                                </label>
                                                <?php
                                                if ($data['visa'] == 1) {
                                                    echo '<input name="purse11" type="text" class="form-control balancei_input insert_new_input" value="Кошелёк заблокирован" disabled="">';
                                                }elseif(strlen($data['visa']) > 2){
                                                    echo '<input name="purse11" type="text" class="form-control balancei_input insert_new_input" value="'.$data['visa'].'" disabled="disabled">';
                                                }else echo '<input name="purse11" type="text" class="form-control balancei_input insert_new_input" placeholder="Формат кошелька: 2911432072895794">';
                                                ?>
                                            </div>
                                            <button type="submit" name="purse" class="btn waves-light btn-block balancei_btngo insert_new_btn">Сохранить изменения</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="myModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                        <h4 class="modal-title" id="mySmallModalLabel">Блокировка кошелька</h4>
                                    </div>
                                    <div class="modal-body">
                                        <p class="settings_pmodal">
                                            Блокировка кошелька
                                            <b id="nowpurse">Яндекс.Деньги</b>
                                            удалит его из формы установки кошельков в настройках аккаунта, тем самым не даст потенциальному злоумышленнику ввести свой кошелек и вывести на него Ваши средства.
                                        </p>
                                    </div>
                                    <div class="modal-footer">
                                        <p class="settings_pmodal" style="font-size:12px;">
                                            Мы рекомендуем блокировать все кошельки, которыми Вы не планируете пользоваться, в случае необходимости Вы сможете восстановить форму ввода кошельков через запрос в техническую поддержку проекта.
                                        </p>
                                        <button type="button" onclick="blockPurse();" class="btn btn-danger waves-effect waves-light settings_modal_btn">Удалить кошелек</button>
                                        <button type="button" class="btn btn-default waves-effect" data-dismiss="modal">Закрыть</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<!--     </div>
</div> -->