<?php
$id = (isset($_GET["id"])) ? (int)$_GET["id"] : NULL;
$id = filter_var($id, FILTER_SANITIZE_NUMBER_INT);

if ($id == false) {
    header("Location: /user/");
}

$array_items = array(
                1 => "a_t",
                2 => "b_t",
                3 => "c_t",
                4 => "d_t",
                5 => "e_t",
                6 => "f_t",
                7 => "g_t",
                8 => "h_t",
                9 => "j_t",
);

$db->Query("SELECT db_users_b.payment_sum,
                   db_users_b.user, 
                   db_users_a.referals,
                   db_users_a.date_reg,
                   db_users_b.from_referals,
                   db_users_b.a_t,db_users_b.b_t,db_users_b.c_t,db_users_b.d_t,db_users_b.e_t,db_users_b.f_t,db_users_b.g_t,db_users_b.h_t,db_users_b.j_t,
                   db_users_a.referer,
                   db_users_a.referer_id
            FROM db_users_a,db_users_b WHERE db_users_b.id = db_users_a.id AND db_users_a.id = '$id'");
if($db->NumRows() == 0){
    header("Location: /user/");
}
$data = $db->FetchArray();
 
$_OPTIMIZATION["title"] = "Стена пользователя ".$data['user'];

# ========= вывод всего заработано на рефералах ========= #
    $db->Query("SELECT doxod2 FROM db_users_a WHERE referer_id2 = '$id'");
    $doxod_refs2 = $db->FetchArray();
    $doxod_refs2['doxod2'];

    $db->Query("SELECT doxod3 FROM db_users_a WHERE referer_id3 = '$id'");
    $doxod_refs3 = $db->FetchArray();
    $doxod_refs3['doxod3'];

    $zarab_na_refax = $data["from_referals"] + $doxod_refs2['doxod2'] + $doxod_refs3['doxod3'];
# ========= /вывод всего заработано на рефералах ========= #

$allCars = $data['a_t']+$data['b_t']+$data['c_t']+$data['d_t']+$data['e_t']+$data['f_t']+$data['g_t']+$data['h_t']+$data['j_t'];


$db->Query("SELECT * FROM db_config WHERE id = '1' LIMIT 1");
$sonfig_site = $db->FetchArray();

$kyr1 = $data["a_t"]*$sonfig_site["a_in_h"];
$kyr2 = $data["b_t"]*$sonfig_site["b_in_h"];
$kyr3 = $data["c_t"]*$sonfig_site["c_in_h"];
$kyr4 = $data["d_t"]*$sonfig_site["d_in_h"];
$kyr5 = $data["e_t"]*$sonfig_site["e_in_h"];
$kyr6 = $data["f_t"]*$sonfig_site["f_in_h"];
$kyr7 = $data["g_t"]*$sonfig_site["g_in_h"];
$kyr8 = $data["h_t"]*$sonfig_site["h_in_h"];
$kyr9 = $data["j_t"]*$sonfig_site["j_in_h"];

$kyrcall = $kyr1+$kyr2+$kyr3+$kyr4+$kyr5+$kyr6+$kyr7+$kyr8+$kyr9;

$all = $kyrcall / $sonfig_site["items_per_coin"];
?>
<div class="page-content-wrapper ">
    <div class="container">
        <div class="row">
            <div class="col-sm-9">
                <div class="row">
                    <div class="col-sm-6 col-lg-4 partner_cl_top">
                        <div class="panel text-center">
                            <div class="panel-heading">
                                <h4 class="panel-title text-muted font-light profilemsz">Скорость заработка</h4>
                            </div>
                            <div class="panel-body p-t-0">
                                <h2 class="m-t-0 m-b-5 profilemst"> <i class="mdi mdi-speedometer text-danger m-r-10"></i>
                                    <b><?=sprintf("%.4f",$all);?>₽ / час</b>
                                </h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-4 partner_cl_top">
                        <div class="panel text-center">
                            <div class="panel-heading">
                                <h4 class="panel-title text-muted font-light profilemsz">Выплачено заработка</h4>
                            </div>
                            <div class="panel-body p-t-0">
                                <h2 class="m-t-0 m-b-5 profilemst"> <i class="mdi mdi-cash-multiple text-primary m-r-10"></i> <b><?=$func->numberFormat($data['payment_sum'])?>₽</b>
                                </h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-4 partner_cl_top">
                        <div class="panel text-center">
                            <div class="panel-heading">
                                <h4 class="panel-title text-muted font-light profilemsz">Количество рефералов</h4>
                            </div>
                            <div class="panel-body p-t-0">
                                <h2 class="m-t-0 m-b-5 profilemst">
                                    <i class="mdi mdi-account-network text-danger m-r-10"></i>
                                    <b><?=$data['referals']?> чел.</b>
                                </h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12">
                        <div class="panel panel-primary">
                            <div class="panel-body">
                                <h4 class="m-t-0">Машины в автопарке </h4>
                                <div class="row">
                                    <?php 
                                    for ($i=1; $i < 6; $i++) { 
                                        if ($data[$array_items[$i]] >= 1) {
                                            $all = $data[$array_items[$i]];
                                            for ($j = 0; $j < $all; $j++) {
                                                echo '<div class="col-lg-1 col-sm-2 col-xs-2">
                                                    <img src="/img/cars/n'.$i.'.png" class="profilecarimg">
                                                </div>';
                                            }
                                               
                                        }
                                    }   
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-primary">
                            <div class="panel-body text-center">
                                <img src="/img/nouser.png" class="img-circle wall_ava">
                                <p class="text-muted m-0 m-t-10">
                                    <i class="fa fa-dot-circle-o text-primary"></i>
                                    Online
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="panel panel-primary">
                            <div class="panel-body">
                                <h5 class="profileinfoh5">
                                    Статус:
                                    <span>игрок</span>
                                </h5>
                                <h5 class="profileinfoh5">
                                    Реферер:
                                    <span>
                                        <a href="/user/wall/<?=$data['referer_id']?>"><?=(empty($data['referer']) ? 'Сам пришел' : $data['referer'])?></a>
                                    </span>
                                </span>
                                </h5>
                                <h5 class="profileinfoh5">
                                    ID в системе:
                                    <span>#<?=$id?></span>
                                </h5>
                                <h5 class="profileinfoh5">
                                    Дата регистрации:
                                    <span><?=date("d.m.Y",$data['date_reg'])?></span>
                                </h5>
                                <hr>
                                <h5 class="profileinfoh5">
                                    Сумма выплат:
                                    <span><?=$func->numberFormat($data['payment_sum'])?>₽</span>
                                </h5>
                                <h5 class="profileinfoh5">
                                    Кол-во рефералов:
                                    <span><?=$data['referals']?> чел.</span>
                                </h5>
                                <h5 class="profileinfoh5">
                                    Доход с рефералов:
                                    <span><?=$func->numberFormat($zarab_na_refax)?>₽</span>
                                </h5>
                                <h5 class="profileinfoh5">
                                    Сделано кликов:
                                    <span><?=($clicks == 0) ? 'нет' : $clicks?></span>
                                </h5>
                                <h5 class="profileinfoh5 m-b-0">
                                    Машин в автопарке:
                                    <span><?=$allCars?> шт.</span>
                                </h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>