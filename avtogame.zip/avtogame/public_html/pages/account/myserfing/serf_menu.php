<center>
    <a href="/account/serfing" class="button-green-big" style="margin-top:0px;">Серфинг</a>
    <a href="/account/serfing/add" class="button-green-big" style="margin-top:0px;">Разместить ссылку</a>
    <a href="/account/serfing/cabinet" class="button-green-big" style="margin-top:0px;">Мои ссылки</a>
    <a href="/account/serfing/account" class="button-green-big" style="margin-top:0px;">Мой кабинет</a>
</center>