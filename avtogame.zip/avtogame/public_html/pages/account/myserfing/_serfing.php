<?php
######################################
# Модуль Серфинг для Fruit Farm
# Автор APTEMOH
# E-mail: anatolii.123456@yandex.ru
# Skype: ArtIncProject
# VK.com: https://vk.com/id381626457
######################################
define('TIME', time());
header("Content-Type: text/html; charset=utf-8");

$_OPTIMIZATION["title"] = "Сёрфинг сайтов";
$usid = $_SESSION["user_id"];
$usname = $_SESSION["user"];

$db->Query("SELECT * FROM db_users_a WHERE id = '".$_SESSION['user_id']."'");
$users_info = $db->FetchArray();

    if (isset($_GET['delete']))
    {
        $id = (int)$_GET['delete'];

        #if (isset($_SESSION['admin']))
        if ($config->serfIdAdmin() == $_SESSION["user_id"])
        {
            $db->query("SELECT `money`, `user_name` FROM `db_serfing` WHERE id = '".$id."' LIMIT 1");

            $result = $db->FetchArray();

            $db->query("UPDATE db_users_b SET money_p = money_p + '".$result['money']."' WHERE user = '".$result['user_name']."'");

            $db->query("DELETE FROM db_serfing WHERE id = '".$id."'");
            #$db->query("DELETE FROM db_serfing_view WHERE ident = '".$id."'");
        }
    }
?>
<script>

function getHTTPRequest()
{
    var req = false;
    try {
        req = new XMLHttpRequest();
    } catch(err) {
        try {
            req = new ActiveXObject("MsXML2.XMLHTTP");
        } catch(err) {
            try {
                req = new ActiveXObject("Microsoft.XMLHTTP");
            } catch(err) {
                req = false;
            }
        }
    }
    return req;
}

jQuery(document).ready(function(){
    $(".normalm").click(function(e){
        var oLeft = 0, oTop = 0;
        element = this;
        if (element.className == 'normalm') {
            do {
                oLeft += element.offsetLeft;
                oTop  += element.offsetTop;
            } while (element = element.offsetParent);
            var sx = e.pageX - oLeft;
            var sy = e.pageY - oTop;
            var elid = $(this).attr("id");
            fixed(elid, sx, sy);
        }
    });
})

function sendBug() {
    var id = $('.normalm').attr("id");
    var myReq = getHTTPRequest();
    var params = "id="+id+"&sendBug=sendBug";

    alert("Подать жалобу на №"+id+"?");

    function setBug() {

        if ((myReq.readyState == 4)&&(myReq.status == 200)) {
            var setBug = myReq.responseText;
            if (setBug != '') {
                alert(setBug);
            }else{
                alert(setBug);
            }
        }

    }

    myReq.open("POST", "/ajax/myserfing/us-cliker.php", true);
    myReq.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    myReq.setRequestHeader("Content-lenght", params.length);
    //myReq.setRequestHeader("Connection", "close");
    myReq.onreadystatechange = setBug;
    myReq.send(params);
    return false;
}

function showFrame(div, link) {
    window.open('http://avtogame.ru/user/serfing/view/'+link, '_blank');
    $(div).parent().parent().parent().parent().addClass("surfblockopen");
}

function goserf(obj)
{
    obj.parentNode.innerHTML = "<span class='textgreen'>Спасибо за визит</span>";
    return false;
}

function fixed(p1, p2, p3)
{
    var myReq = getHTTPRequest();
    var params = "p1="+p1+"&p2="+p2+"&p3="+p3;
    function setstate()
    {
        if ((myReq.readyState == 4)&&(myReq.status == 200)) {
            var resvalue = myReq.responseText;
            if (resvalue != '') {
                if (resvalue.length > 12) {

                    if (elem = document.getElementById(p1)) {
                        elem.style.backgroundImage = 'none';
                        elem.className = 'goadvsite';
                        if (p1 == 2) {
                            elem.innerHTML = '<a target="_blank" href="/'+resvalue+'" onclick="javascript:goserf(this);">Попался БОТ! Минус 1000 тебе!</a>';
                        }else{
                            elem.innerHTML = '<a target="_blank" href="/'+resvalue+'" onclick="javascript:goserf(this);">Просмотреть сайт рекламодателя</a>';
                        }

                    }
                } else {
                    if (elem = document.getElementById(resvalue)) {
                        $(elem).fadeOut('low', function() {
                            elem.innerHTML = "<td colspan='3'></td>";
                        });
                    }
                }
            }
        }
    }

    if (p1 == 2) {
        myReq.open("POST", "/ajax/myserfing/us-cliker.php", true);
        myReq.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        myReq.setRequestHeader("Content-lenght", params.length);
        //myReq.setRequestHeader("Connection", "close");
        myReq.onreadystatechange = setstate;
        myReq.send(params);
        return false;
    }

        myReq.open("POST", "/ajax/myserfing/us-fixedserf.php", true);
        myReq.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        myReq.setRequestHeader("Content-lenght", params.length);
        //myReq.setRequestHeader("Connection", "close");
        myReq.onreadystatechange = setstate;
        myReq.send(params);
        return false;

}
</script>

<link rel="stylesheet" href="/style/main.css" type="text/css" />

        
        <div class="page-content-wrapper ">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-body">
                                <p class="raceinfotext m-b-0">
                                    Нажмите по заголовку любой из доступных ссылок, дождитесь окончания таймера и получайте деньги на свой <b>баланс для вывода</b>
                                    ! Средства заработанные в сёрфинге Вы можете тратить на расширение своего
                                    <a href="/user/carpark">автопарка</a>
                                    , участвовать в азартных играх или просто
                                    <a href="/user/outpay">вывести</a>
                                    их из проекта любым удобным для Вас способом!
									<h3 class="panel-title racetabletitle"><i class="fa fa-list-ul"></i> Партнёрская программа на сёрфинг 100 %</h3>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-lg-12">
                        <div class="panel panel-default racerespan1">
                            <div class="panel-body text-center">
                                <p class="text-muted m-b-10 m-t-0">
                                    <code class="profilemsd">Вам необходимы посетители или рефералы?</code>
                                </p>
                                <button type="button" class="btn waves-effect btn-default" onclick="location.href='./serfing/add';"> <i class="mdi mdi-bullhorn"></i>
                                    Разместить сайт в сёрфинге
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">

<?php
    $db->query("SELECT ident, time_add FROM db_serfing_view WHERE user_id = '$usid' AND time_add + INTERVAL 24*60*60 SECOND > NOW()");

    while ($row_view = $db->FetchArray())
    {
        $visits[$row_view['ident']] = $row_view;
    }

    $db->Query("SELECT * FROM db_serfing WHERE `money` >= `price` and `status` = '2' ORDER BY high DESC, time_add DESC");

    if ($db->NumRows())
    {
        while ($row = $db->FetchArray())
        {

            if (isset($visits[$row['id']])) continue;

            if ($row['speed'] > 1)
            {
                if (mt_rand(1, $row['speed']) != 1) continue;
            }

            $high = ($row['high']) ? 'serfimghigh' : 'serfimg';
            $pay_user = number_format($row['price'] - $row['price'] * (10/100), 2); //оплата пользователю

            if ($row['rating'] == 1) {
                $cena = 20;
            }elseif ($row['rating'] == 2) {
                $cena = 40;
            }elseif ($row['rating'] == 3) {
                $cena = 60;
            }else{
                $cena = 0;
            }

            if ($row['id'] == 2) {
                # бот
?>
                    <div class="col-lg-12">
                        <div class="panel panel-default surfblock<?=$row['rating']?>">
                            <div class="panel-body">
                                <div class="surflink">
                                    <img src="https://www.google.com/s2/favicons?domain=<?=$row['url']?>">
                                    <h4>
                                        <a href="#" onclick="showFrame(this, '<?=$row['id']; ?>');" class="surflinkgoto waves-effect" title="Начать просмотр сайта">
                                            <small>«</small>
                                            <?=$row['title']?>
                                            <small>»</small>
                                        </a>
                                        <span id="<?=$row['id']; ?>" class="normalm"></span>
                                        <span onclick="sendBug();" style="cursor: pointer;" class="surfabuselink"><i class="fa fa-bug"></i> Жалоба</span>
                                        <!-- <a onclick="sendBug();" href="./surfing?report=58738" class="surfabuselink"> <i class="fa fa-bug"></i>
                                            Жалоба
                                        </a> -->
                                    </h4>
                                    <h6>
                                        <span class="surftimer">
                                            <i class="fa fa-clock-o"></i>
                                            Время просмотра: <?=$row['timer']?> сек.
                                        </span>
                                        <span class="surfprice">
                                            <i class="fa fa-money"></i>
                                            Оплата: -1000 руб.
                                        </span>
                                        <span class="surfactive">
                                            <?=($row['wind'] == 1) ? '<i class="fa fa-window-maximize"></i>Активное окно' : '';?>
                                        </span>
                                        <span class="surfviewleft">Осталось <?=1000?> просмотров</span>
                                    </h6>
                                </div>
                            </div>
                        </div>
                    </div>

            <!-- <tr id="tr<?=$row['id']; ?>">
                <td class="normal" width="40" valign="top">
                    <span id="adstatus<?=$row['id']; ?>" class="<?=$high; ?>" title="Реклама: <?=$row['id']; ?>, Рекламодатель: <?=$row['user_name']; ?> | <?=$row['url']; ?>"></span>
                </td>
                <td id="<?=$row['id']; ?>" class="normalm" valign="top">
                    <?=$row['title']; ?><br /><span class="desctext"><?=$row['desc']; ?></span>
                </td>
                <td class="normal" nowrap="nowrap" valign="top" style="width: 130px; text-align: right; padding-right: 10px;">
                    <span class="smoolgray" title="Осталось визитов">(<?php echo (int)($row['money']/$row['price']); ?>)</span>&nbsp;<span class="clickprice">-1000&nbsp;баксов</span><br />

                    <a class="workevents" href="/account/wall/<?=$row['user_name']; ?>" title="Рекламодатель" target="_blank"></a>
                    <a class="workvir" href="http://online.us.drweb.com/result/?url=<?=$row['url']; ?>" title="Проверить ссылку на вирусы" target="_blank"></a>
                </td>
            </tr> -->
<?php

            }else{
                # НЕ БОТ

?>                  <div class="col-lg-12">
                        <div class="panel panel-default surfblock<?=$row['rating']?>">
                            <div class="panel-body">
                                <div class="surflink">
                                    <img src="https://www.google.com/s2/favicons?domain=<?=$row['url']?>">
                                    <h4>
                                        <a href="#" onclick="showFrame(this, '<?=$row['id']?>');" class="surflinkgoto waves-effect" title="Начать просмотр сайта">
                                            <small>«</small>
                                            <?=$row['title']?>
                                            <small>»</small>
                                        </a>
                                        <span id="<?=$row['id']; ?>" class="normalm" style="cursor: pointer;"></span>
                                        <span onclick="sendBug();" style="cursor: pointer;" class="surfabuselink"><i class="fa fa-bug"></i> Жалоба</span>
                                        <!-- <a onclick="sendBug();" href="./surfing?report=58738" class="surfabuselink"> <i class="fa fa-bug"></i>
                                            Жалоба
                                        </a> -->
                                    </h4>
                                    <h6>
                                        <span class="surftimer">
                                            <i class="fa fa-clock-o"></i>
                                            Время просмотра: <?=$row['timer']?> сек.
                                        </span>
                                        <span class="surfprice">
                                            <i class="fa fa-money"></i>
                                            Оплата: <?=$row['price']?> руб.
                                        </span>
                                        <span class="surfactive">
                                            <?=($row['wind'] == 1) ? '<i class="fa fa-window-maximize"></i>Активное окно' : '';?>
                                        </span>
                                        <span class="surfviewleft">Осталось <?php echo (int)($row['money']/($cena/1000)); ?> просмотров</span>
                                    </h6>
                                </div>
                            </div>
                        </div>
                    </div>

            <!-- <tr id="tr<?=$row['id']; ?>">
                <td class="normal" width="40" valign="top">
                    <span id="adstatus<?=$row['id']; ?>" class="<?=$high; ?>" title="Реклама: <?=$row['id']; ?>, Рекламодатель: <?=$row['user_name']; ?> | <?=$row['url']; ?>"></span>
                </td>
                <td id="<?=$row['id']; ?>" class="normalm" valign="top">
                    <?=$row['title']; ?><br /><span class="desctext"><?=$row['desc']; ?></span>
                    <br/>
                    Просмотр: <?=$row['timer']; ?> сек.
                </td>
                <td class="normal" nowrap="nowrap" valign="top" style="width: 130px; text-align: right; padding-right: 10px;">
                    <span class="smoolgray" title="Осталось визитов">(<?php echo (int)($row['money']/$row['price']); ?>)</span>&nbsp;<span class="clickprice"><?=$pay_user; ?>&nbsp;баксов</span><br />
                    <?php if ($config->serfIdAdmin() == $_SESSION["user_id"]) { ?><a class="workcomp" href="/account/serfing/delete/<?=$row['id']; ?>" title="Удалить ссылку и вернуть деньги"></a><?php } ?>
                    <span onclick="sendBug();" style="cursor: pointer;">Подать жалобу</span> <a class="workbug" title="Подать жалобу" target="_blank"></a>
                    <?=($row['wind'] == 1) ? '<a class="window" title="Активное окно"></a>' : '';?>
                    <a class="workevents" href="/account/wall/<?=$row['user_name']; ?>" title="Рекламодатель" target="_blank"></a>
                    <a class="workvir" href="http://online.us.drweb.com/result/?url=<?=$row['url']; ?>" title="Проверить ссылку на вирусы" target="_blank"></a>
                </td>
            </tr> -->
<?php
            }
        }
    }
    else
    {
        echo "Нет сайтов для просмотра!";
    }
?>                   

                </div>
            </div>
        </div>
