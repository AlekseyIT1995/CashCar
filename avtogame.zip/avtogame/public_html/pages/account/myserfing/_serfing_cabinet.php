<?php
######################################
# Модуль Серфинг для Fruit Farm
# Автор APTEMOH
# E-mail: anatolii.123456@yandex.ru
# Skype: ArtIncProject
# VK.com: https://vk.com/id381626457
######################################
define('TIME', time());

header("Content-Type: text/html; charset=utf-8");
$_OPTIMIZATION["title"] = "Аккаунт | Кабинет Серфинга";

$msg = '';
$_SESSION['cnt'] = md5($_SESSION['user_id'].session_id());

$db->Query("SELECT * FROM db_users_b WHERE id = '".$_SESSION['user_id']."'");
$users_info = $db->FetchArray();

?>
<script>
function getHTTPRequest()
{
    var req = false;
    try {
        req = new XMLHttpRequest();
    } catch(err) {
        try {
            req = new ActiveXObject("MsXML2.XMLHTTP");
        } catch(err) {
            try {
                req = new ActiveXObject("Microsoft.XMLHTTP");
            } catch(err) {
                req = false;
            }
        }
    }
    return req;
}

 var  defsummin = 1;
            function advevent(badv, buse) 
            {
                var postc = '<?=$_SESSION['cnt']; ?>';
                var issend = true;
                if (buse == 3) issend = confirm("Обнулить счётчик просмотров ссылки №" + badv + "?");
                if (buse == 4) issend = confirm("Вы уверены что хотите удалить ссылку №" + badv + "?");
                if (issend)
                    senddata(badv, buse, postc, 1);
                return true;
            }
         
 
 function senddata(radv, ruse, rpostc, rmode)
{
    var myReq = getHTTPRequest();
    var params = "use="+ruse+"&mode="+rmode+"&adv="+radv+"&cnt="+rpostc;
    function setstate()
    {
        if ((myReq.readyState == 4)&&(myReq.status == 200)) {
            var resvalue = parseInt(myReq.responseText);
            //console.log("ass"+resvalue);
            if (resvalue > 0) {
                if (ruse == 1) {
                    document.getElementById("advimg"+radv).innerHTML = "<span class='serfcontrol-pause1' title='Остановить показ рекламной площадки' onclick='javascript:advevent(" + radv + ",2);'>Остановить показ</span>";
                    document.getElementById("status"+radv).innerHTML = "Показывается";
                } else
                if (ruse == 2) {
                    document.getElementById("advimg"+radv).innerHTML = "<span class='serfcontrol-play1' title='Запустить показ рекламной площадки' onclick='javascript:advevent(" + radv + ",1);'>Возобновить показ</span>";
                    document.getElementById("status"+radv).innerHTML = "Остановлен";
                } else
                if (ruse == 3) {
                    document.getElementById("erase"+radv).innerHTML = "0";
                } else
                if (ruse == 4) {
                    $('#adv'+radv).fadeOut('def');
                    //console.log("ass");
                } else
                if (ruse == 5) {
                    if ((resvalue > 0)&&(resvalue < 8))
                        document.getElementById("int"+radv).className = 'scon-speed-'+resvalue;
                } else
                if (ruse == 6) {
                    document.getElementById("status"+radv).innerHTML = "<span class='desctext' style='text-decoration: blink;'>Ожидает<br />проверки</span>";
                    document.getElementById("advimg"+radv).innerHTML = "<span class='serfcontrol-postmoder'></span>";
                } else
                if (ruse == 7) {
                    window.location.reload(true);
                }
            }
        }
    }
    myReq.open("POST", "/ajax/myserfing/us-advservice.php", true);
    myReq.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    myReq.setRequestHeader("Content-lenght", params.length);
    //myReq.setRequestHeader("Connection", "close");
    myReq.onreadystatechange = setstate;
    myReq.send(params);
    return false;
}

function submitform(formnum)
{
    if (document.forms['payform'+formnum].pay_order) {
        var field = document.forms['payform'+formnum].pay_order.value;
        var minsum = $('#minsum'+formnum).text();      
        var tm;
        function hidemsg()
        {
            $('#entermsg'+formnum).fadeOut('slow');
            if (tm)
                clearTimeout(tm);
        }
        field = field.replace(",", ".");
        if (field == '') {
            document.getElementById('entermsg'+formnum).innerHTML = "<span class='msgbox-error'>Введите необходимую сумму</span>";
            document.getElementById('entermsg'+formnum).style.display = '';
            tm = setTimeout(function() {
                hidemsg()
            }, 1000);
            return false;
        }
        rprice = parseFloat(field);
        if (isNaN(rprice)) {
            document.getElementById('entermsg'+formnum).innerHTML = "<span class='msgbox-error'>Значение должно быть числовым</span>";
            document.getElementById('entermsg'+formnum).style.display = '';
            tm = setTimeout(function() {
                hidemsg()
            }, 1000);
            return false;
        }
        if (rprice != field) {
            document.getElementById('entermsg'+formnum).innerHTML = "<span class='msgbox-error'>Значение должно быть числовым</span>";
            document.getElementById('entermsg'+formnum).style.display = '';
            tm = setTimeout(function() {
                hidemsg()
            }, 1000);
            return false;
        }
        if (rprice < minsum) {
            document.getElementById('entermsg'+formnum).innerHTML = "<span class='msgbox-error'>Сумма должна быть не менее "+minsum+" баксов</span>";
            document.getElementById('entermsg'+formnum).style.display = '';
            tm = setTimeout(function() {
                hidemsg()
            }, 1000);
            return false;
        }
        var rnote = document.forms['payform'+formnum].pay_adv.value;
        var rart = document.forms['payform'+formnum].pay_mode.value;
        var rcnt = document.forms['payform'+formnum].pay_cnt.value;
        senddatacart(rnote, rart, rprice, rcnt);
        return true;
    }
    return false;
}

function senddatacart(rnote, rart, rprice, rcnt)
{
    var myReq = getHTTPRequest();
    var params = "adv="+rnote+"&use="+rart+"&price="+rprice+"&cnt="+rcnt;
    function setstate()
    {
        if ((myReq.readyState == 4)&&(myReq.status == 200)) {
            var resvalue = myReq.responseText;
            if (resvalue != '') {
                if (resvalue > 0) {                   
                    document.getElementById("entermsg"+rnote).innerHTML = "<center>Оплачено</center>";
                    window.location.reload(true);
                } else
                    document.getElementById("entermsg"+rnote).innerHTML = "<span class='msgbox-error'>"+resvalue+"</span>";
            } else {
                document.getElementById("entermsg"+rnote).innerHTML = "<span class='msgbox-error'>Не удалось обработать запрос</span>";
            }
        } else {
            document.getElementById("entermsg"+rnote).innerHTML = "<span class='loading' title='Подождите пожалуйста...'></span>";
            document.getElementById("entermsg"+rnote).style.display = '';
        }
    }
    myReq.open("POST", "/ajax/myserfing/us-advservice.php", true);
    myReq.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    myReq.setRequestHeader("Content-lenght", params.length);
    //myReq.setRequestHeader("Connection", "close");
    myReq.onreadystatechange = setstate;
    myReq.send(params);
    return false;
}

function hideserfaddblock(bname) {
    if (document.getElementById(bname).style.display == 'none')
        document.getElementById(bname).style.display = '';
    else
        document.getElementById(bname).style.display = 'none';
    return false;
}
function alertbudget()
{
    alert("Пополните рекламный бюджет");
    return false;
}
function alertnochange()
{
    alert("Задание можно редактировать только раз в 3 часа");
    return false;
}

function reportformactivate(dnum, dmode) {
    if (dmode == 2)
        document.getElementById('delcomment'+dnum).style.display = '';
    else
    if (dmode == 3)
        document.getElementById('reversecomment'+dnum).style.display = '';
    document.getElementById('btns'+dnum).style.display = 'none';
    return false;
    }
</script> 
<style type="text/css">
.surftimer {
    color: rgb(169, 68, 66);
}
.surfprice {
    color: rgb(14, 105, 16);
    margin-left: 15px;
}
.surfviewleft {
    float: right;
    color: rgb(0, 0, 0);
    text-shadow: rgb(255, 255, 255) 1px 1px 1px;
}
.addsurf_balance {
    font-weight: bold;
    font-size: 16px;
    display: inline;
}
.addsurf_status {
    font-weight: bold;
    font-size: 16px;
    display: inline;
    float: right;
}
.addsurf_status span {
    font-weight: 100;
}
.text-warning {
    color: #f7b543;
}
.addsurf_balance a {
    font-weight: 100;
    color: #5e90bb;
    margin-left: 3px;
}
</style>
<link rel="stylesheet" href="/style/main.css" type="text/css" />
<div class="s-bk-lf">
	<div class="acc-title">Мои сайты в сёрфинге</div>
</div>
<div class="silver-bk">
<?include("serf_menu.php");?>
 <?php
 $db->Query("SELECT * FROM db_serfing WHERE user_name = '".$_SESSION['user']."' ORDER BY time_add DESC");
  
 if ($db->NumRows())
 {  
   while ($row = $db->FetchArray())
   {
     
    if ($row['rating'] == 1) {
      $tarif1 = 'Эконом';
      $tarif2 = '';
      $tarif3 = '';
    }elseif ($row['rating'] == 2) {
      $tarif1 = '';
      $tarif2 = 'Обычный';
      $tarif3 = '';
    }elseif ($row['rating'] == 3) {
      $tarif1 = '';
      $tarif2 = '';
      $tarif3 = 'Премиум';
    }else{
      $tarif1 = '';
      $tarif2 = '';
      $tarif3 = '';
    }


    if ($row['status'] == 1) {
      $status = 'ПостМодерация';
    }elseif ($row['status'] == 2) {
      $status = 'Показывается';
    }elseif ($row['status'] == 3) {
      $status = 'Остановлен';
    }elseif ($row['status'] == 0) {
      $status = 'Модерация';
    }else{
      $status = 'Error!';
    }
?>

      <table border="0" align="center" width="100%" id="adv<?=$row['id']; ?>">
        <tr>
            <td style="color: #000000; font-weight: bold;"><?=$row['title']?></td>
        </tr>
        <tr>
            <td>
                <table align="center" width="100%">
                    <tr>
                        <td><span class="surftimer"><i class="fa fa-mouse-pointer"></i> Просмотрено: <?=$row['view']?> раз.</span></td>
                        <td><span class="surfprice"><i class="fa fa-diamond"></i> Тариф: "<?=$tarif1?><?=$tarif2?><?=$tarif3?>"</span></td>
                        <td><span class="surfviewleft">Осталось <?php echo (int)($row['money']/$row['price']); ?> просмотров</span></td>
                    </tr>
                </table>
            </td>
        </tr>
        <tr>
            <td>
                <table align="center" width="100%">
                    <tr>
                        <td align="left"><div class="addsurf_balance"><i class="mdi mdi-square-inc-cash"></i> Баланс сайта: <span><?=$row['money'];?></span> <a style="cursor:pointer;"><span class="add-budgetnone1" title="Пополнить рекламный бюджет" onclick="javascript:hideserfaddblock('serfadd<?=$row['id'];?>');">[пополнить баланс]</span></a></div></td>
                        <td align="right">
                            <div class="addsurf_status"><i class="mdi mdi-apple-safari"></i> 
                              Статус: <span class="text-warning" id="status<?=$row['id'];?>"><?=$status?></span>
                            </div>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
        <tr>
            <td>
                <table align="center" width="100%" style="border: 1px solid black;border-collapse: collapse;">
                    <tr>
                        <td style="padding: 5px;border: 1px solid black;" align="center">
                            <i class="mdi mdi-google-play"></i>
                            <div id="advimg<?=$row['id'];?>" style="cursor: pointer;">
                                <?php   
                                if ($row['status'] == 0)
                                {
                                  ?><span class="serfcontrol-moder1">На модерации</span><?php
                                } 
                                else if ($row['status'] == 1)
                                {
                                  ?><span class="serfcontrol-postmoder1">Постмодерация</span><?php
                                }
                                else if ($row['status'] == 2)
                                {
                                  ?><span class="serfcontrol-pause1" title="Остановить показ ссылки" onclick="javascript:advevent(<?=$row['id']; ?>,2);">Остановить показ</span><?php
                                }
                                else if ($row['status'] == 3)
                                {
                                  if ($row['money'] >= $row['price'])
                                  {
                                    ?><span class="serfcontrol-play1" title="Запустить показ ссылки" onclick="javascript:advevent(<?=$row['id']; ?>,1);">Возобновить показ</span><?php
                                  }
                                  else
                                  {
                                    ?><span class="serfcontrol-play1" title="Запустить показ ссылки" onclick="javascript:alertbudget();">Возобновить показ</span><?php
                                  }           
                                } 
                                ?>
                                
                            </div>
                        </td>
                        <td style="padding: 5px;border: 1px solid black;" align="center"><i class="mdi mdi-settings"></i><a class="scon-edit1" href="/account/serfing/edit/<?=$row['id']; ?>" title="Редактировать сайт">Редактировать сайт</a></td>
                        <td style="padding: 5px;border: 1px solid black;" align="center">
                            <i class="mdi mdi-delete-forever"></i>
                            <span class="scon-delete1" style="cursor: pointer;" title="Удалить сайт" onclick="javascript:advevent(<?=$row['id']; ?>,4);">Удалить сайт</span>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
        <tr id="serfadd<?php echo $row['id']; ?>" style="display: none">
            <td class="ext" colspan="3">
                <form name="payform<?=$row['id']; ?>" class="pay-form" onkeypress="if (event.keyCode == 13) return false;">
                <input name="pay_cnt" value="<?=$_SESSION['cnt']; ?>" type="hidden">
                <input name="pay_mode" value="12" type="hidden">
                <input name="pay_user" value="<?=$_SESSION['user_id']; ?>" type="hidden">
                <input name="pay_adv" value="<?=$row['id']; ?>" type="hidden">Укажите сумму, которую вы хотите внести в бюджет рекламной площадки<br>(Минимум <span id="minsum<?=$row['id']; ?>"><?=$row['price']; ?></span> баксов)<input name="pay_order" maxlength="10" value="<?=number_format($row['price']*1000, 2, '.', ''); ?>" type="text"><center><span class="button-red" title="Внести средства в бюджет площадки" onclick="javascript:submitform(<?php echo $row['id']; ?>);">Оплатить</span></center></form>
                <div id="entermsg<?=$row['id']; ?>" style="display: none"></div>
            </td>
        </tr>
    </table>
    
    <BR/><BR/>
 
     <?php
   }
 } 
 else
 {
    echo 'У тебя ссылок нет! :(';
 }
 
 ?>
</div>