<?php
######################################
# Модуль Серфинг для Fruit Farm
# Автор APTEMOH
# E-mail: anatolii.123456@yandex.ru
# Skype: ArtIncProject
# VK.com: https://vk.com/id381626457
######################################

$_OPTIMIZATION["title"] = "Аккаунт | Серфинг | Аккаунт";
$usid = $_SESSION["user_id"];
$usname = $_SESSION["user"];

$db->Query("SELECT `serf`,`money_p` FROM db_users_b WHERE id = '$usid' LIMIT 1");
$user_data = $db->FetchArray();

$db->Query("SELECT COUNT(*) FROM db_serfing_view WHERE user_id = '$usid'");
$kolSerf = $db->FetchRow();
?>

<link rel="stylesheet" href="/style/main.css" type="text/css" />

<div class="s-bk-lf">
    <div class="acc-title">Аккаунт</div>
</div>
<div class="silver-bk">

    <?include("serf_menu.php");?>

    Ваша рекламный баланс: <?=number_format($user_data['serf'], 2, ".", "");?> RUB
    <BR/>
    Вы просмотрели <?=$kolSerf;?> шт. сайтов в серфинге. За 1000 будет печенька :)
    <BR/>

<?php
    #######################

    // db_payeer_insert
    if(isset($_POST["pay_process"])){

        $sum = round(floatval($_POST["sump"]),2);

        $minPay = "1";

        # Заносим в БД
        $db->Query("INSERT INTO `db_payeer_insert` (user_id, user, sum, date_add, pay) VALUES ('".$_SESSION["user_id"]."','".$_SESSION["user"]."','$sum','".time()."', '6')");

        $desc = base64_encode($_SERVER["HTTP_HOST"]." - SERFING - USER ".$_SESSION["user"]);
        $m_shop = $config->shopID;
        $m_orderid = $db->LastInsert();
        $m_amount = number_format($sum, 2, ".", "");
        $m_curr = "RUB";
        $m_desc = $desc;
        $m_key = $config->secretW;

        $arHash = array(
            $m_shop,
            $m_orderid,
            $m_amount,
            $m_curr,
            $m_desc,
            $m_key
        );
        $sign = strtoupper(hash('sha256', implode(":", $arHash)));

        if ($sum >= $minPay) { ?>

        <center>
        <form method="GET" action="//payeer.com/api/merchant/m.php">
            <input type="hidden" name="m_shop" value="<?=$config->shopID; ?>">
            <input type="hidden" name="m_orderid" value="<?=$m_orderid; ?>">
            <input type="hidden" name="m_amount" value="<?=number_format($sum, 2, ".", "")?>">
            <input type="hidden" name="m_curr" value="RUB">
            <input type="hidden" name="m_desc" value="<?=$desc; ?>">
            <input type="hidden" name="m_sign" value="<?=$sign; ?>">
            <input type="submit" name="m_process" value="Продолжить пополнение на <?=$m_amount;?> руб." />
        </form>
        </center>

        <?php
        }else{
            echo "<div style='color:red;' align='center'>Минимальная сумма пополнения ".$minPay." руб. <a href='' onclick='history.back()'>Назад</a></div>";
        }

        return;
    }


    # SWAP
    if(isset($_POST["swap_process"])){

        $sum = intval($_POST["sumswap"]);

        if($sum >= 10){

            if($user_data["money_p"] >= $sum){

                $add_sum = ($sonfig_site["percent_swap"] > 0) ? ( ($sonfig_site["percent_swap"] / 100) * $sum) + $sum : $sum;

                $ta = time();
                $td = $ta + 60*60*24*15;

                $db->Query("UPDATE db_users_b SET serf = serf + $add_sum, money_p = money_p - $sum WHERE id = '$usid'");
                $db->Query("INSERT INTO db_swap_ser (user_id, user, amount_b, amount_p, date_add, date_del) VALUES ('$usid','$usname','$add_sum','$sum','$ta','$td')");

                echo "<center><font color = 'green'><b>Обмен произведен</b></font></center><BR />";
                header( 'Refresh: 3; url=/account/serfing/account' );

            }else echo "<center><font color = 'red'><b>Недостаточно RUB для обмена</b></font></center><BR />";

        }else echo "<center><font color = 'red'><b>Минимальная сумма для обмена 10 RUB</b></font></center><BR />";

    }
?>

</br><b>Пополнить и заказать рекламу!</b>

</br></br>

<form method="POST" action="">
    Введите сумму :
    <input type="text" value="100" name="sump" size="7" maxlength="5" required="required" />
    <BR /><BR />
    <input type="submit" id="submit" name="pay_process" value="Пополнить" >
</form>


</br><b>Обмен с вывода на рекламный</b>

</br></br>

<form method="POST" action="">
    Введите сумму :
    <input type="text" value="100" name="sumswap" size="7" maxlength="5" required="required" />
    <BR /><BR />
    <input type="submit" id="submit" name="swap_process" value="Обменять" >
</form>

</div>