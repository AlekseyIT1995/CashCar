<?php
######################################
# Модуль Серфинг для Fruit Farm
# Автор APTEMOH
# E-mail: anatolii.123456@yandex.ru
# Skype: ArtIncProject
# VK.com: https://vk.com/id381626457
######################################
error_reporting(E_ALL);
ini_set('display_errors', 1);

define('TIME', time());

define('SERF_PRICE', 0.025); //минимальная стоимость просмотра
define('SERF_PRICE_TIMER', 0.2); //стоимость таймера
define('SERF_PRICE_MOVE', 0.8); //стоимость последующего перехода на сайт
define('SERF_PRICE_WIND', 0.8); //стоимость просмотра в активном окне
define('SERF_PRICE_HIGH', 0.5); //стоимость выделения ссылки
define('SERF_PRICE_TARGET', 1.2); //стоимость таргетинга


header("Content-Type: text/html; charset=utf-8");
$_OPTIMIZATION["title"] = "Панель управления сёрфингом";
$msg = '';

$usid = $_SESSION['user_id'];

$_SESSION['cnt'] = md5($usid.session_id());

$db->Query("SELECT * FROM db_users_b WHERE id = '$usid'");
$users_info = $db->FetchArray();
?>
<link rel="stylesheet" href="/style/main.css" type="text/css" />
<?php

# пополнить
if (isset($_POST['sum'])) {
    $id = (int)$_POST['id'];

    if ($func->myNum($_POST['sum']) == false) {
        echo $func->error("Введите сумму пополнения!");
    }

    $money = $func->myNum($_POST['sum']);

    if ($money >= 19.99) {

        if ($money <= 0) echo $func->error("Error!");

        if ($users_info['serf'] >= $money)
        {

            $db->query("UPDATE db_serfing SET `money` = `money` + '$money' WHERE id = '$id'");

            $db->query("UPDATE db_users_b SET `serf` = `serf` - '$money'  WHERE id = '$usid'");

            echo $func->error("Ваш счет пополнен.", true);
            header( 'Refresh: 3; url=/user/serfing/add' );
        }
        else
        {
            echo $func->error("Пополните свой счет!");
        }

    }else echo $func->error("Минимальная сумма пополнения 50 руб.");

}
# ----- END --------

//Данные для формы (по умолчанию)
$title = '';
$desc = '';
$url = 'http://';
$timer = 20;
$move = 0;
$wind = 0;
$high = 0;
$speed = 1;
$rating = 1;

$advedit = isset($_GET['advedit']) ? (int)$_GET['advedit'] : false; 

$user_name = $_SESSION['user'];

if (!$advedit && isset($_POST['ask_editcode'])) { $advedit = (int)$_POST['ask_editcode']; }


if ($advedit)
{  
    #if (isset($_SESSION['admin'])) 
    if ($config->serfIdAdmin() == $usid)
    {
        $db->query("SELECT * FROM `db_serfing` WHERE id = '".$advedit."' LIMIT 1");
    } 
    else
    { 
        $db->query("SELECT * FROM `db_serfing` WHERE `id` = '$advedit' AND `user_name` = '$user_name' LIMIT 1");
    }
      
    if ($db->NumRows())
    {
        $result = $db->FetchArray();    
        
        //Подставляем данные из БД для формы редактирования
        $title = $result['title'] ? $result['title'] : '';
        $desc = $result['desc'] ? $result['desc'] : '';
        $url = $result['url'] ? $result['url'] : '';   
        $timer = $result['timer'] ? $result['timer'] : 20;
        $move = $result['move'] ? $result['move'] : 0;
        $wind = $result['wind'] ? $result['wind'] : 0;
        $high = $result['high'] ? $result['high'] : 0;
        $speed = $result['speed'] ? $result['speed'] : 1;
        $rating = $result['rating'] ? $result['rating'] : 1; # Тариф
        $status = $result['status'];
    } 
    else 
    {
        #exit(1);
        $show = true;
    }
} 


if (isset($_POST['title']))
{
    //Заголовок ссылки
    $title = filter_var(mb_substr(trim($_POST['title']), 0, 55), FILTER_SANITIZE_STRING);
    
    //Краткое описание ссылки
    $desc = mb_substr(trim(""),0 ,55);

    // Тариф
    $rating = isset($_POST['type']) ? trim($_POST['type']) : '1';
    
    //URL сайта
    $url = isset($_POST['url']) ? trim($_POST['url']) : '';  
    if (!filter_var($url, FILTER_VALIDATE_URL)) { echo '<span class="msgbox-error">Неверный адрес сайта</span>'; return; }

    //Если не заполнены основные поля
    if ($title == '' || $url == '') { echo '<span class="msgbox-error">Заполнены не все поля</span>'; return; }

    if (isset($_POST['type'])) {
        $type = (int)$_POST['type'];

        if ($type == 1) {
            # Первый тариф
            
            //Время просмотра ссылки
            $timer = 1;
            $timer_arr = array('1' => 5, '2' => 10, '3' => 15);
            if (!isset($timer_arr[$timer])) { echo '<span class="msgbox-error">Ошибка данных1</span>'; return; }
            
            //Последующий переход на сайт
            $move = 1;
            if ($move > 1 || $move < 0) { echo '<span class="msgbox-error">Ошибка данных2</span>'; return; }

            // Просмот в активном окне
            $wind = 0;
            if ($wind > 1 || $wind < 0) { echo '<span class="msgbox-error">Ошибка данных3</span>'; return; }
            
            //Выделить ссылку
            $high = 0;
            if ($high > 1 || $high < 0) { echo '<span class="msgbox-error">Ошибка данных4</span>'; return; }

            $price = number_format(0.01, 3, '.', '');

        }elseif ($type == 2) {
            # Второй тариф
            
            //Время просмотра ссылки
            $timer = 2;
            $timer_arr = array('1' => 5, '2' => 10, '3' => 15);
            if (!isset($timer_arr[$timer])) { echo '<span class="msgbox-error">Ошибка данных</span>'; return; }
            
            //Последующий переход на сайт
            $move = 1;
            if ($move > 1 || $move < 0) { echo '<span class="msgbox-error">Ошибка данных</span>'; return; }

            // Просмот в активном окне
            $wind = 0;
            if ($wind > 1 || $wind < 0) { echo '<span class="msgbox-error">Ошибка данных</span>'; return; }
            
            //Выделить ссылку
            $high = 1;
            if ($high > 1 || $high < 0) { echo '<span class="msgbox-error">Ошибка данных</span>'; return; }

            $price = number_format(0.02, 3, '.', '');

        }elseif ($type == 3) {
            # Третий тариф
            
            //Время просмотра ссылки
            $timer = 3;
            $timer_arr = array('1' => 5, '2' => 10, '3' => 15);
            if (!isset($timer_arr[$timer])) { echo '<span class="msgbox-error">Ошибка данных</span>'; return; }
            
            //Последующий переход на сайт
            $move = 1;
            if ($move > 1 || $move < 0) { echo '<span class="msgbox-error">Ошибка данных</span>'; return; }

            // Просмот в активном окне
            $wind = 1;
            if ($wind > 1 || $wind < 0) { echo '<span class="msgbox-error">Ошибка данных</span>'; return; }
            
            //Выделить ссылку
            $high = 1;
            if ($high > 1 || $high < 0) { echo '<span class="msgbox-error">Ошибка данных</span>'; return; }

            $price = number_format(0.03, 3, '.', '');

        }else{
            echo "Error Type!";
        }
    }
    
    
    //Расчёт стоимости просмотра
    /*$price = SERF_PRICE; 
    
    if ($move == 1) {$price += SERF_PRICE_MOVE; }

    if ($wind == 1) {$price += SERF_PRICE_WIND; }
    
    if ($high == 1) { $price += SERF_PRICE_HIGH; }
    
    if ($timer == 30) { $price += SERF_PRICE_TIMER; } 
    else if ($timer == 40) { $price += (SERF_PRICE_TIMER * 2); } 
    else if ($timer == 50) { $price += (SERF_PRICE_TIMER * 3); } 
    else if ($timer == 60) { $price += (SERF_PRICE_TIMER * 4); }
   
   
    $price = number_format($price, 2, '.', '');*/
    
    if ($advedit) 
    {  
        #if (!isset($_SESSION['admin']))
        if ($config->serfIdAdmin() !== $usid)
        {
            if ($result['title'] != $title || $result['desc'] != $desc || $result['url'] != $url)
            {
                #$status = 0; 
                $status = '3';     
            }
        }  
   
        $db->query("UPDATE db_serfing SET `title` = '".$title."', `desc` = '".$desc."', `url` = '".$url."', `timer` = '".$timer."', `move` = '".$move."', `high` = '".$high."', `speed` = '".$speed."', `country` = '0', `rating` = '".$rating."', `wind` = '".$wind."', `price` = '".$price."', `status` = '".$status."' WHERE id = '".$advedit."'");
    
        #if (isset($_SESSION['admin']))
        if ($config->serfIdAdmin() == $usid) 
        {
            header('Location: /user/serfing/moder'); 
        } 
        else
        {
            //header('Location: /user/serfing/cabinet'); 
            header('Location: /user/serfing/add'); 
        }
    
        exit();
    }
    else
    { 
        #if (isset($_SESSION['admin']))
        if ($config->serfIdAdmin() == $usid)
        {
            $status = '3';
        }
        else
        {
            #$status = '0';
            $status = '3';
        }
   
        $db->query("INSERT INTO db_serfing
            (
            `user_name`,
            `time_add`,	    
            `title`,
            `desc`,
            `url`,         
            `timer`,
            `move`,
            `high`,
            `speed`,	  
            `country`,
            `rating`,
            `wind`,
            `price`,
            `status`
            )
            VALUES
            (
                '".$_SESSION['user']."',
                '".TIME."',
                '".$title."',
                '".$desc."',
                '".$url."', 
                '".$timer."',
                '".$move."', 
                '".$high."',
                '".$speed."',	  
                '0',
                '".$rating."', 
                '".$wind."',
                '".$price."',
                '".$status."'
            )");
      
        //echo '<span class="msgbox-success">Ссылка добавлена</span>';
      
        //header('Location: /user/serfing/cabinet'); exit();
        header('Location: /user/serfing/add'); exit();
    }  
} 

//end:

if ($rating == '1') {
    $selected1 = "selected";
    $selected2 = "";
    $selected3 = "";  
}elseif ($rating == '2') {
    $selected1 = "";
    $selected2 = "selected";
    $selected3 = ""; 
}elseif ($rating == '3') {
    $selected1 = "";
    $selected2 = "";
    $selected3 = "selected"; 
}else{
    $selected1 = "";
    $selected2 = "";
    $selected3 = ""; 
}

?>
<script>
function SbmForm() {
    if (document.forms['surforder'].title.value == '') {
        alert('Вы не указали заголовок ссылки');
        document.forms['surforder'].title.focus();
        return false;
    }

    if (document.forms['surforder'].rule.value == '') {
        alert('Вы не согласились с правилами');
        document.forms['surforder'].rule.focus();
        return false;
    }

    // if (document.forms['surforder'].ask_desc.value == '') {
    //     alert('Вы не указали краткое описание ссылки');
    //     document.forms['surforder'].ask_desc.focus();
    //     return false;
    // }
    if ((document.forms['surforder'].url.value == '')|(document.forms['surforder'].url.value == 'http://')) {
        alert('Вы не указали URL-адрес ссылки');
        document.forms['surforder'].url.focus();
        return false;
    }
    
    document.forms['surforder'].submit();
    return true;
}
 
function PlanChange(frm)
{  
 
    lprice = serf_price;
    if (frm.ask_move.value == 1) {
        lprice += serf_price_move;
    }
    if (frm.ask_wind.value == 1) {
        lprice += serf_price_wind;
    }
    if (frm.ask_high.value == 1) {
        lprice += serf_price_high;
    }
    if (frm.ask_timer.value == 5) {
        lprice += serf_price_timer;
    } else
    if (frm.ask_timer.value == 10) {
        lprice += (serf_price_timer * 2);
    } else
    if (frm.ask_timer.value == 15) {
        lprice += (serf_price_timer * 3);
    } else
    if (frm.ask_timer.value == 20) {
        lprice += (serf_price_timer * 4);
    }

    frm.linkprice.value = number_format(lprice, 2, '.', '');
    
    //money = lprice * $('input[name=ask_kolvo]').val();
    
    //frm.money.value = number_format(money, 2, '.', '');
}

function number_format(number, decimals, dec_point, thousands_sep) {
    var i, j, kw, kd, km;
    if (isNaN(decimals = Math.abs(decimals))) {
        decimals = 2;
    }
    if (dec_point == undefined) {
        dec_point = ",";
    }
    if (thousands_sep == undefined) {
        thousands_sep = ".";
    }
    i = parseInt(number = (+number || 0).toFixed(decimals)) + "";
    if ((j = i.length) > 3) {
        j = j % 3;
    } else {
        j = 0;
    }
    km = (j ? i.substr(0, j) + thousands_sep : "");
    kw = i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + thousands_sep);
    kd = (decimals ? dec_point + Math.abs(number - i).toFixed(decimals).replace(/-/, 0).slice(2) : "");
    return km + kw + kd;
}
 
function showhide(bid) {
    if (document.getElementById('cattitle'+bid).className == 'cattitle-open')
        document.getElementById('cattitle'+bid).className = 'cattitle-close'; else
        document.getElementById('cattitle'+bid).className = 'cattitle-open';
    $('#catblock'+bid).slideToggle('fast');
}


    var serf_price = <?php echo SERF_PRICE; ?>;
    var serf_price_timer = <?php echo SERF_PRICE_TIMER; ?>;
    var serf_price_move = <?php echo SERF_PRICE_MOVE; ?>;
    var serf_price_wind = <?php echo SERF_PRICE_WIND; ?>;
    var serf_price_high = <?php echo SERF_PRICE_HIGH; ?>;
    var serf_price_target = <?php echo SERF_PRICE_TARGET; ?>;
    function ClearForm()
    {
        //document.forms['surforder'].ask_timer.value = <?php echo $timer; ?>;
        //document.forms['surforder'].ask_move.value = <?php echo $move; ?>;
        //document.forms['surforder'].ask_wind.value = <?php echo $wind; ?>;
        //document.forms['surforder'].ask_high.value = <?php echo $high; ?>;

        //document.forms['surforder'].ask_speed.value = <?php echo $speed; ?>;  
        //document.getElementById("ask_speed").value = "<?=$speed;?>"; 
        //PlanChange(document.forms['surforder']);
    }
    
    $(document).ready(function() { ClearForm(); });
   
// ------- cabinet -----------
function getHTTPRequest()
{
    var req = false;
    try {
        req = new XMLHttpRequest();
    } catch(err) {
        try {
            req = new ActiveXObject("MsXML2.XMLHTTP");
        } catch(err) {
            try {
                req = new ActiveXObject("Microsoft.XMLHTTP");
            } catch(err) {
                req = false;
            }
        }
    }
    return req;
}

 var  defsummin = 1;
            function advevent(badv, buse) 
            {
                var postc = '<?=$_SESSION['cnt']; ?>';
                //var issend = true;
                if (buse == 3) issend = confirm("Обнулить счётчик просмотров ссылки №" + badv + "?");
                if (buse == 4) {
                    //issend = confirm("Вы уверены что хотите удалить ссылку №" + badv + "?");
                    swal({
                       title: "Вы уверены?",   
                       text: "Площадка №" + badv + " будет удалена, баланс блока вернется вам на рекламный счет.",  
                       type: "warning",   showCancelButton: true,   confirmButtonColor: "#DD6B55",  
                       confirmButtonText: "Да, удалить!",   closeOnConfirm: false,
                       cancelButtonText: "Отмена",
                    }, function(){ 
                            swal("Удалено!", "Площадка удалена!", "success");
                            issend = true;
                            senddata(badv, buse, postc, 1); 
                    });
                }

                if (buse == 1 || buse == 2 || buse == 5 || buse == 6 || buse == 7) {
                    var issend = true;
                }

                if (issend)
                    senddata(badv, buse, postc, 1);
                return true;
            }
         
 
function senddata(radv, ruse, rpostc, rmode)
{
    var myReq = getHTTPRequest();
    var params = "use="+ruse+"&mode="+rmode+"&adv="+radv+"&cnt="+rpostc;
    function setstate()
    {
        if ((myReq.readyState == 4)&&(myReq.status == 200)) {
            var resvalue = parseInt(myReq.responseText);
            //console.log("ass"+resvalue);
            if (resvalue > 0) {
                if (ruse == 1) {
                    document.getElementById("advimg"+radv).innerHTML = "<span class='serfcontrol-pause1' title='Остановить показ рекламной площадки' onclick='javascript:advevent(" + radv + ",2);'>Остановить показ</span>";
                    document.getElementById("status"+radv).innerHTML = "Показывается";
                } else
                if (ruse == 2) {
                    document.getElementById("advimg"+radv).innerHTML = "<span class='serfcontrol-play1' title='Запустить показ рекламной площадки' onclick='javascript:advevent(" + radv + ",1);'>Возобновить показ</span>";
                    document.getElementById("status"+radv).innerHTML = "Остановлен";
                } else
                if (ruse == 3) {
                    document.getElementById("erase"+radv).innerHTML = "0";
                } else
                if (ruse == 4) {
                    $('#adv'+radv).fadeOut('def');
                    //console.log("ass");
                } else
                if (ruse == 5) {
                    if ((resvalue > 0)&&(resvalue < 8))
                        document.getElementById("int"+radv).className = 'scon-speed-'+resvalue;
                } else
                if (ruse == 6) {
                    document.getElementById("status"+radv).innerHTML = "<span class='desctext' style='text-decoration: blink;'>Ожидает<br />проверки</span>";
                    document.getElementById("advimg"+radv).innerHTML = "<span class='serfcontrol-postmoder'></span>";
                } else
                if (ruse == 7) {
                    window.location.reload(true);
                }
            }
        }
    }
    myReq.open("POST", "/ajax/myserfing/us-advservice.php", true);
    myReq.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    myReq.setRequestHeader("Content-lenght", params.length);
    //myReq.setRequestHeader("Connection", "close");
    myReq.onreadystatechange = setstate;
    myReq.send(params);
    return false;
}

function submitform(formnum)
{
    if (document.forms['payform'+formnum].pay_order) {
        var field = document.forms['payform'+formnum].pay_order.value;
        var minsum = $('#minsum'+formnum).text();      
        var tm;
        function hidemsg()
        {
            $('#entermsg'+formnum).fadeOut('slow');
            if (tm)
                clearTimeout(tm);
        }
        field = field.replace(",", ".");
        if (field == '') {
            document.getElementById('entermsg'+formnum).innerHTML = "<span class='msgbox-error'>Введите необходимую сумму</span>";
            document.getElementById('entermsg'+formnum).style.display = '';
            tm = setTimeout(function() {
                hidemsg()
            }, 1000);
            return false;
        }
        rprice = parseFloat(field);
        if (isNaN(rprice)) {
            document.getElementById('entermsg'+formnum).innerHTML = "<span class='msgbox-error'>Значение должно быть числовым</span>";
            document.getElementById('entermsg'+formnum).style.display = '';
            tm = setTimeout(function() {
                hidemsg()
            }, 1000);
            return false;
        }
        if (rprice != field) {
            document.getElementById('entermsg'+formnum).innerHTML = "<span class='msgbox-error'>Значение должно быть числовым</span>";
            document.getElementById('entermsg'+formnum).style.display = '';
            tm = setTimeout(function() {
                hidemsg()
            }, 1000);
            return false;
        }
        if (rprice < minsum) {
            document.getElementById('entermsg'+formnum).innerHTML = "<span class='msgbox-error'>Сумма должна быть не менее "+minsum+" баксов</span>";
            document.getElementById('entermsg'+formnum).style.display = '';
            tm = setTimeout(function() {
                hidemsg()
            }, 1000);
            return false;
        }
        var rnote = document.forms['payform'+formnum].pay_adv.value;
        var rart = document.forms['payform'+formnum].pay_mode.value;
        var rcnt = document.forms['payform'+formnum].pay_cnt.value;
        senddatacart(rnote, rart, rprice, rcnt);
        return true;
    }
    return false;
}

function senddatacart(rnote, rart, rprice, rcnt)
{
    var myReq = getHTTPRequest();
    var params = "adv="+rnote+"&use="+rart+"&price="+rprice+"&cnt="+rcnt;
    function setstate()
    {
        if ((myReq.readyState == 4)&&(myReq.status == 200)) {
            var resvalue = myReq.responseText;
            if (resvalue != '') {
                if (resvalue > 0) {                   
                    document.getElementById("entermsg"+rnote).innerHTML = "<center>Оплачено</center>";
                    window.location.reload(true);
                } else
                    document.getElementById("entermsg"+rnote).innerHTML = "<span class='msgbox-error'>"+resvalue+"</span>";
            } else {
                document.getElementById("entermsg"+rnote).innerHTML = "<span class='msgbox-error'>Не удалось обработать запрос</span>";
            }
        } else {
            document.getElementById("entermsg"+rnote).innerHTML = "<span class='loading' title='Подождите пожалуйста...'></span>";
            document.getElementById("entermsg"+rnote).style.display = '';
        }
    }
    myReq.open("POST", "/ajax/myserfing/us-advservice.php", true);
    myReq.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    myReq.setRequestHeader("Content-lenght", params.length);
    //myReq.setRequestHeader("Connection", "close");
    myReq.onreadystatechange = setstate;
    myReq.send(params);
    return false;
}

function hideserfaddblock(bname) {
    if (document.getElementById(bname).style.display == 'none')
        document.getElementById(bname).style.display = '';
    else
        document.getElementById(bname).style.display = 'none';
    return false;
}
function alertbudget()
{
    alert("Пополните Баланс сайта");
    return false;
}
function alertnochange()
{
    alert("Задание можно редактировать только раз в 3 часа");
    return false;
}

function reportformactivate(dnum, dmode) {
    if (dmode == 2)
        document.getElementById('delcomment'+dnum).style.display = '';
    else
    if (dmode == 3)
        document.getElementById('reversecomment'+dnum).style.display = '';
    document.getElementById('btns'+dnum).style.display = 'none';
    return false;
}


function setAdv(gid) {
    $("#bid").html("Загрузка");
    $("#bdata").val("");
    $("#btitle").val("");
    $("#burl").val("");

    $.post("/ajax/myserfing/loadserf.php", { id: gid })

    .done(function(data) {
        if(data!='fail') {
            var fd=data.split("<br/>");
            $("#bid").html(fd[0]);
            $("#bdata").val(fd[0]);
            $("#btitle").val(fd[1]);
            $("#burl").val(fd[2]);
            $("#btype").val(fd[3]);
            console.log(fd[3]);
        }
        else
        {
            swal({
                type: "warning",
                title: "Ошибка!",
                text: "Данного блока не существует",
                timer: 5000,
                showConfirmButton: true
            });
        }
    });
}

function insBalance(gid) {
    $("#iid").html("Загрузка");
    $("#inow").html("");
    $("#idata").val("");

    $.post("/ajax/myserfing/inserf.php", { id: gid })

    .done(function(data) {
        if(data!='fail') {
            var fd=data.split("<br/>");
            $("#iid").html(fd[0]);
            $("#inow").html(fd[1]);
            $("#idata").val(fd[0]);
            nowcost=fd[2];
        }
        else
        {
            swal({
                type: "warning",
                title: "Ошибка!",
                text: "Данного блока не существует",
                timer: 5000,
                showConfirmButton: true
            });
        }
    });
}

function calClicks() {
    var seens;
    seens=Math.floor($("#isum").val()/nowcost);
    if(isNaN(seens)) {
        seens=0;
    }
    $("#chclc").val("Хватит на "+seens+" просмотров");
}
// ---------- END cabinet ------------     
</script> 

<style type="text/css">
.m-r-15 {
    margin-right: 15px !important;
}
.text-danger {
    color: #f03154;
}
.text-primary {
    color: #5cb45b;
}
.text-danger {
    color: #f03154;
}
@media (max-width: 1380px) and (min-width: 1330px)
.addsurf_h5 {
    padding-left: 10px;
    font-size: 14px;
}
.addsurf_h5 {
    text-align: left;
    font-size: 15px;
    font-weight: 100;
    padding-left: 60px;
}

.form-group {
    margin-bottom: 10px;
}
label {
    display: inline-block;
    max-width: 100%;
    margin-bottom: 5px;
    font-weight: 700;
}
.form-control {
    -moz-border-radius: 2px;
    -moz-box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
    -webkit-border-radius: 2px;
    -webkit-box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
    background-color: #fafafa;
    border-radius: 2px;
    border: 1px solid #eeeeee;
    box-shadow: none;
    height: 38px;
    color: rgba(0, 0, 0, 0.6);
    font-size: 14px;
}
.form-control {
    display: block;
    width: 100%;
    height: 34px;
    padding: 6px 12px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
    background-image: none;
    border: 1px solid #ccc;
    border-radius: 4px;
    -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
    box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
    -webkit-transition: border-color ease-in-out .15s,-webkit-box-shadow ease-in-out .15s;
    -o-transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
    transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
}
.checkbox {
    padding-left: 20px;
}
.checkbox, .radio {
    position: relative;
    display: block;
    margin-top: 10px;
    margin-bottom: 10px;
}
.checkbox input[type="checkbox"] {
    cursor: pointer;
    opacity: 0;
    z-index: 1;
    outline: none !important;
}
.checkbox label {
    display: inline-block;
    padding-left: 5px;
    position: relative;
}
.checkbox label, .radio label {
    min-height: 20px;
    padding-left: 20px;
    margin-bottom: 0;
    font-weight: 400;
    cursor: pointer;
}
.checkbox label::before {
    -o-transition: 0.3s ease-in-out;
    -webkit-transition: 0.3s ease-in-out;
    background-color: #ffffff;
    border-radius: 3px;
    border: 1px solid #cccccc;
    content: "";
    display: inline-block;
    height: 17px;
    left: 0;
    margin-left: -20px;
    position: absolute;
    transition: 0.3s ease-in-out;
    width: 17px;
    outline: none !important;
}
:after, :before {
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
}
.btn-primary {
    background-color: #5cb45b !important;
    border: 1px solid #5cb45b !important;
}
.btn-primary {
    color: #ffffff !important;
}
.btn {
    border-radius: 2px;
    padding: 6px 14px;
}
.waves-effect {
    position: relative;
    cursor: pointer;
    display: inline-block;
    overflow: hidden;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    -webkit-tap-highlight-color: transparent;
    vertical-align: middle;
    z-index: 1;
    will-change: opacity, transform;
    -webkit-transition: all 0.3s ease-out;
    -moz-transition: all 0.3s ease-out;
    -o-transition: all 0.3s ease-out;
    -ms-transition: all 0.3s ease-out;
    transition: all 0.3s ease-out;
}
.btn-primary {
    color: #fff;
    background-color: #337ab7;
    border-color: #2e6da4;
}
.btn {
    display: inline-block;
    padding: 6px 12px;
    margin-bottom: 0;
    font-size: 14px;
    font-weight: 400;
    line-height: 1.42857143;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    -ms-touch-action: manipulation;
    touch-action: manipulation;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    background-image: none;
    border: 1px solid transparent;
    border-radius: 4px;
}

@media (max-width: 1799px) and (min-width: 1199px)
.addsurf_priceform {
    float: none;
    display: block;
}
.addsurf_priceform {
    float: right;
    display: inline;
    padding-top: 8px;
    font-weight: bold;
}
.checkbox-primary input[type="checkbox"]:checked + label::after {
    /*color: #ffffff;*/
}
.checkbox input[type="checkbox"]:checked + label::after {
    content: "\f00c";
    font-family: 'FontAwesome';
}
.checkbox label::after {
    color: #555555;
    display: inline-block;
    font-size: 13px;
    height: 16px;
    left: -1;
    margin-left: -20px;
    padding-left: 3px;
    padding-top: 1px;
    position: absolute;
    top: 0;
    width: 16px;
}
.inw {
    background-color: #f1f1f1;
    /*border: 1px solid;*/
}
</style>

<?php 
if (isset($show) == false) {
?>

<div class="page-content-wrapper ">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="panel panel-default" id="in1">
                    <div class="panel-body text-center">
                        <h3 class="m-t-0 m-b-10 profilemst addsurf_topzag"> <i class="fa fa-car text-danger m-r-15"></i> <b>Тариф "Эконом"</b>
                        </h3>
                        <hr>
                        <h5 class="addsurf_h5 m-t-15"> <i class="fa fa-cube"></i>
                            Переход после просмотра:
                            <div class="text-primary">ДА</div>
                        </h5>
                        <h5 class="addsurf_h5">
                            <i class="fa fa-window-maximize"></i>
                            Просмотр в активном окне:
                            <div class="text-danger">НЕТ</div>
                        </h5>
                        <h5 class="addsurf_h5">
                            <i class="fa fa-bug"></i>
                            Защита от автокликеров:
                            <div class="text-primary">ДА</div>
                        </h5>
                        <h5 class="addsurf_h5">
                            <i class="fa fa-clock-o"></i>
                            Время просмотра сайта:
                            <div>5 секунд</div>
                        </h5>
                        <h5 class="addsurf_h5 m-b-15">
                            <i class="fa fa-eercast"></i>
                            Выделение в списке:
                            <div class="text-danger">НЕТ</div>
                        </h5>
                        <hr>
                        <h5 class="m-b-0 m-t-15 addsurf_price">Цена за 1000 просмотров: 20 руб.</h5>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="panel panel-default" id="in2">
                    <div class="panel-body text-center">
                        <h3 class="m-t-0 m-b-10 profilemst addsurf_topzag">
                            <i class="fa fa-plane text-danger m-r-15"></i> <b>Тариф "Обычный"</b>
                        </h3>
                        <hr>
                        <h5 class="addsurf_h5 m-t-15">
                            <i class="fa fa-cube"></i>
                            Переход после просмотра:
                            <div class="text-primary">ДА</div>
                        </h5>
                        <h5 class="addsurf_h5">
                            <i class="fa fa-window-maximize"></i>
                            Просмотр в активном окне:
                            <div class="text-danger">НЕТ</div>
                        </h5>
                        <h5 class="addsurf_h5">
                            <i class="fa fa-bug"></i>
                            Защита от автокликеров:
                            <div class="text-primary">ДА</div>
                        </h5>
                        <h5 class="addsurf_h5">
                            <i class="fa fa-clock-o"></i>
                            Время просмотра сайта:
                            <div>10 секунд</div>
                        </h5>
                        <h5 class="addsurf_h5 m-b-15">
                            <i class="fa fa-eercast"></i>
                            Выделение в списке:
                            <div class="text-primary">ДА</div>
                        </h5>
                        <hr>
                        <h5 class="m-b-0 m-t-15 addsurf_price">Цена за 1000 просмотров: 40 руб.</h5>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="panel panel-default" id="in3">
                    <div class="panel-body text-center">
                        <h3 class="m-t-0 m-b-10 profilemst addsurf_topzag">
                            <i class="fa fa-rocket text-danger m-r-15"></i>
                            <b>Тариф "Премиум"</b>
                        </h3>
                        <hr>
                        <h5 class="addsurf_h5 m-t-15">
                            <i class="fa fa-cube"></i>
                            Переход после просмотра:
                            <div class="text-primary">ДА</div>
                        </h5>
                        <h5 class="addsurf_h5">
                            <i class="fa fa-window-maximize"></i>
                            Просмотр в активном окне:
                            <div class="text-primary">ДА</div>
                        </h5>
                        <h5 class="addsurf_h5">
                            <i class="fa fa-bug"></i>
                            Защита от автокликеров:
                            <div class="text-primary">ДА</div>
                        </h5>
                        <h5 class="addsurf_h5">
                            <i class="fa fa-clock-o"></i>
                            Время просмотра сайта:
                            <div>15 секунд</div>
                        </h5>
                        <h5 class="addsurf_h5 m-b-15">
                            <i class="fa fa-eercast"></i>
                            Выделение в списке:
                            <div class="text-primary">ДА</div>
                        </h5>
                        <hr>
                        <h5 class="m-b-0 m-t-15 addsurf_price">Цена за 1000 просмотров: 60 руб.</h5>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-4">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Добавление сайта в сёрфинг</h3>
                    </div>
                    <div class="panel-body">
                        <form name="surforder" id="myform" method="post" action="/user/serfing/add" onsubmit="return SbmForm(); return false;">
                            <input type="hidden" name="ask_editcode" value="<?=$advedit?>" />
                            <div class="form-group">
                                <label>Заголовок рекламного блока:</label>
                                <div>
                                    <input name="title" type="text" maxlength="70" class="form-control" placeholder="Например: Отличный сайт, смотреть всем!" required></div>
                            </div>
                            <div class="form-group">
                                <label>URL сайта:</label>
                                <div>
                                    <input name="url" type="url" class="form-control" placeholder="Например: http://yandex.ru" value="http://" required></div>
                            </div>
                            <div class="form-group">
                                <label>Выберите тариф для показа:</label>
                                <select name="type" id="tarif" class="form-control">
                                    <option value="1" <?=$selected1;?>>Тариф "Эконом"</option>
                                    <option value="2" <?=$selected2;?>>Тариф "Обычный"</option>
                                    <option value="3" <?=$selected3;?>>Тариф "Премиум"</option>
                                </select>
                            </div>
                            <div class="checkbox checkbox-primary">
                                <input name="rule" value="1" id="checkbox222" type="checkbox" required>
                                <label for="checkbox222">
                                    Я согласен с
                                    <a data-toggle="modal" data-target="#addsurfmodalrules">правилами размещения</a>
                                    рекламы на сайте.
                                </label>
                            </div>
                            <div class="addsurf_fbtn">
                                <?php
                                if ($advedit)
                                {
                                  ?>                             
                                    <!-- <span class="button-green" title="Принять изменения" onclick="SbmForm();">Сохранить</span> -->
                                    <button type="button" onclick="SbmForm();" class="btn btn-primary waves-effect waves-light">Сохранить</button>
                                  <?php
                                } 
                                else
                                {
                                  ?>                            
                                    <!-- <span class="button-green" title="Разместить рекламу" onclick="SbmForm();">Добавить</span> -->
                                    <button type="button" onclick="SbmForm();" class="btn btn-primary waves-effect waves-light">Добавить сайт в сёрфинг</button>
                                  <?php
                                } 
                                ?>
                                <div class="addsurf_priceform">Цена за 1000 просмотров: <span id="price">20</span> руб.</div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg-8">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Мои сайты в сёрфинге</h3>
                    </div>
                    <div class="panel-body">
<?php
                    $db->Query("SELECT * FROM db_serfing WHERE user_name = '$user_name' ORDER BY time_add DESC");

                    if ($db->NumRows())
                    {

                        while ($row = $db->FetchArray())
                        {

                            if ($row['rating'] == 1) {
                                $tarif1 = 'Эконом';
                                $tarif2 = '';
                                $tarif3 = '';
                                $cena = 20;
                            }elseif ($row['rating'] == 2) {
                                $tarif1 = '';
                                $tarif2 = 'Обычный';
                                $tarif3 = '';
                                $cena = 40;
                            }elseif ($row['rating'] == 3) {
                                $tarif1 = '';
                                $tarif2 = '';
                                $tarif3 = 'Премиум';
                                $cena = 60;
                            }else{
                                $tarif1 = '';
                                $tarif2 = '';
                                $tarif3 = '';
                                $cena = 0;
                            }


                            if ($row['status'] == 1) {
                                $status = 'ПостМодерация';
                            }elseif ($row['status'] == 2) {
                                $status = 'Показывается';
                            }elseif ($row['status'] == 3) {
                                $status = 'Остановлен';
                            }elseif ($row['status'] == 0) {
                                $status = 'Модерация';
                            }else{
                                $status = 'Error!';
                            }
?>
                        <div class="panel panel-default addsurf_sitepan" id="adv<?=$row['id']; ?>">
                            <div class="panel-body">
                                <div class="addsurf_sitebox">
                                    <h4>
                                        <a href="" target="_blank" class="surflinkgoto waves-effect">«<?=$row['title']?>»</a>
                                    </h4>
                                    <h6>
                                        <span class="surftimer">
                                            <i class="fa fa-mouse-pointer"></i>
                                            Просмотрено: <?=$row['view']?> раз.
                                        </span>
                                        <span class="surfprice">
                                            <i class="fa fa-diamond"></i>
                                            Тариф: "<?=$tarif1?><?=$tarif2?><?=$tarif3?>"
                                        </span>
                                        <span class="surfviewleft">Осталось <?php echo (int)($row['money']/($cena/1000)); ?> просмотров</span>
                                    </h6>
                                    <hr class="m-t-15 m-b-15">
                                    <div>
                                        <div class="addsurf_balance">
                                            <i class="mdi mdi-square-inc-cash"></i>
                                            Баланс сайта:
                                            <span><?=$row['money'];?></span>
                                            <a onclick="insBalance('<?=$row['id']?>');" style="cursor:pointer;" data-toggle="modal" data-target=".addsurfmodalbalance">[пополнить баланс]</a>
                                        </div>
                                        <div class="addsurf_status"><i class="mdi mdi-apple-safari"></i> 
                                            Статус: <span class="text-warning" id="status<?=$row['id'];?>"><?=$status?></span>
                                        </div>
                                    </div>
                                    <hr class="m-t-15 m-b-15">
                                    <div class="btn-group addsurf_btngroup">
                                        <button type="button" class="btn btn-default waves-effect addsurf_btn">
                                            <i class="mdi mdi-google-play"></i>
                                            <span id="advimg<?=$row['id'];?>" style="cursor: pointer;">
                                            <?php   
                                            if ($row['status'] == 0)
                                            {
                                            ?><span class="serfcontrol-moder1">На модерации</span><?php
                                            } 
                                            else if ($row['status'] == 1)
                                            {
                                            ?><span class="serfcontrol-postmoder1">Постмодерация</span><?php
                                            }
                                            else if ($row['status'] == 2)
                                            {
                                            ?><span class="serfcontrol-pause1" title="Остановить показ ссылки" onclick="javascript:advevent(<?=$row['id']; ?>,2);">Остановить показ</span><?php
                                            }
                                            else if ($row['status'] == 3)
                                            {
                                                if ($row['money'] >= $row['price'])
                                                {
                                                ?><span class="serfcontrol-play1" title="Запустить показ ссылки" onclick="javascript:advevent('<?=$row['id']; ?>','1');">Возобновить показ</span>
                                                <?php
                                                }
                                                else
                                                {
                                                ?><span class="serfcontrol-play1" title="Запустить показ ссылки" onclick="javascript:alertbudget();">Возобновить показ</span><?php
                                                }           
                                            } 
                                            ?></span>
                                        </button>
                                        <button type="button" class="btn btn-default waves-effect addsurf_btn" data-toggle="modal" data-target="#addsurfmodaledit" onclick="setAdv('<?=$row['id']?>');">
                                            <i class="mdi mdi-settings"></i>
                                            Редактировать сайт
                                        </button>
                                        <button type="button" class="btn btn-default waves-effect addsurf_btn" data-toggle="tooltip" data-placement="top" data-original-title="Баланс сайта вернется вам на рекламный счет">
                                            <i class="mdi mdi-delete-forever"></i>
                                            <span class="scon-delete1" style="cursor: pointer;" title="Удалить сайт" onclick="javascript:advevent(<?=$row['id']; ?>,4);">Удалить сайт</span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
<?php
                        }

                    }else{
                        echo 'У тебя ссылок нет! :(';
                    }
?>
                    </div>
                </div>
            </div>
        </div>

        <div id="addsurfmodalrules" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="addsurf_modal1" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                        <h4 class="modal-title" id="addsurf_modal1">Правила размещения рекламы</h4>
                    </div>
                    <div class="modal-body">
                        <h4>Запрещена реклама сайтов следующих категорий:</h4>
                        <p>- Фишинг, вирусы, секс-шопы, знакомства "на одну ночь";</p>
                        <p>- Сайты которые разрушают фрейм, сайты с редиректом;</p>
                        <p>
                            - Сайты содержащие порнографию, обилие эротических материалов;
                        </p>
                        <p>- Политические и религиозные ресурсы, любые виды насилия;</p>
                        <p>- Ресурсы с элементами магии, спиритизма, оккультизма;</p>
                        <p>- Ресурсы, с явно выраженным обманом;</p>
                        <p>
                            - Сайты набитые множеством партнёрок, всплывающих pop-up и т.д.
                        </p>
                        <p>- Ресурсы, требующие отправку платных СМС-сообщений</p>
                        <p style="color:#d22;">- Сайты-копии проектов команды ARCHI Developmnet LTD.</p>
                        <hr>
                        <h6>
                            В случае выявления нарушений к аккаунту пользователя могут быть применены штрафные санкции, вплоть блокировки аккаунта, в зависимости от строгости нарушения.
                        </h6>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default waves-effect" data-dismiss="modal">Закрыть</button>
                    </div>
                </div>
            </div>
        </div>
        <div id="addsurfmodaledit" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="addsurf_modal2" aria-hidden="true">
            <div class="modal-dialog balancep_modalwidth">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                        <h4 class="modal-title" id="addsurf_modal2">
                            Редактирование сайта #
                            <span id="bid"></span>
                        </h4>
                    </div>
                    <form action="./addsurfing?update&hex=01793a9387aa7c1b8b4c356b6aaa4e74" id="update" method="post">
                        <input type="hidden" name="id" id="bdata">
                        <div class="modal-body">
                            <div class="form-group m-t-5">
                                <label>Заголовок рекламного блока:</label>
                                <div>
                                    <input name="title" type="text" id="btitle" maxlength="70" class="form-control" value="Приглашай друзей и зарабатывай. Система только запущена!" placeholder="Например: Отличный сайт, смотреть всем!" required></div>
                            </div>
                            <div class="form-group">
                                <label>URL сайта:</label>
                                <div>
                                    <input name="url" type="url" id="burl" class="form-control" placeholder="Например: http://yandex.ru" value="http://www.taxi-money.info/" required></div>
                            </div>
                            <div class="form-group">
                                <label>Выберите тариф для показа:</label>
                                <select name="type" class="form-control" id="btype">
                                    <option value="1">Тариф "Эконом"</option>
                                    <option value="2">Тариф "Обычный"</option>
                                    <option value="3">Тариф "Премиум"</option>
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary waves-effect waves-light">Обновить настройки</button>
                            <button type="button" class="btn btn-default waves-effect" data-dismiss="modal">Отмена</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="modal fade addsurfmodalbalance" tabindex="-1" role="dialog" aria-labelledby="addsurf_modal3" aria-hidden="true">
            <div class="modal-dialog modal-sm">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                        <h4 class="modal-title" id="addsurf_modal3">
                            Баланс ссылки #
                            <span id="iid"></span>
                        </h4>
                    </div>
                    <div class="modal-body text-center">
                        <div class="addsurf_balance">
                            <i class="mdi mdi-square-inc-cash"></i>
                            Баланс сайта:
                            <span id="inow"></span>
                        </div>
                        <hr class="m-t-15 m-b-15">
                        <form action="/user/serfing/add" method="post">
                            <input type="hidden" name="id" id="idata">
                            <div class="form-group">
                                <label style="letter-spacing:1px;">Пополнить баланс сайта:</label>
                                <div>
                                    <input name="sum" autocomplete="new-password" id="isum" onkeyup="calClicks();" type="text" maxlength="9" class="form-control" placeholder="Введите сумму... (руб.)" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control balancei_input" id="chclc" value="Хватит на 0 просмотров" disabled></div>
                            <button type="submit" class="btn btn-primary waves-effect waves-light btn-block">Пополнить баланс</button>
                            <div id="entermsg<?=$row['id']; ?>" style="display: none"></div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<script type='text/javascript'>

    $(document).ready(function() {

        var val = '<?=$rating?>';
        if (val == 1) {
            price = 20;
            $("#in1").addClass("inw");
            $("#in2").removeClass("inw");
            $("#in3").removeClass("inw");

        }else if (val == 2) {
            price = 40;
            $("#in2").addClass("inw");
            $("#in1").removeClass("inw");
            $("#in3").removeClass("inw");
        }else if (val == 3) {
            price = 60;
            $("#in3").addClass("inw");
            $("#in2").removeClass("inw");
            $("#in1").removeClass("inw");
        }else{
            price = "Error!";
        }

    });

$('select[name=type]').change(function() { 
    var val = $(this).val();
    if (val == 1) {
        price = 20;
        $("#in1").addClass("inw");
        $("#in2").removeClass("inw");
        $("#in3").removeClass("inw");

    }else if (val == 2) {
        price = 40;
        $("#in2").addClass("inw");
        $("#in1").removeClass("inw");
        $("#in3").removeClass("inw");
    }else if (val == 3) {
        price = 60;
        $("#in3").addClass("inw");
        $("#in2").removeClass("inw");
        $("#in1").removeClass("inw");
    }else{
        price = "Error!";
    }
    $("#price").text(price);
    

});

</script>

<div id="entermsg"><?php if (!empty($msg)) { echo $msg; } ?></div>

</div>

<?php 
}else{
?>

<center><h2>Сайта с таким ID нет в серфинге или Вы пытаетесь отредактировать не свой заказ!</h2></center>

</div>
<?php
}
?>