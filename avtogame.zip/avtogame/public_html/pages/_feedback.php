<?php
$_OPTIMIZATION["title"] = "Отзывы";
$_OPTIMIZATION["description"] = "Отзывы проекта";
$_OPTIMIZATION["keywords"] = "Отзывы игрового проекта";
?>
<div class="head-page">
    <div class="container">
        <div class="row">
            <div class="col-md-12 fb_topbox">
                <div class="fb_tt" style="margin-top:0;">Мы на форумах:</div>
                <a href="http://mmgp.ru" target="_blank">
                    <img src="/img/mons/f_1.gif"></a>
                <a href="http://www.rusmmg.ru" target="_blank">
                    <img src="/img/mons/f_2.jpg"></a>
                <a href="http://antimmgp.ru" target="_blank">
                    <img src="/img/mons/f_3.jpg"></a>
                <a href="http://www.moneymaker.team" target="_blank">
                    <img src="/img/mons/f_4.gif"></a>
                <a href="http://amigoinvest.ru" target="_blank">
                    <img src="/img/mons/f_5.gif"></a>
                <div class="fb_tt">Мы на мониторингах:</div>
                <a href="http://netweb-monitor.ru" target="_blank">
                    <img src="/img/mons/1.gif"></a>
                <a href="http://profmonitgame.ru" target="_blank">
                    <img src="/img/mons/2.gif"></a>
                <a href="http://gamedom.ru" target="_blank">
                    <img src="/img/mons/3.gif"></a>
                <a href="https://bizoninvest.com" target="_blank">
                    <img src="/img/mons/4.gif"></a>
                <a href="http://digestgame.ru" target="_blank">
                    <img src="/img/mons/5.gif"></a>
                <a href="http://well-money.ru" target="_blank">
                    <img src="/img/mons/6.gif"></a>
                <a href="http://monitor-infobiz.ru" target="_blank">
                    <img src="/img/mons/7.gif"></a>
                <a href="http://monitorff.ru" target="_blank">
                    <img src="/img/mons/8.gif"></a>
                <a href="http://monhyip.net" target="_blank">
                    <img src="/img/mons/9.gif"></a>
                <a href="http://exmonitor.ru" target="_blank">
                    <img src="/img/mons/11.gif"></a>
                <a href="http://www.lordborg.com" target="_blank">
                    <img src="/img/mons/10.gif"></a>
                <a href="http://monitorings-games.ru" target="_blank">
                    <img src="/img/mons/12.gif"></a>
            </div>
        </div>
    </div>
</div>
<style>
.fb_topbox{background-color: #f3f7fa;box-shadow: 0 1px 3px #bbd0f6;padding:20px;text-align:center;}
.fb_tt{color: #8193a5;font-size: 21px;text-shadow: 3px 3px 5px #fff;font-weight: 700;letter-spacing: 2px;text-transform: uppercase;margin:20px 0;}
</style>
<?php
if(isset($_SESSION["user"])){
	
	$user_id = $_SESSION["user_id"];
	$usname = $_SESSION["user"];

	if (isset($_POST['text'])) {
		$text = $_POST['text'];
		
		if (isset($_POST['photo'])) {
			$photo = $_POST['photo'];
		}else $photo = 0;

		$db->Query("INSERT INTO db_feedback (user_id, user, text_fedd, scrin) VALUES ('$user_id','$usname','$text','$photo')");
	}
}
?>
<div class="content" style="padding-top:0;">
    <div class="add-form">
<?php
if(isset($_SESSION["user"])){
?>
        <div class="container">
            <h2 class="title">
                <span class="title__mark">ДОБАВИТЬ</span>ОТЗЫВ:
            </h2>
            <p class="desc" style="margin-bottom: 15px;">
                Отзывы необходимы для формирования мнения о проекте для других участников. Мы очень рады каждому отзыву, пожалуйста пишите их максимально развернуто, например опишите плюсы и минусы проекта, свои пожелания его дальнейшей работе. Спасибо!</b> 
			</p>
			<form action="" enctype="multipart/form-data" method="post" class="form">
				<div class="form__row row">
					<div class="col-md-12">
						<textarea name="text" class="textarea textarea_fullwidth" maxlength="750" placeholder="Введите текст отзыва, 80 - 750 символов"></textarea>
					</div>
				</div>
				<div class="form__row row">
					<div class="col-md-6">
						<p class="desc" style="margin-bottom: 8px;line-height: 1;">Загрузка скриншота выплаты: (необязательно, не более 1mb)</p>
						<input type="file" name="photo" accept="image/*"></div>
					<div class="col-md-6">
						<button class="btn btn" type="submit" style="float:right;">
							<span class="btn__text">Добавить отзыв</span>
						</button>
					</div>
				</div>
			</form>
		</div>
<?php
}
?>
	</div>
<div class="review-list" style="margin-top:50px;">

<?php 
$num_p = (isset($_GET["page"]) AND intval($_GET["page"]) < 1000 AND intval($_GET["page"]) >= 1) ? (intval($_GET["page"]) -1) : 0;
$lim = $num_p * $config->feedOnPage;

$db->Query("SELECT * FROM db_feedback WHERE status = '1' ORDER BY `id` DESC LIMIT {$lim}, $config->feedOnPage");

if($db->NumRows() > 0){

    while($feed = $db->FetchArray()){

        if ($feed['scrin'] == 0) {
            $scrin = false;
        }else{
            $scrin = '<a class="creenlink" href="/img/reviews/'.$feed['scrin'].'" target="_blank">
                        <i class="fa fa-picture-o"></i>Скриншот выплаты
                    </a>';
        }

        $userId = $feed['user_id'];
        $data = $db->MultiQuery("SELECT `ava` FROM db_users_a WHERE id = '$userId' LIMIT 1");
		if(isset($data)){
			$ava = 'nouser.png';
		}else $ava = (strlen($data[0][0]['ava']) > 1) ? $data[0][0]['ava'] : 'nouser.png';

        echo '<blockquote class="quote">
                <div class="container">
                    <div class="quote__header">
                        <figure class="quote__fig">
                            <img src="/img/avatar/'.$ava.'" alt="" />
                        </figure>
                        <div class="quote__author">
                            '.$feed['user'].'
                            '.$scrin.'
                        </div>
                        <div class="card__period">Опубликовано: '.$feed['data_time'].'</div>
                    </div>
                    <div class="quote__body">
                        '.$feed['text_fedd'].'
                    </div>
                </div>
            </blockquote>';
    }

}else echo '<blockquote class="quote"><div class="container"><div class="quote__body">Отзывов нет! Оставь свой отзыв и будь первым!</div></div></div>';
?>
</div>
<div class="container">
    <div class="col-md-12 text-center" style="padding-bottom:50px;">
<?php

$db->Query("SELECT COUNT(*) FROM db_feedback WHERE status = '1'");
$all_pages = $db->FetchRow();

    if($all_pages > $config->feedOnPage){
    
        $nav = new navigator;
        $page = (isset($_GET["page"]) AND intval($_GET["page"]) < 1000 AND intval($_GET["page"]) >= 1) ? (intval($_GET["page"])) : 1;
    
        echo "<BR /><center>".$nav->Navigation(10, $page, ceil($all_pages / $config->feedOnPage), "/feedback/"), "</center>";
    
    }

?>
<!--         <ul class="pagination">
            <li class="active">
                <a href="./feedback?p=1">1</a>
            </li>
            <li>
                <a href="./feedback?p=2">2</a>
            </li>
            <li>
                <a href="./feedback?p=3">3</a>
            </li>
            <li>
                <a href="./feedback?p=72">72</a>
            </li>
        </ul> -->
    </div>
</div>
</div>