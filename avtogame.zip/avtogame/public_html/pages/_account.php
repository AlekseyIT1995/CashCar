<?php
#####################################
# Автор APTEMOH
# E-mail: anatolii.123456@yandex.ru
# Skype: ArtIncProject
# VK.com: https://vk.com/id381626457
# Version: 1.1
#####################################

if(!defined('MY_KEY'))
{
    header("HTTP/1.1 404 Not Found");
    exit(file_get_contents('../404.html'));
}

$_OPTIMIZATION["title"] = "Аккаунт";
$_OPTIMIZATION["description"] = "Аккаунт пользователя";
$_OPTIMIZATION["keywords"] = "Аккаунт, личный кабинет, пользователь";

# Блокировка сессии
if(!isset($_SESSION["user_id"])){ Header("Location: /"); return; }

if(isset($_GET["sel"])){

    $smenu = strval($_GET["sel"]);

    switch($smenu){

        case "404": include("pages/_404.php"); break; // Страница ошибки
        case "carpark": include("pages/account/_carpark.php"); break; // Мой автопарк
        case "settings": include("pages/account/_settings.php"); break; // Настройки
        case "wall": include("pages/account/_wall.php"); break; // Стена
        case "training": include("pages/account/_training.php"); break; // Обучающий раздел
        case "insert": include("pages/account/_insert.php"); break; // Пополнить
        case "exchange": include("pages/account/_exchange.php"); break; // Обменник
        case "partnership": include("pages/account/_partnership.php"); break; // Партнерская программа
        case "myreferrals": include("pages/account/_myreferrals.php"); break; // Мои рефералы
        case "promo": include("pages/account/_promo.php"); break; // Рекламные материалы
        case "daily": include("pages/account/_daily.php"); break; // Бонус
        case "calculator": include("pages/account/_calculator.php"); break; // calculator
        case "outpay": include("pages/account/_outpay.php"); break; // Выплаты
        case "serfing": include("pages/account/myserfing/_serfing.php"); break; // Серфинг мой
        case "serfing_add": include("pages/account/myserfing/_serfing_add.php"); break; // Серфинг мой
        case "serfing_cabinet": include("pages/account/myserfing/_serfing_cabinet.php"); break; // Серфинг мой
        case "serfing_moder": include("pages/account/myserfing/_serfing_moder.php"); break; // Серфинг мой
        case "serfing_account": include("pages/account/myserfing/_serfing_account.php"); break; // Серфинг мой
        case "quests": include("pages/account/_quests.php"); break; // Квесты
		case "adv_balance": include("pages/account/_adv_balance.php"); break; // Квесты
		case "buyref": include("pages/account/_buyref.php"); break; // Биржа рефералов
		case "myref": include("pages/account/_myref.php"); break; // Биржа рефералов
		case "lottery": include("pages/account/_lottery.php"); break; // lottery
		case "race_leaders": include("pages/account/_race_leaders.php"); break; // race_leaders

        case "exit": 
            unset($_SESSION['user']);unset($_SESSION['admin']);session_destroy();session_unset();
            Header("Location: /"); return;
        break; // Выход

        # Страница ошибки
        default: include("pages/_404.php"); break;

    }

}else{
    include("pages/account/_user_account.php");
}

?>
