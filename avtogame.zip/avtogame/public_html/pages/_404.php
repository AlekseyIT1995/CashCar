<?php
$_OPTIMIZATION["title"] = "Ошибка";
$_OPTIMIZATION["description"] = "Указанная страница отсутствует на сервере";
$_OPTIMIZATION["keywords"] = "Ошибка, error, 404, Not Found";
?>
<div class="page-header">
	<br/><br/><br/>
    <center><h1>Страница не существует</h1></center>
</div>
<BR />
<center>
    <br/><br/><br/>
    <div class="acc-title">Ошибка 404</div>
    <br/><br/><br/>
</center>
