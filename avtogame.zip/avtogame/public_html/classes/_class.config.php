<?php
#####################################
# Автор APTEMOH
# E-mail: anatolii.123456@yandex.ru
# Skype: ArtIncProject
# VK.com: https://vk.com/id381626457
# Version: 1.1
#####################################

class config{

	public static $HostDBstatic = "localhost";
	public static $UserDBstatic = "toliasik_moto";
	public static $PassDBstatic = "bombae1";
	public static $BaseDBstatic = "toliasik_moto"; 

	public $HostDB = "localhost";
	public $UserDB = "toliasik_moto";
	public $PassDB = "bombae1";
	public $BaseDB = "toliasik_moto";    
	
    public $AdminPage = "adminass"; # сылка в админку /?menu=adminass
	public $SYSTEM_START_TIME = 1530204422;
	public $VAL = "RUB";
    public $VAL2 = "Руб.";
	public $TextInsert = "При пополнении - деньги поступят на счёт для покупок!"; # Текст на странице пополнения /user/insert ЕСЛИ ПУСТО ТЕКСТ НЕ ВЫВОДИТСЯ!
    public $feedOnPage = 2; # Отзывов на странице
	
	public $SITE_NAME = "Game-Game.biz";
	public $SUPPORT = "support@site.ru";

	# минимальная сумма обмена
	public $minSumSwap = 1;

	# минимальная сумма поплнения для того что бы вывести
	public $minForPayment = 0.99;

	/**
     * Возвращает ID админа
     * @return [type] = INT [description] = ID Админа
     */
    public function serfIdAdmin()
    {
        return $serfIdAdmin = 4;
    }

	# PAYEER настройки
	# выплаты
	public $AccountNumber = "P745****";
	public $apiId = "5994****";
	public $apiKey = "pGoSY*****";
	# поплнение
 	public $shopID = "599429334";
	public $secretW = "30AbPTCztJjEHDtp";

	# YandexMoney
	public $yandexMoney = '410013599960828';

	# AdvCash
    # SCI
    public $ac_sci_name = 'TestDemo';
    public $secret = 'qwerty';
    public $ac_account_name = 'anatolii.123456@yandex.ru'; # Который выводим при платеже
    public $ac_account_email = 'anatolii.123456@yandex.ru'; # на который зарегистрирован AdvCash
    public $saitUrl = "http://motor.art-script.ru"; # БЕЗ слеша / в конце
    # API
    #public $api_password = 'qwerty';
    #public $account_email = 'art@gmail.com';
    #public $api_name = 'MyAPI';

    # PerfectMoney настройки
    # SCI
    public $AccountNumberPM = "U1234567";  // Номер кошелька PerfectMoney
    public $StoreName       = "GameFF";    // StoreName  Название Store
    public $SecurityWord    = "qwerty";  // SecurityWord Альтернативная фраза
    #public $merchantEmail   = "anatolii.123456@yandex.ru";    // E-mail администратора
    # API
    #public $AutoPay    = "on";             // Автовыплаты (on - включены; off - выключены)
    #public $PmId       = "123456";         // ID PerfectMoney
    #public $PmPass     = "qwerty";         // Пароль от PerfectMoney
    public $SaitUrlStatus    = "http://motor.art-script.ru"; // Сылка на сайт

    # Free-Kassa настройки
    # SCI
    public $fk_merchant_id = '12345'; //merchant_id ID мазагина в free-kassa.ru http://free-kassa.ru/merchant/cabinet/help/
    public $fk_merchant_key = 'qwerty'; //Секретное слово http://free-kassa.ru/merchant/cabinet/profile/tech.php
    public $fk_merchant_key2 = 'ytrewq'; //Секретное слово2 (result) http://free-kassa.ru/merchant/cabinet/profile/tech.php
    # API
    public $wallet_id = ""; #Ваш номер кошелька
    public $API_KEY = ""; #API KEY

    # Mega-Kassa настройки
    # SCI
    public $secret_key = 'qwerty12345';
    public $shop_id = '3055';
    # API
    public $secret_api = 'qwerty12345';


}
?>