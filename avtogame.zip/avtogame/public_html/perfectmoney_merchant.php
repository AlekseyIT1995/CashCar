<?php
#########################################
# Модуль Perfect Money Скрипт Fruit Farm
# Автор APTEMOH
# E-mail: anatolii.123456@yandex.ru
# Skype: ArtIncProject
# VK.com: https://vk.com/id381626457
#########################################

# Автоподгрузка классов
function __autoload($name){ include("classes/_class.".$name.".php");}

# Класс конфига
$config = new config;

# Функции
$func = new func;

# База данных
$db = new db($config->HostDB, $config->UserDB, $config->PassDB, $config->BaseDB);


// Проверим то что у нас получилось с тем, что прислали нам из Perfect Money
//if ($hash==$_POST['V2_HASH'] && $_POST['PAYEE_ACCOUNT']==$conf_merchantAccountNumber && $_POST['PAYMENT_UNITS']=='USD')


$conf_merchantAccountNumber = $config->AccountNumberPM; //номер кошелька
$conf_merchantStoreName = $config->StoreName; //StoreName  Название Store
$conf_merchantPmId = $config->PmId;
$conf_merchantPmPass = $config->PmPass;
$conf_merchantSecurityWord = strtoupper(md5("".$config->SecurityWord."")); //SecurityWord  MD5 hash пароля для этого Store

/* Constant below contains md5-hashed alternate passhrase in upper case.
You can generate it like this:
strtoupper(md5('your_passphrase'));
Where `your_passphrase' is Alternate Passphrase you entered
in your Perfect Money account.*/

define('ALTERNATE_PHRASE_HASH',  $conf_merchantSecurityWord);

/* Two constants below are required to act additional payment
verification using Perfect Money API interface in purpose of
improving security. Please fill in them with your actual data.
Please note that you also need to turn on API for your server's
IP in your Perfect Money account.*/

define('PM_MEMBER_ID', $conf_merchantPmId); // Your Perfect Money member ID
define('PM_PASSWORD',  $conf_merchantPmPass); // Password you use to login your account

    function additionlPaymentCheckingUsingAPI(){

            $f=fopen('https://perfectmoney.is/acct/historycsv.asp?AccountID='.PM_MEMBER_ID.'&PassPhrase='.PM_PASSWORD.'&startmonth='.date("m", $_POST['TIMESTAMPGMT']).'&startday='.date("d", $_POST['TIMESTAMPGMT']).'&startyear='.date("Y", $_POST['TIMESTAMPGMT']).'&endmonth='.date("m", $_POST['TIMESTAMPGMT']).'&endday='.date("d", $_POST['TIMESTAMPGMT']).'&endyear='.date("Y", $_POST['TIMESTAMPGMT']).'&paymentsreceived=1&batchfilter='.$_POST['PAYMENT_BATCH_NUM'], 'rb');
            if($f===false) return 'error openning url';

            $lines=array();
            while(!feof($f)) array_push($lines, trim(fgets($f)));

            fclose($f);

            if($lines[0]!='Time,Type,Batch,Currency,Amount,Fee,Payer Account,Payee Account,Payment ID,Memo'){
            return $lines[0];
        }else{

            $ar=array();
            $n=count($lines);
            if($n!=2) return 'payment not found';

            $item=explode(",", $lines[1], 10);
            if(count($item)!=10) return 'invalid API output';
            $item_named['Time']=$item[0];
            $item_named['Type']=$item[1];
            $item_named['Batch']=$item[2];
            $item_named['Currency']=$item[3];
            $item_named['Amount']=$item[4];
            $item_named['Fee']=$item[5];
            $item_named['Payer Account']=$item[6];
            $item_named['Payee Account']=$item[7];
            $item_named['Payment ID']=$item[8];
            $item_named['Memo']=$item[9];

            if($item_named['Batch']==$_POST['PAYMENT_BATCH_NUM'] && $_POST['PAYMENT_ID']==$item_named['Payment ID'] && $item_named['Type']=='Income' && $_POST['PAYEE_ACCOUNT']==$item_named['Payer Account'] && $_POST['PAYMENT_AMOUNT']==$item_named['Amount'] && $_POST['PAYMENT_UNITS']==$item_named['Currency'] && $_POST['PAYER_ACCOUNT']==$item_named['Payee Account']){
                return 'OK';
            }else{
                return "Some payment data not match:
                batch:  {$_POST['PAYMENT_BATCH_NUM']} vs. {$item_named['Batch']} = ".(($item_named['Batch']==$_POST['PAYMENT_BATCH_NUM']) ? 'OK' : '!!!NOT MATCH!!!')."
                payment_id:  {$_POST['PAYMENT_ID']} vs. {$item_named['Payment ID']} = ".(($item_named['Payment ID']==$_POST['PAYMENT_ID']) ? 'OK' : '!!!NOT MATCH!!!')."
                type:  Income vs. {$item_named['Type']} = ".(('Income'==$item_named['Type']) ? 'OK' : '!!!NOT MATCH!!!')."
                payee_account:  {$_POST['PAYEE_ACCOUNT']} vs. {$item_named['Payer Account']} = ".(($item_named['Payee Account']==$_POST['PAYER_ACCOUNT']) ? 'OK' : '!!!NOT MATCH!!!')."
                amount:  {$_POST['PAYMENT_AMOUNT']} vs. {$item_named['Amount']} = ".(($item_named['Amount']==$_POST['PAYMENT_AMOUNT']) ? 'OK' : '!!!NOT MATCH!!!')."
                currency:  {$_POST['PAYMENT_UNITS']} vs. {$item_named['Currency']} = ".(($item_named['Currency']==$_POST['PAYMENT_UNITS']) ? 'OK' : '!!!NOT MATCH!!!')."
                payer account:  {$_POST['PAYEE_ACCOUNT']} vs. {$item_named['Payer Account']} = ".(($item_named['Payee Account']==$_POST['PAYER_ACCOUNT']) ? 'OK' : '!!!NOT MATCH!!!');
            }

        }

    }

// Path to directory to save logs. Make sure it has write permissions.
define('PATH_TO_LOG',  '/home/webog/domains/art-script.ru/public_html/motor/');

$string=
$_POST['PAYMENT_ID'].':'.$_POST['PAYEE_ACCOUNT'].':'.
$_POST['PAYMENT_AMOUNT'].':'.$_POST['PAYMENT_UNITS'].':'.
$_POST['PAYMENT_BATCH_NUM'].':'.
$_POST['PAYER_ACCOUNT'].':'.ALTERNATE_PHRASE_HASH.':'.
$_POST['TIMESTAMPGMT'];

$hash=strtoupper(md5($string));

/*
Please use this tool to see how valid hash is genereted:
https://perfectmoney.is/acct/md5check.html
*/
if($hash==$_POST['V2_HASH']){ // proccessing payment if only hash is valid

    /* In section below you must implement comparing of data you recieved
    with data you sent. This means to check if $_POST['PAYMENT_AMOUNT'] is
    particular amount you billed to client and so on. */

    if($_POST['PAYMENT_AMOUNT']==$_POST['PAYMENT_AMOUNT'] && $_POST['PAYEE_ACCOUNT']==$_POST['PAYEE_ACCOUNT'] && $_POST['PAYMENT_UNITS']=='USD'){
        //if($_POST['PAYMENT_AMOUNT']=='15.95' && $_POST['PAYEE_ACCOUNT']=='U1234567' && $_POST['PAYMENT_UNITS']=='USD'){

        $apcua=additionlPaymentCheckingUsingAPI();
        if($apcua=='OK'){

            $nokow = $_POST['PAYEE_ACCOUNT'];
            $nokowby = $_POST['PAYER_ACCOUNT'];
            //Payee_Account - счет получателя
            //Payer_Account - счет отправителя
            $timedat = $_POST['TIMESTAMPGMT'];
            $units = $_POST['PAYMENT_UNITS'];
            $batch_num = $_POST['PAYMENT_BATCH_NUM'];
            $PAYMENT_AMOUNT = $_POST['PAYMENT_AMOUNT'];
            $ip = $_POST["BAGGAGE_FIELDS_ip"];
            $paymentid = $_POST['PAYMENT_ID'];
            $uid = $_POST["BAGGAGE_FIELDS_id"];
            $typepayment = "PerfectMoney";
            $payment = "1"; //если 1, то есть платеж

            /*$db->Query("UPDATE `db_oplata_pm`
            SET `payment`='".$payment."',
            `nokow`='".$nokow."' ,
            `batch_num` = '".$batch_num."',
            `timedat` = '".$timedat."',
            `nokowby` = '".$nokowby."',
            `units` = '".$units."'
            WHERE `typepayment` = '".$typepayment."'
            AND `amount` = '".$PAYMENT_AMOUNT."'
            AND `id` = '".$paymentid."'
            AND `ip` = '".$ip."'"); //AND `memopay` = '".$uid."'*/

            $db->Query("SELECT * FROM `db_payeer_insert` WHERE id = '".intval($_POST['PAYMENT_ID'])."'");
            if($db->NumRows() == 0){ echo $_POST['PAYMENT_ID']."|error"; exit;}

            $payeer_row = $db->FetchArray();
            if($payeer_row["status"] > 0){ echo $_POST['PAYMENT_ID']."|success"; exit;}

            $db->Query("UPDATE `db_payeer_insert` SET status = '1' WHERE id = '".intval($_POST['PAYMENT_ID'])."'");

            $ik_payment_amount = $_POST['PAYMENT_AMOUNT'];
            $user_id = $payeer_row["user_id"];

            # Настройки
            $db->Query("SELECT * FROM db_config WHERE id = '1' LIMIT 1");
            $sonfig_site = $db->FetchArray();

            $db->Query("SELECT user, referer_id FROM db_users_a WHERE id = '{$user_id}' LIMIT 1");
            $user_ardata = $db->FetchArray();
            $user_name = $user_ardata["user"];
            $refid = $user_ardata["referer_id"];

            # Зачисляем баланс
            $serebro = sprintf("%.4f", floatval($sonfig_site["ser_per_wmr"] * $ik_payment_amount) );

            $db->Query("SELECT insert_sum FROM db_users_b WHERE id = '{$user_id}' LIMIT 1");
            $ins_sum = $db->FetchRow();

            $serebro = intval($ins_sum <= 0.01) ? ($serebro + ($serebro * 0.1) ) : $serebro;

            #$add_tree = ( $ik_payment_amount >= 499.99) ? 2 : 0; e_t = e_t + '$add_tree',
            $lsb = time();
            
            /* ====== Рефералка 3 уровня ====== */
            $db->Query("SELECT user, referer_id, referer_id2, referer_id3 FROM db_users_a WHERE id = '{$user_id}' LIMIT 1");
            $user_ardata = $db->FetchArray();
            $user_name = $user_ardata["user"];
            $refid = $user_ardata["referer_id"];
            $ref2 = $user_ardata["referer_id2"];
            $ref3 = $user_ardata["referer_id3"];

            $to_referer  = ($serebro * 0.04); // Первый уровень - 4 процента
            $to_referer2 = ($serebro * 0.03); // Второй уровень - 3 процента
            $to_referer3 = ($serebro * 0.01); // Третий уровень - 1 процент


            $db->Query("UPDATE db_users_b SET money_b = money_b + $to_referer2 WHERE id = '$ref2'");
            $db->Query("UPDATE db_users_b SET money_b = money_b + $to_referer3 WHERE id = '$ref3'");

            $db->Query("UPDATE db_users_a SET doxod2 = doxod2 + $to_referer2 WHERE id = '$user_id'");
            $db->Query("UPDATE db_users_a SET doxod3 = doxod3 + $to_referer3 WHERE id = '$user_id'");

            /* ====== /Рефералка 3 уровня ====== */

            # Зачисляем средства НАМ )
            $db->Query("UPDATE db_users_b
                        SET money_b = money_b + '$serebro',
                            to_referer = to_referer + '$to_referer',
                            insert_sum = insert_sum + '$ik_payment_amount'
                        WHERE id = '{$user_id}'"); # last_sbor = '$lsb',

            # Зачисляем средства рефереру и дерево
            #$add_tree_referer = ($ins_sum <= 0.01) ? ", a_t = a_t + 1" : "";
            $db->Query("UPDATE db_users_b
                        SET money_b = money_b + $to_referer,
                            from_referals = from_referals + '$to_referer'
                        WHERE id = '$refid'");

            # Статистика пополнений
            $da = time();
            $dd = $da + 60*60*24*15;
            $db->Query("INSERT INTO db_insert_money (`user`, `user_id`, `money`, `serebro`, `date_add`, `date_del`) VALUES ('$user_name','$user_id','$ik_payment_amount','$serebro','$da','$dd')");

            # Обновление статистики сайта
            $db->Query("UPDATE db_stats SET all_insert = all_insert + '$ik_payment_amount' WHERE id = '1'");

            # Конкурс
            $competition = new competition($db);
            $competition->UpdatePoints($user_id, $ik_payment_amount);
            #--------
            # Конкурс
            $invcompetition = new invcompetition($db);
            $invcompetition->UpdatePoints($user_id, $ik_payment_amount);
            #--------
            
            echo $paymentid."|success";

            // uncomment code below if you want to log successfull payments
            $f=fopen(PATH_TO_LOG."good.log", "ab+");
            fwrite($f, date("d.m.Y H:i")."; POST: ".serialize($_POST)."; STRING: $string; HASH: $hash\n");
            fflush($f);
            fclose($f);

        }else{  // you can also save invalid payments for debug purposes

            $nokow = $_POST['PAYEE_ACCOUNT'];
            $nokowby = $_POST['PAYER_ACCOUNT'];
            //Payee_Account - счет получателя
            //Payer_Account - счет отправителя
            $timedat = $_POST['TIMESTAMPGMT'];
            $units = $_POST['PAYMENT_UNITS'];
            $batch_num = $_POST['PAYMENT_BATCH_NUM'];
            $PAYMENT_AMOUNT = $_POST['PAYMENT_AMOUNT'];
            $ip = $_POST["BAGGAGE_FIELDS_ip"];
            $paymentid = $_POST['PAYMENT_ID'];
            $uid = $_POST["BAGGAGE_FIELDS_id"];
            $typepayment = "PerfectMoney";
            $payment = "0"; //если 0, то НЕТ платежа

            /*$db->Query("UPDATE `db_oplata_pm`
                SET `payment`='".$payment."',
                `nokow`='".$nokow."' ,
                `batch_num` = '".$batch_num."',
                `timedat` = '".$timedat."',
                `nokowby` = '".$nokowby."',
                `units` = '".$units."'
                WHERE `typepayment` = '".$typepayment."'
                AND `amount` = '".$PAYMENT_AMOUNT."'
                AND `id` = '".$paymentid."'
                AND `ip` = '".$ip."'"); //AND `memopay` = '".$uid."'*/

            echo $paymentid."|error";

            $f=fopen(PATH_TO_LOG."bad.log", "ab+");
            fwrite($f, date("d.m.Y H:i")."; REASON: additional checking failed with error(s): ".$apcua."; POST: ".serialize($_POST)."; STRING: $string; HASH: $hash\n");
            fflush($f);
            fclose($f);

        }

    }else{ // you can also save invalid payments for debug purposes

        // uncomment code below if you want to log requests with fake data
        $f=fopen(PATH_TO_LOG."bad.log", "ab+");
        fwrite($f, date("d.m.Y H:i")."; REASON: fake data; POST: ".serialize($_POST)."; STRING: $string; HASH: $hash\n");
        fflush($f);
        fclose($f);

    }


}else{ // you can also save invalid payments for debug purposes

    // uncomment code below if you want to log requests with bad hash
    $f=fopen(PATH_TO_LOG."bad.log", "ab+");
    fwrite($f, date("d.m.Y H:i")."; REASON: bad hash; POST: ".serialize($_POST)."; STRING: $string; HASH: $hash\n");
    fflush($f);
    fclose($f);

}

?>