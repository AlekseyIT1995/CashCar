<?php
# Константа для Include
define("CONST_RUFUS", true);

define("DR", $_SERVER['DOCUMENT_ROOT']);

# Автоподгрузка классов
function __autoload($name){ include(DR."/classes/_class.".$name.".php");}

# Класс конфига 
$config = new config;

# Функции
$func = new func;

# База данных
$db = new db($config->HostDB, $config->UserDB, $config->PassDB, $config->BaseDB);

$db->Query("SELECT * FROM db_config WHERE id = '1' LIMIT 1");
$sonfig_site = $db->FetchArray();

$db->Query("SELECT * FROM db_users_b ORDER BY `id` ASC");
while ($data = $db->FetchArray()) {
    $kyr1 = $data["a_t"]*$sonfig_site["a_in_h"];
    $kyr2 = $data["b_t"]*$sonfig_site["b_in_h"];
    $kyr3 = $data["c_t"]*$sonfig_site["c_in_h"];
    $kyr4 = $data["d_t"]*$sonfig_site["d_in_h"];
    $kyr5 = $data["e_t"]*$sonfig_site["e_in_h"];
    $kyr6 = $data["f_t"]*$sonfig_site["f_in_h"];
    $kyr7 = $data["g_t"]*$sonfig_site["g_in_h"];
    $kyr8 = $data["h_t"]*$sonfig_site["h_in_h"];
    $kyr9 = $data["j_t"]*$sonfig_site["j_in_h"];

    $kyrcall = $kyr1+$kyr2+$kyr3+$kyr4+$kyr5+$kyr6+$kyr7+$kyr8+$kyr9;

    $all = $kyrcall / $sonfig_site["items_per_coin"];

    $user_id = $data["id"];

    $db->MultiQuery("INSERT INTO `db_speed_user` (user_id, speed) VALUES ('$user_id','$all')");

    echo "User: ".$data["user"]." - Speed: ".$all."<br/>";
}




?>