<?php
######################################
# Модуль AdvCash Скрипт Fruit Farm
# Автор APTEMOH
# E-mail: anatolii.123456@yandex.ru
# Skype: ArtIncProject
# VK.com: https://vk.com/id381626457
######################################

# Заголовки страницы с кодировкой :
header( 'Content-type: text/html; charset=utf-8' );

# Автоподгрузка классов
function __autoload($name){ include("classes/_class.".$name.".php");}

# Класс конфига
$config = new config;

# Функции
$func = new func;

# База данных
$db = new db($config->HostDB, $config->UserDB, $config->PassDB, $config->BaseDB);

# Получение внешних данных :
$transactionId = isset( $_POST['ac_transfer'] ) ? trim( $_POST['ac_transfer'] ) : null;
$paymentDate = isset( $_POST['ac_start_date'] ) ? $_POST['ac_start_date'] : null;
$sciName = isset( $_POST['ac_sci_name'] ) ? trim( $_POST['ac_sci_name'] ) : null;
$payer = isset( $_POST['ac_src_wallet'] ) ? trim( $_POST['ac_src_wallet'] ) : null;
$destWallet = isset( $_POST['ac_dest_wallet'] ) ? trim( $_POST['ac_dest_wallet'] ) : null;
$orderId = isset( $_POST['ac_order_id'] ) ? trim( $_POST['ac_order_id'] ) : null;
$amount = isset( $_POST['ac_amount'] ) ? trim( $_POST['ac_amount'] ) : null;
$currency = isset( $_POST['ac_merchant_currency'] ) ? trim( $_POST['ac_merchant_currency'] ) : null;
$hash = isset( $_POST['ac_hash'] ) ? trim( $_POST['ac_hash'] ) : null;

# Проверка валюты платежа :
if( !in_array( $currency, array( 'USD', 'EUR', 'RUR', 'GBP' ) ) )
    die( 'Неверная валюта платежа' );

# Проверка контрольной подписи :
if( $hash != strtolower( hash('sha256', $transactionId.':'.$paymentDate.':'.$sciName.':'.$payer.':'.$destWallet.':'.$orderId.':'.$amount.':'.$currency.':'.$config->secret ) ) )
    die( 'Неверная контрольная подпись' );


#############################################
#       ДЕЙСТВИЯ ПРИ ПОЛУЧЕНИИ ПЛАТЕЖА      #
#############################################

#echo 'Получен платеж Advanced Cash', "Счет отправителя: ".$payer."\nСумма и валюта: ".$amount." ".$currency."\nНомер транзакции: ".$transactionId;


if (isset($_POST["ac_order_id"]) && isset($_POST["ac_transfer"]))
{
    $password = $config->secret;
    $arHash = array($_POST['ac_transfer'],
                    $_POST['ac_start_date'],
                    $_POST['ac_sci_name'],
                    $_POST['ac_src_wallet'],
                    $_POST['ac_dest_wallet'],
                    $_POST['ac_order_id'],
                    $_POST['ac_amount'],
                    $_POST['ac_merchant_currency'],
                    $password
                );

    $sign_hash = strtolower( hash('sha256', implode(":", $arHash)) );

    if ($_POST["ac_hash"] == $sign_hash)
    {

        $db->Query("SELECT * FROM `db_payeer_insert` WHERE id = '".intval($_POST['ac_order_id'])."'");
        if($db->NumRows() == 0){ echo $_POST['ac_order_id']."|error"; exit;}

        $payeer_row = $db->FetchArray();
        if($payeer_row["status"] > 0){ echo $_POST['ac_order_id']."|success"; exit;}

        $db->Query("UPDATE `db_payeer_insert` SET status = '1' WHERE id = '".intval($_POST['ac_order_id'])."'");

        $ik_payment_amount = $amount;
        $user_id = $payeer_row["user_id"];

        # Настройки
        $db->Query("SELECT * FROM db_config WHERE id = '1' LIMIT 1");
        $sonfig_site = $db->FetchArray();

        $db->Query("SELECT user, referer_id FROM db_users_a WHERE id = '{$user_id}' LIMIT 1");
        $user_ardata = $db->FetchArray();
        $user_name = $user_ardata["user"];
        $refid = $user_ardata["referer_id"];

        # Зачисляем баланс
        $serebro = sprintf("%.4f", floatval($sonfig_site["ser_per_wmr"] * $ik_payment_amount) );

        $db->Query("SELECT insert_sum FROM db_users_b WHERE id = '{$user_id}' LIMIT 1");
        $ins_sum = $db->FetchRow();

        $serebro = intval($ins_sum <= 0.01) ? ($serebro + ($serebro * 0.1) ) : $serebro;

        #$add_tree = ( $ik_payment_amount >= 499.99) ? 2 : 0; e_t = e_t + '$add_tree',
        $lsb = time();
        /* ====== Рефералка 3 уровня ====== */
        $db->Query("SELECT user, referer_id, referer_id2, referer_id3 FROM db_users_a WHERE id = '{$user_id}' LIMIT 1");
        $user_ardata = $db->FetchArray();
        $user_name = $user_ardata["user"];
        $refid = $user_ardata["referer_id"];
        $ref2 = $user_ardata["referer_id2"];
        $ref3 = $user_ardata["referer_id3"];

        $to_referer  = ($serebro * 0.04); // Первый уровень - 4 процента
        $to_referer2 = ($serebro * 0.03); // Второй уровень - 3 процента
        $to_referer3 = ($serebro * 0.01); // Третий уровень - 1 процент


        $db->Query("UPDATE db_users_b SET money_b = money_b + $to_referer2 WHERE id = '$ref2'");
        $db->Query("UPDATE db_users_b SET money_b = money_b + $to_referer3 WHERE id = '$ref3'");

        $db->Query("UPDATE db_users_a SET doxod2 = doxod2 + $to_referer2 WHERE id = '$user_id'");
        $db->Query("UPDATE db_users_a SET doxod3 = doxod3 + $to_referer3 WHERE id = '$user_id'");

        /* ====== /Рефералка 3 уровня ====== */

        # Зачисляем средства НАМ )
        $db->Query("UPDATE db_users_b
                    SET money_b = money_b + '$serebro',
                        to_referer = to_referer + '$to_referer',
                        insert_sum = insert_sum + '$ik_payment_amount'
                    WHERE id = '{$user_id}'"); # last_sbor = '$lsb',

        # Зачисляем средства рефереру и дерево
        #$add_tree_referer = ($ins_sum <= 0.01) ? ", a_t = a_t + 1" : "";
        $db->Query("UPDATE db_users_b
                    SET money_b = money_b + $to_referer,
                        from_referals = from_referals + '$to_referer'
                    WHERE id = '$refid'");

        # Статистика пополнений
        $da = time();
        $dd = $da + 60*60*24*15;
        $db->Query("INSERT INTO db_insert_money (`user`, `user_id`, `money`, `serebro`, `date_add`, `date_del`) VALUES ('$user_name','$user_id','$ik_payment_amount','$serebro','$da','$dd')");

        # Обновление статистики сайта
        $db->Query("UPDATE db_stats SET all_insert = all_insert + '$ik_payment_amount' WHERE id = '1'");

        # Конкурс
        $competition = new competition($db);
        $competition->UpdatePoints($user_id, $ik_payment_amount);
        #--------
        # Конкурс
        $invcompetition = new invcompetition($db);
        $invcompetition->UpdatePoints($user_id, $ik_payment_amount);
        #--------

        echo $_POST['ac_order_id']."|success";
        exit;

    }

    echo $_POST['ac_order_id']."|error";

}


?>